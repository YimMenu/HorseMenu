param([switch]$Clean, [switch]$ConfigureOnly)

$ErrorActionPreference = "Stop"
$root  = Split-Path -Parent $MyInvocation.MyCommand.Path
$src   = Join-Path $root "src"
$build = Join-Path $root "build"

# 1. 找 VS2022 的 vcvars64.bat（BuildTools 或完整版都行）
$vswhere = "${env:ProgramFiles(x86)}\Microsoft Visual Studio\Installer\vswhere.exe"
$vcvars = $null
if (Test-Path $vswhere) {
    $vsPath = & $vswhere -latest -products * -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -property installationPath
    if ($vsPath) { $vcvars = Join-Path $vsPath "VC\Auxiliary\Build\vcvars64.bat" }
}
if (-not $vcvars -or -not (Test-Path $vcvars)) { throw "vcvars64.bat not found, 请安装 Visual Studio 2022（含 MSVC v143）" }

# 2. cmake / ninja 走 PATH（也可用 -DCMakePath 手动指定）
$cmake = (Get-Command cmake -ErrorAction SilentlyContinue).Source
if (-not $cmake) { throw "cmake not found, 请先安装 CMake 并加入 PATH" }
$ninja = (Get-Command ninja -ErrorAction SilentlyContinue).Source
if (-not $ninja) { throw "ninja not found, 请先安装 Ninja 并加入 PATH" }

if ($Clean -and (Test-Path $build)) { Remove-Item -LiteralPath $build -Recurse -Force }

# 3. 系统 TEMP 不可写时回退到工程内 tmp
$tmpdir = Join-Path $root "tmp"
if (-not (Test-Path $tmpdir)) { New-Item -ItemType Directory -Path $tmpdir | Out-Null }
$env:TMP  = $tmpdir
$env:TEMP = $tmpdir

$cfgArgs = "-S `"$src`" -B `"$build`" -G Ninja " +
    "-DCMAKE_BUILD_TYPE=Release -DCMAKE_TRY_COMPILE_CONFIGURATION=Release " +
    "-DCMAKE_MAKE_PROGRAM=`"$ninja`" -DCMAKE_POLICY_VERSION_MINIMUM=3.5 " +
    "-DCMAKE_C_FLAGS=`"/utf-8`" -DCMAKE_CXX_FLAGS=`"/utf-8`" " +
    "-DCMAKE_C_FLAGS_DEBUG=`"-Od -MDd`" -DCMAKE_CXX_FLAGS_DEBUG=`"-Od -MDd`" " +
    "-DCMAKE_C_FLAGS_RELWITHDEBINFO=`"-O2 -MD`" -DCMAKE_CXX_FLAGS_RELWITHDEBINFO=`"-O2 -MD`""

$lines = @("call `"$vcvars`" >nul")
if ($Clean -or $ConfigureOnly -or -not (Test-Path (Join-Path $build "build.ninja"))) {
    $lines += "`"$cmake`" $cfgArgs"
}
if (-not $ConfigureOnly) {
    $lines += @("if errorlevel 1 exit /b 1", "`"$cmake`" --build `"$build`"")
}

$bat = Join-Path $root "_build_run.bat"
[IO.File]::WriteAllText($bat, ($lines -join "`r`n") + "`r`nexit /b %errorlevel%`r`n", (New-Object Text.UTF8Encoding $false))
cmd /c "`"$bat`""
Write-Host "exit code: $LASTEXITCODE"
