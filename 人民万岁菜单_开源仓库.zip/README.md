<div align="center">

# 人民万岁菜单

**Terminus 中文重制版 · People's Menu for Red Dead Redemption 2**

RDR2 单机 / 线上通用 · 半透明毛玻璃 · 圆角卡片 · 15 套主题背景 · 165 套模组 · Lua 脚本系统

</div>

> 基于 [Terminus（原 HorseMenu）](https://github.com/YimMenu/HorseMenu) 深度重制的中文菜单项目：
> 全量界面汉化 + 主题系统 + 模组库 + 脚本系统 + 独立安装器。

---

## 截图

| 主题背景 / 毛玻璃面板 |
| --- |
| ![游戏内菜单](docs/images/界面-游戏内菜单.png) |

| 模组页（165 套模组，可搜索） | 脚本页（Lua 5.4） |
| --- | --- |
| ![模组](docs/images/预览-模组页.png) | ![脚本](docs/images/预览-脚本页.png) |

| 主题效果 | 交互预览站 | 安装器 |
| --- | --- | --- |
| ![主题](docs/images/界面-主题效果.png) | ![预览](docs/images/界面-交互预览站.png) | ![安装器](docs/images/界面-安装器.png) |

---

## 特性

- **全量中文化**：1013 条界面文本已汉化，14 类收藏品 / 40 种草药 / 56 张塔罗牌 / 演出场景下拉 13 项全部中文
- **主题系统**：15 套内置主题背景，半透明毛玻璃 + 圆角卡片，可调背景亮度 / 不透明度 / 磨砂强度
- **一键防护**：18 项防护开关一键全开，含实体校验增强
- **模组库**：内置 165 套模组（载具 61 / 马匹 29 / 世界 75），带编号、中文名与备注，支持按名称或编号搜索
- **Lua 脚本系统**：内置 Lua 5.4 引擎，脚本放进 `C:\PeopleMenu\scripts` 即加载运行
- **脚本接口**：生成物体 / NPC / 载具、传送、旋转、冻结、碰撞、无敌、同步为网络实体、每帧回调
- **稳定优先**：模组生成分帧执行（载具每帧 8 件、世界每帧 4 件，单次上限 400 件），生成后立即同步为网络实体，联机队友可见

---

## 目录结构

```
src/            C++ 核心（CMake 工程，菜单本体）
  src/core/     通用框架：命令、热键、本地化、前端、文件管理
  src/game/     游戏相关：指针、Hook、防护、脚本、绘制
installer/      C# WPF 单文件安装器（选路径、写文件、拉起游戏）
themes/         15 套内置主题背景（JPG）
tools/          Python 辅助脚本：本地化提取 / 字典生成 / 主题打包 / 预览数据生成
docs/           使用说明与界面截图
```

---

## 构建

**前置要求**

- Visual Studio 2022（含 MSVC v143 与 Windows SDK）
- CMake ≥ 3.20、Ninja
- Windows 10/11 x64

**构建步骤**

```powershell
# 在仓库根目录执行（脚本会自动查找 vcvars64.bat 并配置 Ninja + Release）
powershell -ExecutionPolicy Bypass -File .\build.ps1
```

只配置不编译：

```powershell
powershell -ExecutionPolicy Bypass -File .\build.ps1 -ConfigureOnly
```

清理重来：

```powershell
powershell -ExecutionPolicy Bypass -File .\build.ps1 -Clean
```

> 说明：本仓库不包含第三方依赖（`deps/`、`tools_bin/`、编译产物均未入库）。
> 公开构建需要自行准备依赖库与 `vcvars64.bat` 环境；`build.ps1` 里的 CMake / Ninja 路径请按本机情况修改。
> 编译产物为 `Terminus.dll`，由安装器注入到 `rdr2.exe`。

---

## 安装与使用

1. 运行单文件安装器，选择安装位置（默认 `C:\PeopleMenu`），一路下一步
2. 进游戏到主界面后再注入（安装器会处理注入）
3. 进游戏后按 **INSERT** 打开 / 关闭菜单，方向键切换分类
4. 目录约定：
   - 模组包 → `C:\PeopleMenu\mods`
   - Lua 脚本 → `C:\PeopleMenu\scripts`
5. 全部文件只落在 `C:\PeopleMenu` 一个目录，DLL 带隐藏 + 系统属性，不写 AppData、不污染游戏根目录

---

## 脚本系统

- 引擎：Lua 5.4，放入 `C:\PeopleMenu\scripts` 的 `.lua` 文件会被加载
- 菜单「脚本」页签可查看已加载脚本与运行状态，支持一键重新加载、全部卸载
- 单个脚本报错只影响该脚本自身，不会连累菜单；重载时会先彻底卸载旧脚本，避免旧回调残留
- 可用接口：生成物体 / NPC / 载具，传送、旋转、冻结、碰撞、无敌，同步为网络实体，每帧回调

---

## 交流

- QQ 开黑群：https://qm.qq.com/q/EdE7aQ59rW
- 官网：https://xn--kiv066b.myweb999.cfd/

---

## 免责声明

本菜单为第三方模组，与 Rockstar Games 和菜单作者无关，使用风险自负。

---

## 许可证

本项目基于 Terminus / HorseMenu（YimMenu 系）二次开发，遵循 **GNU General Public License v3.0**，详见 [LICENSE](LICENSE)。
