#include "util/Joaat.hpp"
#include "Command.hpp"
#include "Commands.hpp"
#include "core/frontend/Localization.hpp"

namespace YimMenu
{
	Command::Command(std::string name, std::string label, std::string description, int num_args) :
	    m_Name(name),                       // 内部标识：不翻译（用于配置存档与哈希）
	    m_Label(LH(label.c_str())),         // 显示名称：查表转中文
	    m_Description(LH(description.c_str())),
	    m_NumArgs(num_args),
	    m_Hash(Joaat(name))
	{
		Commands::AddCommand(this);
	}

	void Command::Call()
	{
		OnCall();
	}

	void Command::MarkDirty()
	{
		Commands::MarkDirty();
	}
}