#pragma once
#include <string>
#include <utility>
#include <vector>

namespace YimMenu
{
	// Lua 脚本系统：脚本放在 C:\PeopleMenu\scripts\*.lua，每个文件一个独立沙箱
	// 所有 Lua 调用都在脚本 fiber 里执行，不会阻塞渲染线程
	class LuaScripts
	{
	public:
		static void LoadAll();   // 只会排队到 FiberPool，实际加载在脚本上下文里完成
		static void Unload();
		static void Tick();      // 由 FiberPool 常驻循环调用
		static bool IsLoaded();
		static int Count();
		static std::string Status();
		static const std::vector<std::pair<std::string, std::string>>& Entries(); // 名字, 状态
	};
}
