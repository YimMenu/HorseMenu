#include "LuaScripts.hpp"

#include "core/frontend/Notifications.hpp"
#include "game/backend/FiberPool.hpp"
#include "game/backend/ScriptMgr.hpp"
#include "game/backend/Self.hpp"
#include "game/rdr/Natives.hpp"
#include "game/rdr/Object.hpp"
#include "game/rdr/Ped.hpp"
#include "game/rdr/Vehicle.hpp"

#include <atomic>
#include <chrono>
#include <filesystem>
#include <fstream>
#include <lua.hpp>
#include <sstream>

namespace YimMenu
{
	namespace
	{
		struct ScriptState
		{
			std::string Name;
			std::string Status;
			lua_State* L;
			bool Failed;
		};

		std::vector<ScriptState> s_Scripts;
		std::vector<std::pair<std::string, std::string>> s_Entries;
		std::atomic_bool s_LoadRequested{false};
		std::atomic_bool s_UnloadRequested{false};
		bool s_TickedOnce = false;
		std::string s_Status = "未加载";

		std::filesystem::path ConfigRoot()
		{
			std::error_code ec;
			auto root = std::filesystem::path("C:\\PeopleMenu");
			if (std::filesystem::exists(root, ec))
				return root;
			const char* appdata = std::getenv("appdata");
			if (appdata)
				return std::filesystem::path(appdata) / "PeopleMenu";
			return root;
		}

		std::filesystem::path ScriptDir()
		{
			return ConfigRoot() / "scripts";
		}

		Entity ToEntity(lua_State* L)
		{
			int h = static_cast<int>(luaL_checkinteger(L, 1));
			return Entity(h);
		}

		// ---------------- 暴露给 Lua 的函数 ----------------
		int l_log(lua_State* L)
		{
			std::string msg = luaL_tolstring(L, 1, nullptr) ? lua_tostring(L, -1) : "";
			lua_pop(L, 1);
			LOG(INFO) << "[Lua] " << msg;
			return 0;
		}

		int l_notify(lua_State* L)
		{
			const char* msg = luaL_checkstring(L, 1);
			const char* title = lua_gettop(L) >= 2 ? luaL_checkstring(L, 2) : "Lua 脚本";
			Notifications::Show(title, msg, NotificationType::Info);
			return 0;
		}

		int l_pos(lua_State* L)
		{
			auto ped = Self::GetPed();
			rage::fvector3 p{0.0f, 0.0f, 0.0f};
			if (ped)
				p = ped.GetPosition();
			lua_pushnumber(L, p.x);
			lua_pushnumber(L, p.y);
			lua_pushnumber(L, p.z);
			return 3;
		}

		int l_player(lua_State* L)
		{
			auto ped = Self::GetPed();
			lua_pushinteger(L, ped ? ped.GetHandle() : 0);
			return 1;
		}

		int l_spawn_object(lua_State* L)
		{
			uint32_t model = static_cast<uint32_t>(luaL_checkinteger(L, 1));
			rage::fvector3 pos{static_cast<float>(luaL_checknumber(L, 2)),
			    static_cast<float>(luaL_checknumber(L, 3)),
			    static_cast<float>(luaL_checknumber(L, 4))};
			auto o = Object::Create(model, pos);
			lua_pushinteger(L, o ? o.GetHandle() : 0);
			return 1;
		}

		int l_spawn_ped(lua_State* L)
		{
			uint32_t model = static_cast<uint32_t>(luaL_checkinteger(L, 1));
			rage::fvector3 pos{static_cast<float>(luaL_checknumber(L, 2)),
			    static_cast<float>(luaL_checknumber(L, 3)),
			    static_cast<float>(luaL_checknumber(L, 4))};
			float heading = static_cast<float>(luaL_optnumber(L, 5, 0.0));
			auto p = Ped::Create(model, pos, heading);
			lua_pushinteger(L, p ? p.GetHandle() : 0);
			return 1;
		}

		int l_spawn_vehicle(lua_State* L)
		{
			uint32_t model = static_cast<uint32_t>(luaL_checkinteger(L, 1));
			rage::fvector3 pos{static_cast<float>(luaL_checknumber(L, 2)),
			    static_cast<float>(luaL_checknumber(L, 3)),
			    static_cast<float>(luaL_checknumber(L, 4))};
			float heading = static_cast<float>(luaL_optnumber(L, 5, 0.0));
			auto v = Vehicle::Create(model, pos, heading);
			lua_pushinteger(L, v ? v.GetHandle() : 0);
			return 1;
		}

		int l_delete(lua_State* L)
		{
			auto e = ToEntity(L);
			if (e)
				e.Delete();
			return 0;
		}

		int l_set_pos(lua_State* L)
		{
			auto e = ToEntity(L);
			if (e)
				e.SetPosition(rage::fvector3{static_cast<float>(luaL_checknumber(L, 2)),
				    static_cast<float>(luaL_checknumber(L, 3)),
				    static_cast<float>(luaL_checknumber(L, 4))});
			return 0;
		}

		int l_set_rot(lua_State* L)
		{
			auto e = ToEntity(L);
			if (e)
				e.SetRotation(rage::fvector3{static_cast<float>(luaL_checknumber(L, 2)),
				    static_cast<float>(luaL_checknumber(L, 3)),
				    static_cast<float>(luaL_checknumber(L, 4))}, 2);
			return 0;
		}

		int l_freeze(lua_State* L)
		{
			auto e = ToEntity(L);
			if (e)
				e.SetFrozen(lua_toboolean(L, 2) != 0);
			return 0;
		}

		int l_collision(lua_State* L)
		{
			auto e = ToEntity(L);
			if (e)
				e.SetCollision(lua_toboolean(L, 2) != 0);
			return 0;
		}

		int l_invincible(lua_State* L)
		{
			auto e = ToEntity(L);
			if (e)
				e.SetInvincible(lua_toboolean(L, 2) != 0);
			return 0;
		}

		int l_sync(lua_State* L)
		{
			auto e = ToEntity(L);
			if (e)
				e.ForceSync();
			return 0;
		}

		int l_valid(lua_State* L)
		{
			auto e = ToEntity(L);
			lua_pushboolean(L, e ? 1 : 0);
			return 1;
		}

		// 注册每帧回调：脚本结束前调用 PM.onTick(function)
		int l_on_tick(lua_State* L)
		{
			luaL_checktype(L, 1, LUA_TFUNCTION);
			lua_getfield(L, LUA_REGISTRYINDEX, "pm_ticks");
			lua_pushvalue(L, 1);
			int ref = luaL_ref(L, -2); // ticks[#ticks+1] = ref, 存的是函数本身
			lua_getfield(L, LUA_REGISTRYINDEX, "pm_tick_list");
			lua_pushinteger(L, ref);
			lua_rawseti(L, -2, static_cast<lua_Integer>(lua_rawlen(L, -2)) + 1);
			lua_pop(L, 2);
			return 0;
		}

		void RegisterApi(lua_State* L)
		{
			lua_newtable(L); // pm_ticks: function 存储表
			lua_setfield(L, LUA_REGISTRYINDEX, "pm_ticks");
			lua_newtable(L); // pm_tick_list: ref 列表
			lua_setfield(L, LUA_REGISTRYINDEX, "pm_tick_list");

			lua_newtable(L);
			struct
			{
				const char* name;
				lua_CFunction fn;
			} funcs[] = {
			    {"log", l_log},
			    {"notify", l_notify},
			    {"pos", l_pos},
			    {"player", l_player},
			    {"spawnObject", l_spawn_object},
			    {"spawnPed", l_spawn_ped},
			    {"spawnVehicle", l_spawn_vehicle},
			    {"delete", l_delete},
			    {"setPos", l_set_pos},
			    {"setRot", l_set_rot},
			    {"freeze", l_freeze},
			    {"collision", l_collision},
			    {"invincible", l_invincible},
			    {"sync", l_sync},
			    {"valid", l_valid},
			    {"onTick", l_on_tick},
			};
			for (auto& f : funcs)
			{
				lua_pushcfunction(L, f.fn);
				lua_setfield(L, -2, f.name);
			}
			lua_setglobal(L, "PM");
		}

		// 每次加载菜单都会重写一份 API 说明到脚本目录，别人照着写就能用
		const char* kApiDoc = R"PMDOC(# 人民万岁【RDR2】菜单 · Lua 脚本 API

> 这个文件由菜单每次加载时自动生成（覆盖写入），不要在它里面改东西。
> 你自己的脚本写在 `C:\PeopleMenu\scripts\` 下的独立 `.lua` 文件里，改完在
> 菜单 → 脚本 → 重新加载脚本 里刷新即可。下划线开头的文件（`_lib.lua`）会被跳过，可以当公共库。

---

## 一、最快上手

```lua
local x, y, z = PM.pos()                        -- 拿自己脚下坐标
local veh = PM.spawnVehicle(0x5E56769C, x + 2, y + 2, z, 0.0)
if veh ~= 0 then
    PM.sync(veh)                                -- 同步给所有玩家
    PM.freeze(veh, true)
    PM.notify("车生成好了")
end

PM.onTick(function()
    -- 每帧回调（约 10 次/秒），这里只放轻量逻辑
end)
```

脚本加载成功时，菜单的「脚本」页签会显示 `已加载`；报错会显示红字原因。

---

## 二、函数总表

| 函数 | 说明 | 返回值 |
| --- | --- | --- |
| `PM.log(msg)` | 写一行日志（菜单日志/日志文件） | 无 |
| `PM.notify(msg [, title])` | 右下角弹通知，默认标题「Lua 脚本」 | 无 |
| `PM.pos()` | 自己 ped 的坐标 | `x, y, z` 三个数 |
| `PM.player()` | 自己 ped 的实体句柄 | 整数句柄，无效为 `0` |
| `PM.spawnObject(hash, x, y, z)` | 生成物体 | 句柄，失败 `0` |
| `PM.spawnPed(hash, x, y, z [, heading])` | 生成 NPC / 动物 | 句柄，失败 `0` |
| `PM.spawnVehicle(hash, x, y, z [, heading])` | 生成载具 | 句柄，失败 `0` |
| `PM.delete(handle)` | 删除实体 | 无 |
| `PM.setPos(handle, x, y, z)` | 传送/改坐标 | 无 |
| `PM.setRot(handle, x, y, z)` | 改旋转（欧拉角，顺序 2） | 无 |
| `PM.freeze(handle, bool)` | 冻结位置 | 无 |
| `PM.collision(handle, bool)` | 开/关碰撞 | 无 |
| `PM.invincible(handle, bool)` | 无敌 | 无 |
| `PM.sync(handle)` | 强制同步成网络实体（所有人都能看到） | 无 |
| `PM.valid(handle)` | 实体是否还在 | `true` / `false` |
| `PM.onTick(fn)` | 注册每帧回调，可以注册多个 | 无 |

句柄说明：脚本里拿到的都是整数句柄，`0` 表示无效；实体被删除或所在区域卸载后就失效，用 `PM.valid(h)` 先判断再操作。

---

## 三、常用写法

### 1. 生成一堆东西并挂到车上

```lua
local x, y, z = PM.pos()
local veh = PM.spawnVehicle(0x5E56769C, x + 3, y + 3, z, 0)
if veh ~= 0 then
    PM.sync(veh)
    for i = 1, 3 do
        local obj = PM.spawnObject(0x7CD0DE94, x + 3, y + 3, z)
        if obj ~= 0 then
            PM.setPos(obj, x + 3 + i, y + 3, z)
            PM.collision(obj, false)
            PM.freeze(obj, true)
            PM.sync(obj)
        end
    end
end
```

### 2. 定时清理自己刚生成的东西

```lua
local mine = {}
PM.onTick(function()
    for i = #mine, 1, -1 do
        if not PM.valid(mine[i]) then
            table.remove(mine, i)
        end
    end
end)
```

### 3. 玩家一移动就把他拉回来（示例，谨慎使用）

```lua
local p = PM.player()
local last = {PM.pos()}
PM.onTick(function()
    if p == 0 or not PM.valid(p) then return end
    local x, y, z = PM.pos()
    PM.setPos(p, last[1], last[2], last[3])
    last = {x, y, z}
end)
```

### 4. 每个脚本自己的状态

Lua 每个文件单独一个状态机，文件之间变量不共享。要共享就写到文件里（没有 io 库，所以不能直接读写文件），或者把公共函数放进一个 `_lib.lua` 之外的方式：直接在每个脚本里重复写少量代码最稳。

---

## 四、模型哈希从哪来

- 载具/物件/动物的模型哈希都是 32 位无符号整数，菜单里看到的模型名（如 `Rc Boat`）对应一个哈希（例如 `0x5E56769C`）。
- 在 `C:\PeopleMenu\mods\` 里的模组 JSON（`vehicles` / `horses` / `world`）能直接查到大量可用哈希：`base.model`、`items[].model`、`base.horseModel`。
- 拿到的是 `0x` 开头的十六进制字符串时，直接在 Lua 里写 `0x...` 就是合法数字。

---

## 五、性能与安全（重要）

1. **`onTick` 会一直跑**：函数里不要做循环几百次的活，也不要每帧都 `spawn`。需要批量生成时用计数分帧，例如每 10 次回调做一件。
2. **单次实体数量**：菜单自身限制单次最多 400 个实体；脚本自己也要克制，一次几十个以内最稳。
3. **生成前先看模型合法**：无效哈希会返回 `0` 并且不生成，不会崩，但会浪费时间。
4. **沙箱**：脚本里没有 `io`、`os`、`package`、`dofile`、`loadfile`，读写不了你的文件和进程；也不能联网。只有 `print` 之外的数学/字符串/表库和上面这些 `PM.*` 可用。
5. **别在脚本里删别人的实体**：只能操作自己拿到的句柄。
6. **出错不会崩游戏**：单个脚本报错只会把它的状态标红并停止这一帧的回调，其余脚本和菜单照常。

---

## 六、排错

| 现象 | 原因 |
| --- | --- |
| 脚本列表显示 `加载失败: ...` | Lua 语法错误，看提示的行号 |
| 显示 `运行错误: ...` | `onTick` 回调里报错，改完重新加载 |
| `spawn*` 一直返回 `0` | 模型哈希不对，或模型没能加载（换一个已知能用的哈希） |
| 生成出来了但别人看不见 | 少调了 `PM.sync(handle)` |
| 改动没生效 | 忘了点「重新加载脚本」 |

---

## 七、完整示例（可直接用）

```lua
-- 脚下生成一辆船，并挂两个装饰物，全部同步给所有人
local x, y, z = PM.pos()
local base = PM.spawnVehicle(0x5E56769C, x + 4, y + 4, z, 0.0)
if base == 0 then
    PM.notify("基座生成失败，换个位置再试", "我的脚本")
    return
end
PM.sync(base)
PM.invincible(base, true)

for i = -1, 1, 2 do
    local obj = PM.spawnObject(0x7CD0DE94, x + 4 + i, y + 4, z)
    if obj ~= 0 then
        PM.collision(obj, false)
        PM.freeze(obj, true)
        PM.sync(obj)
    end
end

PM.notify("生成完成", "我的脚本")
```
)PMDOC";

		void WriteApiDoc()
		{
			std::error_code ec;
			auto dir = ScriptDir();
			std::filesystem::create_directories(dir, ec);
			auto path = dir / "人民万岁脚本API.md";
			std::ofstream out(path, std::ios::binary | std::ios::trunc);
			if (!out.is_open())
				return;
			out << kApiDoc;
			LOG(INFO) << "Lua: API 文档已写入 " << path.string();
		}

		lua_State* NewState()
		{
			lua_State* L = luaL_newstate();
			if (!L)
				return nullptr;
			// 只开安全库：没有 io/os/package，脚本碰不到文件系统和进程
			luaL_requiref(L, "_G", luaopen_base, 1);
			lua_pop(L, 1);
			luaL_requiref(L, LUA_TABLIBNAME, luaopen_table, 1);
			lua_pop(L, 1);
			luaL_requiref(L, LUA_STRLIBNAME, luaopen_string, 1);
			lua_pop(L, 1);
			luaL_requiref(L, LUA_MATHLIBNAME, luaopen_math, 1);
			lua_pop(L, 1);
			luaL_requiref(L, LUA_UTF8LIBNAME, luaopen_utf8, 1);
			lua_pop(L, 1);
			RegisterApi(L);
			return L;
		}

		void ClearScripts()
		{
			for (auto& s : s_Scripts)
				if (s.L)
					lua_close(s.L);
			s_Scripts.clear();
			s_Entries.clear();
		}

		void LoadImpl()
		{
			ClearScripts();
			s_TickedOnce = false;

			WriteApiDoc(); // 每次加载都重新放一份 API 文档到脚本目录

			std::filesystem::path dir = ScriptDir();
			std::error_code ec;
			if (!std::filesystem::exists(dir, ec))
			{
				std::filesystem::create_directories(dir, ec);
				s_Status = "脚本目录已创建，还没有脚本：" + dir.string();
				return;
			}

			std::vector<std::filesystem::path> files;
			for (auto& e : std::filesystem::directory_iterator(dir, ec))
			{
				if (!e.is_regular_file(ec))
					continue;
				if (e.path().extension() != ".lua")
					continue;
				if (e.path().filename().string().rfind("_", 0) == 0)
					continue; // 下划线开头的当公共库
				files.push_back(e.path());
			}
			std::sort(files.begin(), files.end());

			int ok_count = 0;
			for (auto& f : files)
			{
				ScriptState st;
				st.Name = f.filename().string();
				st.L    = NewState();
				st.Failed = false;
				if (!st.L)
				{
					st.Status = "无法创建 Lua 状态";
					s_Scripts.push_back(std::move(st));
					continue;
				}

				std::ifstream in(f, std::ios::binary);
				std::stringstream ss;
				ss << in.rdbuf();
				std::string src = ss.str();

				int rc = luaL_loadbuffer(st.L, src.c_str(), src.size(), ("@" + st.Name).c_str());
				if (rc == LUA_OK)
					rc = lua_pcall(st.L, 0, 0, 0);

				if (rc != LUA_OK)
				{
					st.Failed = true;
					st.Status = std::string("加载失败: ") + lua_tostring(st.L, -1);
					LOG(INFO) << "Lua: " << st.Name << " " << st.Status;
					lua_pop(st.L, 1);
				}
				else
				{
					st.Status = "已加载";
					ok_count++;
				}

				s_Entries.push_back({st.Name, st.Status});
				s_Scripts.push_back(std::move(st));
			}

			s_Status = std::format("已加载 {}/{} 个脚本", ok_count, static_cast<int>(files.size()));
			LOG(INFO) << "Lua: " << s_Status;
		}

		void TickImpl()
		{
			for (auto& s : s_Scripts)
			{
				if (!s.L || s.Failed)
					continue;

				lua_State* L = s.L;
				lua_getfield(L, LUA_REGISTRYINDEX, "pm_tick_list");
				if (!lua_istable(L, -1))
				{
					lua_pop(L, 1);
					continue;
				}

				lua_Integer n = lua_rawlen(L, -1);
				for (lua_Integer i = 1; i <= n; i++)
				{
					lua_rawgeti(L, -1, i); // ref
					int ref = static_cast<int>(lua_tointeger(L, -1));
					lua_pop(L, 1);

					lua_getfield(L, LUA_REGISTRYINDEX, "pm_ticks");
					lua_rawgeti(L, -1, ref);
					lua_remove(L, -2); // 去掉 ticks 表，栈上只剩函数
					if (!lua_isfunction(L, -1))
					{
						lua_pop(L, 1);
						continue;
					}

					if (lua_pcall(L, 0, 0, 0) != LUA_OK)
					{
						s.Status = std::string("运行错误: ") + lua_tostring(L, -1);
						LOG(INFO) << "Lua: " << s.Name << " " << s.Status;
						lua_pop(L, 1);
						for (auto& e : s_Entries)
							if (e.first == s.Name)
								e.second = s.Status;
					}
				}
				lua_pop(L, 1);
			}
		}
	}

	void LuaScripts::LoadAll()
	{
		s_LoadRequested = true;
	}

	void LuaScripts::Unload()
	{
		s_UnloadRequested = true;
	}

	bool LuaScripts::IsLoaded()
	{
		return s_Status.rfind("已加载", 0) == 0;
	}

	int LuaScripts::Count()
	{
		return static_cast<int>(s_Entries.size());
	}

	std::string LuaScripts::Status()
	{
		return s_Status;
	}

	const std::vector<std::pair<std::string, std::string>>& LuaScripts::Entries()
	{
		return s_Entries;
	}

	void LuaScripts::Tick()
	{
		// 常驻脚本循环：第一帧先扫盘加载，之后每 100ms 跑一次所有 onTick 回调
		while (true)
		{
			if (!s_TickedOnce)
			{
				s_TickedOnce = true;
				LoadImpl();
			}
			if (s_LoadRequested.exchange(false))
				LoadImpl();
			if (s_UnloadRequested.exchange(false))
			{
				ClearScripts();
				s_Status = "已卸载";
			}

			TickImpl();
			ScriptMgr::Yield(std::chrono::milliseconds(100));
		}
	}
}
