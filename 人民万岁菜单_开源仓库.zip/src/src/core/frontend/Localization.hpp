﻿#pragma once

namespace YimMenu
{
	namespace Localization
	{
		const char* Translate(const char* english);
	}

	// 查表取中文；未收录的字符串原样返回英文（不影响功能）
	inline const char* LH(const char* english)
	{
		return Localization::Translate(english);
	}
}
