#include "common.hpp"
#include "core/commands/HotkeySystem.hpp"
#include "core/filemgr/FileMgr.hpp"
#include "core/lua/LuaScripts.hpp"
#include "core/frontend/Notifications.hpp"
#include "core/hooking/Hooking.hpp"
#include "core/memory/ModuleMgr.hpp"
#include "game/backend/PlayerDatabase.hpp"
#include "core/renderer/Renderer.hpp"
#include "core/settings/Settings.hpp"
#include "game/backend/FiberPool.hpp"
#include "game/backend/MapEditor/MapEditor.hpp"
#include "game/backend/Mods.hpp"
#include "game/backend/ScriptMgr.hpp"
#include "game/backend/NativeHooks.hpp"
#include "game/backend/SavedLocations.hpp"
#include "game/features/Features.hpp"
#include "game/frontend/GUI.hpp"
#include "game/frontend/Logo.hpp"
#include "game/pointers/Pointers.hpp"

#include <cstdio>
#include <filesystem>


namespace YimMenu
{
	// 菜单自己的文件夹统一放 C:\PeopleMenu（跟 Phantom Night 那类菜单一样，配置/日志/主题都在这儿），
	// C 盘不可写时再回退到 %APPDATA%\PeopleMenu，保证哪里都能跑。
	static std::filesystem::path ConfigDir()
	{
		std::error_code ec;
		auto root = std::filesystem::path("C:\\PeopleMenu");
		std::filesystem::create_directories(root, ec);
		if (!ec)
		{
			FILE* probe = nullptr;
			auto test = root / ".write_test";
			if (fopen_s(&probe, test.string().c_str(), "wb") == 0 && probe)
			{
				fclose(probe);
				std::filesystem::remove(test, ec);
				return root;
			}
		}

		const char* appdata = std::getenv("appdata");
		return appdata ? std::filesystem::path(appdata) / "PeopleMenu" : root;
	}

	// 同步写盘的启动日志：AsyncLogger 是异步的，进程被杀时缓冲区会丢，
	// 所以每一步都单独写一行并立刻 fflush，重启一次就能看出死在哪。
	static void BootLog(const char* msg)
	{
		static const auto dir = ConfigDir();

		std::error_code ec;
		std::filesystem::create_directories(dir, ec);
		auto file = dir / "boot.log";

		FILE* f = nullptr;
		if (fopen_s(&f, file.string().c_str(), "a") == 0 && f)
		{
			fprintf(f, "%s\n", msg);
			fflush(f);
			fclose(f);
		}
	}

	static DWORD Main(void*)
	{
		BootLog("== boot: DLL thread started ==");

		// 独立的配置目录：C:\PeopleMenu（不可写时自动落到 %APPDATA%\PeopleMenu）。
		// 旧的 HorseMenu 目录里留着别的版本的 settings.json / pattern_cache.bin，会直接把游戏带崩。
		const auto documents = ConfigDir();
		FileMgr::Init(documents);
		BootLog("step1: FileMgr ok");

		LogHelper::Init("Terminus", FileMgr::GetProjectFile("./cout.log"));
		BootLog("step2: LogHelper ok");

		std::unique_ptr<PlayerDatabase> PlayerDatabaseInstance;

		try
		{
		BootLog("step3: RegisterCommands");
		g_HotkeySystem.RegisterCommands();
		BootLog("step4: FetchSavedLocations");
		SavedLocations::FetchSavedLocations();
		BootLog("step5: Settings::Initialize");
		Settings::Initialize(FileMgr::GetProjectFile("./settings.json"));
		BootLog("step5b: Mods::Load");
		Mods::Load();
		BootLog("step6: ModuleMgr::LoadModules");

		if (!ModuleMgr.LoadModules())
		{
			BootLog("FAIL: LoadModules");
			return 1;
		}
		BootLog("step7: Pointers.Init (签名扫描)");

		if (!Pointers.Init())
		{
			BootLog("FAIL: Pointers.Init —— 游戏版本和菜单签名对不上，菜单已退出，游戏不受影响");
			return 1;
		}
		BootLog("step8: PlayerDatabase");

		PlayerDatabaseInstance = std::make_unique<PlayerDatabase>();
		BootLog("step9: Hooking::Init");

		Hooking::Init();
		BootLog("step10: Renderer::Init");

		if (!Renderer::Init())
		{
			BootLog("FAIL: Renderer::Init (DX12/Vulkan 挂钩失败)");
			return 1;
		}
		BootLog("step11: Pointers.LateInit");

		if (!Pointers.LateInit())
			LOG(WARNING) << "Failed to find some pointers";
		Hooking::LateInit();
		BootLog("step11b: Hooking::LateInit done");
		BootLog("step12: ScriptMgr::Init");

		ScriptMgr::Init();
		LOG(INFO) << "ScriptMgr initialized";
		BootLog("step13: FiberPool::Init");

		FiberPool::Init(5);
		LOG(INFO) << "FiberPool initialized";
		BootLog("step14: GUI::Init");

		GUI::Init();

		Logo::Init();

		ScriptMgr::AddScript(std::make_unique<Script>(&FeatureLoop));
		ScriptMgr::AddScript(std::make_unique<Script>(&BlockControlsForUI));
		ScriptMgr::AddScript(std::make_unique<Script>(&ContextMenuTick));
		ScriptMgr::AddScript(std::make_unique<Script>(&MapEditor::Update));
		ScriptMgr::AddScript(std::make_unique<Script>(&LuaScripts::Tick));

		Notifications::Show("人民万岁", "加载成功", NotificationType::Success);
		BootLog("OK: 菜单已加载，INSERT 开关");

#ifndef NDEBUG
		LOG(WARNING) << "Debug Build. Switch to RelWithDebInfo or Release build configurations to have a more stable experience.";
#endif
		}
		catch (const std::exception& e)
		{
			// 初始化里任何异常都不许把游戏带崩，记日志后安静退出
			LOG(INFO) << std::string("Init failed, menu unloaded: ") + e.what();
			BootLog(("FAIL: exception -> " + std::string(e.what())).c_str());
			return 1;
		}
		catch (...)
		{
			LOG(INFO) << "Init failed (unknown exception), menu unloaded";
			BootLog("FAIL: unknown exception");
			return 1;
		}

		while (g_Running)
		{
			Settings::Tick(); // TODO: move this somewhere else
		}

		LOG(INFO) << "Unloading";

		NativeHooks::Destroy();
		LOG(INFO) << "NativeHooks uninitialized";

		ScriptMgr::Destroy();
		LOG(INFO) << "ScriptMgr uninitialized";

		FiberPool::Destroy();
		LOG(INFO) << "FiberPool uninitialized";

		PlayerDatabaseInstance.reset();

		Hooking::Destroy();
		LOG(INFO) << "Hooking uninitialized";
		Renderer::Destroy();
		LOG(INFO) << "Renderer uninitialized";

		LOG(INFO) << "Goodbye!";
		LogHelper::Destroy();

		FreeLibraryAndExitThread(g_DllInstance, EXIT_SUCCESS);
		return EXIT_SUCCESS;
	}
}

BOOL WINAPI DllMain(HINSTANCE dllInstance, DWORD reason, void*)
{
	using namespace YimMenu;

	DisableThreadLibraryCalls(dllInstance);

	if (reason == DLL_PROCESS_ATTACH)
	{
		g_DllInstance = dllInstance;

		g_MainThread = CreateThread(nullptr, 0, Main, nullptr, 0, &g_MainThreadId);
	}
	return true;
}