﻿#include "Theme.hpp"

#include <cstdint>

namespace YimMenu::Theme
{
	// 原图不再编译进 DLL：主题图放在 <游戏目录>\themes\01.jpg..15.jpg（安装器释放），
	// 运行时用 WIC 读盘并上传 DX12 纹理，清晰度保持原图。
	bool BuiltinThemeJpeg(int, const std::uint8_t**, std::uint32_t*)
	{
		return false;
	}
}