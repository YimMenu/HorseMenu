﻿#include "Theme.hpp"
#include "core/renderer/Renderer.hpp"

#include <windows.h>
#include <wincodec.h>
#include <d3d12.h>
#include <filesystem>
#include <vector>
#include <string>
#include <cstdlib>
#include <cctype>
#include <cmath>
#include <atomic>
#include <mutex>
#include <thread>
#include <algorithm>

#pragma comment(lib, "windowscodecs.lib")
#pragma comment(lib, "ole32.lib")
#pragma comment(lib, "d3d12.lib")

namespace YimMenu::Theme
{
	struct ExtTheme
	{
		std::string name;
		std::wstring path;
		std::vector<std::uint8_t> grid;
	};

	static std::vector<ExtTheme> s_External;
	static std::string s_FolderInfo = "未找到 themes 文件夹";

	// 显示参数（设置里可调）
	static float s_Bright    = 1.00f;
	static float s_Alpha     = 1.00f;
	static float s_Blur      = 0.00f;
	static int s_ThemeIndex  = -1;

	// ---------------- 解码：WIC（系统自带，不引第三方库） ----------------
	static bool DecodeImage(const std::wstring& path, std::vector<std::uint8_t>& out, int& w, int& h)
	{
		IWICImagingFactory* factory = nullptr;
		IWICBitmapDecoder* decoder  = nullptr;
		IWICBitmapFrameDecode* frame = nullptr;
		IWICFormatConverter* conv   = nullptr;
		bool ok = false;

		do
		{
			HRESULT hr = CoCreateInstance(CLSID_WICImagingFactory,
			    nullptr,
			    CLSCTX_INPROC_SERVER,
			    __uuidof(IWICImagingFactory),
			    reinterpret_cast<LPVOID*>(&factory));
			if (FAILED(hr) || !factory)
				break;

			hr = factory->CreateDecoderFromFilename(path.c_str(), nullptr, GENERIC_READ, WICDecodeMetadataCacheOnLoad, &decoder);
			if (FAILED(hr) || !decoder)
				break;

			hr = decoder->GetFrame(0, &frame);
			if (FAILED(hr) || !frame)
				break;

			hr = factory->CreateFormatConverter(&conv);
			if (FAILED(hr) || !conv)
				break;

			hr = conv->Initialize(frame, GUID_WICPixelFormat32bppRGBA, WICBitmapDitherTypeNone, nullptr, 0.0, WICBitmapPaletteTypeCustom);
			if (FAILED(hr))
				break;

			UINT ww = 0, hh = 0;
			conv->GetSize(&ww, &hh);
			if (ww == 0 || hh == 0)
				break;

			const UINT stride = ww * 4;
			out.resize(static_cast<size_t>(stride) * hh);
			hr = conv->CopyPixels(nullptr, stride, static_cast<UINT>(out.size()), out.data());
			if (FAILED(hr))
				break;

			w  = static_cast<int>(ww);
			h  = static_cast<int>(hh);
			ok = true;
		} while (false);

		if (conv) conv->Release();
		if (frame) frame->Release();
		if (decoder) decoder->Release();
		if (factory) factory->Release();
		return ok;
	}

	// 任意尺寸 → cols×rows 色块网格（边缘渐隐，和内置主题一致的观感）
	static void DownsampleToGrid(const std::vector<std::uint8_t>& rgba, int w, int h, std::vector<std::uint8_t>& grid)
	{
		const int cols = BackdropCols();
		const int rows = BackdropRows();
		grid.assign(static_cast<size_t>(cols) * rows * 4, 0);

		for (int cy = 0; cy < rows; cy++)
		{
			for (int cx = 0; cx < cols; cx++)
			{
				const int x0 = cx * w / cols, x1 = std::max(x0 + 1, (cx + 1) * w / cols);
				const int y0 = cy * h / rows, y1 = std::max(y0 + 1, (cy + 1) * h / rows);
				std::size_t sr = 0, sg = 0, sb = 0, n = 0;
				for (int y = y0; y < y1 && y < h; y++)
				{
					for (int x = x0; x < x1 && x < w; x++)
					{
						const std::uint8_t* p = rgba.data() + (static_cast<std::size_t>(y) * w + x) * 4;
						sr += p[0];
						sg += p[1];
						sb += p[2];
						n++;
					}
				}
				if (!n)
					n = 1;

				const float nx = std::abs(cx / float(cols - 1) * 2.0f - 1.0f);
				const float ny = std::abs(cy / float(rows - 1) * 2.0f - 1.0f);
				const float d  = std::max(nx, ny);
				const int a    = d < 0.55f ? 238 : static_cast<int>(238 * std::pow(std::max(0.0f, 1.0f - (d - 0.55f) / 0.45f), 1.4f));

				std::uint8_t* q = grid.data() + (static_cast<std::size_t>(cy) * cols + cx) * 4;
				q[0] = static_cast<std::uint8_t>(sr / n);
				q[1] = static_cast<std::uint8_t>(sg / n);
				q[2] = static_cast<std::uint8_t>(sb / n);
				q[3] = static_cast<std::uint8_t>(a);
			}
		}
	}

	static void AddFolderThemes(const std::filesystem::path& folder, std::string& info, bool alwaysReport = false)
	{
		if (!std::filesystem::exists(folder))
			return;

		bool any = false;
		for (auto& entry : std::filesystem::directory_iterator(folder))
		{
			if (s_External.size() >= 60)
				break;
			if (!entry.is_regular_file())
				continue;

			std::string lower = entry.path().extension().string();
			std::transform(lower.begin(), lower.end(), lower.begin(), [](unsigned char c) { return static_cast<char>(::tolower(c)); });
			if (lower != ".jpg" && lower != ".jpeg" && lower != ".png" && lower != ".bmp")
				continue;

			// 01.jpg..15.jpg 是内置主题的原图（纹理用），不再重复列进"外部主题"
			const std::string stem = entry.path().stem().string();
			if (stem.size() <= 2 && !stem.empty() && std::all_of(stem.begin(), stem.end(), [](char c) { return c >= '0' && c <= '9'; }))
			{
				const int n = std::atoi(stem.c_str());
				if (n >= 1 && n <= BuiltinThemeCount())
					continue;
			}

			std::vector<std::uint8_t> pixels;
			int w = 0, h = 0;
			if (!DecodeImage(entry.path().wstring(), pixels, w, h))
				continue;

			ExtTheme t;
			t.name = entry.path().stem().string();
			t.path = entry.path().wstring();
			DownsampleToGrid(pixels, w, h, t.grid);
			s_External.push_back(std::move(t));
			any = true;
		}

		if ((any || alwaysReport) && info == "未找到 themes 文件夹")
			info = folder.string();
		else if (any)
			info += "  |  " + folder.string();
	}

	void LoadExternalThemes()
	{
		s_External.clear();
		s_FolderInfo = "未找到 themes 文件夹";

		// 游戏通常已初始化 COM，重复初始化返回 RPC_E_CHANGED_MODE 属正常
		CoInitializeEx(nullptr, COINIT_MULTITHREADED);

		// 主题只认 C:\PeopleMenu\themes（跟 dll、配置放同一个文件夹）；
		// 只有在 C 盘那份不存在时才回退到 %APPDATA%\PeopleMenu\themes，避免页面上出现两个路径。
		std::filesystem::path main = std::filesystem::path("C:\\PeopleMenu") / "themes";
		std::error_code ec0;
		bool mainOk = std::filesystem::exists(main, ec0);
		if (!mainOk)
		{
			const char* appdata = std::getenv("appdata");
			if (appdata)
			{
				auto folder = std::filesystem::path(appdata) / "PeopleMenu" / "themes";
				std::filesystem::create_directories(folder, ec0);
				main = folder;
				mainOk = std::filesystem::exists(main, ec0);
			}
		}
		if (mainOk)
			AddFolderThemes(main, s_FolderInfo, true);

		WCHAR exePath[MAX_PATH]{};
		if (GetModuleFileNameW(nullptr, exePath, MAX_PATH) && !mainOk)
		{
			auto dir = std::filesystem::path(exePath).parent_path();
			AddFolderThemes(dir / "themes", s_FolderInfo, true);
		}
	}

	int ExternalThemeCount()
	{
		return static_cast<int>(s_External.size());
	}

	const char* ExternalThemesFolder()
	{
		return s_FolderInfo.c_str();
	}

	// ==================== 原图纹理（DX12，异步上传，绝不阻塞渲染帧） ====================
	// 设计原则：渲染线程只做两件事——查一个原子标记、拿到句柄就画。
	// 解码/建资源/拷贝/等 fence 全部在独立线程 + 独立命令队列里完成，
	// 即使失败也只是"继续用色块"，不可能卡住游戏的渲染线程。
	static std::mutex s_TexMutex;
	static std::atomic<bool> s_TexBusy{false};
	static std::atomic<bool> s_TexDisabled{false}; // 出过一次显卡超时/设备丢失就彻底不再碰纹理
	static std::atomic<int> s_TexFailTheme{-1};

	// 上传完成的纹理等渲染线程来领（描述符只能在渲染线程写，绝不跨线程碰描述符堆）
	static std::atomic<ID3D12Resource*> s_PendingTex{nullptr};
	static std::atomic<int> s_PendingTheme{-1};

	// 纹理永不在运行中释放（释放正在被 GPU 用的纹理会把设备拖死），
	// 最多缓存 6 张，超过就不再上传，退回色块。
	static constexpr int kTexCacheMax = 6;
	static ID3D12Resource* s_TexList[kTexCacheMax] = {};
	static int s_TexCount                          = 0;

	// 每张纹理占用的 SRV 槽（保留槽里的最后 4 个），4 槽轮换保证不会覆盖还在飞的帧
	static constexpr int kTexSlots = 4;
	static unsigned s_SlotSeq      = 0;

	static bool s_UseTexture = true;

	void SetUseTexture(bool v) { s_UseTexture = v; }
	bool GetUseTexture() { return s_UseTexture; }

	// 主题原图在磁盘上的位置：内置主题读 themes\01.jpg..15.jpg，外部主题读扫描到的文件
	static std::wstring ThemeImagePath(int idx)
	{
		if (idx >= BuiltinThemeCount())
		{
			const int i = idx - BuiltinThemeCount();
			if (i >= 0 && i < static_cast<int>(s_External.size()))
				return s_External[static_cast<size_t>(i)].path;
			return std::wstring();
		}

		if (idx < 0)
			return std::wstring();

		wchar_t num[16]{};
		swprintf_s(num, L"%02d", idx + 1);

		std::vector<std::filesystem::path> bases;
		bases.emplace_back(std::filesystem::path("C:\\PeopleMenu") / "themes");
		if (const char* appdata = std::getenv("appdata"))
			bases.push_back(std::filesystem::path(appdata) / "PeopleMenu" / "themes");
		WCHAR exePath[MAX_PATH]{};
		if (GetModuleFileNameW(nullptr, exePath, MAX_PATH))
			bases.push_back(std::filesystem::path(exePath).parent_path() / "themes");

		const wchar_t* exts[] = {L".jpg", L".jpeg", L".png", L".bmp"};
		for (auto& base : bases)
		{
			for (auto ext : exts)
			{
				auto p = base / (std::wstring(num) + ext);
				std::error_code ec;
				if (std::filesystem::exists(p, ec))
					return p.wstring();
			}
		}
		return std::wstring();
	}

	static void DownscaleRGBA(std::vector<std::uint8_t>& px, int& w, int& h, int maxW)
	{
		if (w <= maxW)
			return;

		const int nw = maxW;
		const int nh = std::max(1, static_cast<int>(static_cast<long long>(h) * nw / w));
		std::vector<std::uint8_t> dst(static_cast<size_t>(nw) * nh * 4);

		for (int y = 0; y < nh; y++)
		{
			const int sy0 = y * h / nh, sy1 = std::max(sy0 + 1, (y + 1) * h / nh);
			for (int x = 0; x < nw; x++)
			{
				const int sx0 = x * w / nw, sx1 = std::max(sx0 + 1, (x + 1) * w / nw);
				unsigned sr = 0, sg = 0, sb = 0, n = 0;
				for (int yy = sy0; yy < sy1; yy++)
					for (int xx = sx0; xx < sx1; xx++)
					{
						const std::uint8_t* p = px.data() + (static_cast<size_t>(yy) * w + xx) * 4;
						sr += p[0];
						sg += p[1];
						sb += p[2];
						n++;
					}
				n = n ? n : 1;
				std::uint8_t* q = dst.data() + (static_cast<size_t>(y) * nw + x) * 4;
				q[0] = static_cast<std::uint8_t>(sr / n);
				q[1] = static_cast<std::uint8_t>(sg / n);
				q[2] = static_cast<std::uint8_t>(sb / n);
				q[3] = 255;
			}
		}

		px.swap(dst);
		w = nw;
		h = nh;
	}

	// 在高清纹理路上做磨砂：分离式盒式模糊，全部在后台线程算
	static void BoxBlurRGBA(std::uint8_t* px, int w, int h, int r)
	{
		if (r <= 0 || w < 2 || h < 2)
			return;
		r = std::min(r, w / 2);
		r = std::min(r, h / 2);

		std::vector<std::uint8_t> tmp(px, px + static_cast<size_t>(w) * h * 4);

		for (int y = 0; y < h; y++)
		{
			for (int c = 0; c < 3; c++)
			{
				const std::uint8_t* src = tmp.data() + static_cast<size_t>(y) * w * 4 + c;
				std::uint8_t* dst       = px + static_cast<size_t>(y) * w * 4 + c;
				long long sum           = 0;
				for (int x = -r; x <= r; x++)
				{
					const int xx = std::clamp(x, 0, w - 1);
					sum += src[static_cast<size_t>(xx) * 4];
				}
				const int cnt = r * 2 + 1;
				for (int x = 0; x < w; x++)
				{
					dst[static_cast<size_t>(x) * 4] = static_cast<std::uint8_t>(sum / cnt);
					sum -= src[static_cast<size_t>(std::clamp(x - r, 0, w - 1)) * 4];
					sum += src[static_cast<size_t>(std::clamp(x + r + 1, 0, w - 1)) * 4];
				}
			}
		}

		for (int x = 0; x < w; x++)
		{
			for (int c = 0; c < 3; c++)
			{
				const std::uint8_t* src = px + static_cast<size_t>(x) * 4 + c;
				std::uint8_t* dst       = tmp.data() + static_cast<size_t>(x) * 4 + c;
				long long sum           = 0;
				for (int y = -r; y <= r; y++)
					sum += src[static_cast<size_t>(std::clamp(y, 0, h - 1)) * w * 4];
				const int cnt = r * 2 + 1;
				for (int y = 0; y < h; y++)
				{
					dst[static_cast<size_t>(y) * w * 4] = static_cast<std::uint8_t>(sum / cnt);
					sum -= src[static_cast<size_t>(std::clamp(y - r, 0, h - 1)) * w * 4];
					sum += src[static_cast<size_t>(std::clamp(y + r + 1, 0, h - 1)) * w * 4];
				}
			}
		}

		std::memcpy(px, tmp.data(), static_cast<size_t>(w) * h * 4);
	}

	// 独立线程里的上传流程：自己的队列、自己的分配器、自己的 fence
	static void UploadTextureWorker(int themeIdx, std::wstring path, int blurPx)
	{
		auto finish = [&](bool ok) {
			if (!ok)
			{
				LOG(INFO) << "Theme: async upload failed, block fallback for theme " << themeIdx;
				s_TexFailTheme = themeIdx;
			}
			s_TexBusy = false;
		};

		ID3D12Device* dev = Renderer::GetDX12Device();
		ID3D12DescriptorHeap* srvHeap = Renderer::GetDX12SrvHeap();
		if (!dev || !srvHeap)
		{
			finish(false);
			return;
		}

		std::vector<std::uint8_t> pixels;
		int w = 0, h = 0;
		if (!DecodeImage(path, pixels, w, h))
		{
			finish(false);
			return;
		}

		DownscaleRGBA(pixels, w, h, 1920);
		if (blurPx > 0)
			BoxBlurRGBA(pixels.data(), w, h, blurPx);

		ID3D12CommandQueue* queue = nullptr;
		D3D12_COMMAND_QUEUE_DESC qd{};
		qd.Type     = D3D12_COMMAND_LIST_TYPE_DIRECT;
		qd.Priority = D3D12_COMMAND_QUEUE_PRIORITY_NORMAL;
		if (FAILED(dev->CreateCommandQueue(&qd, IID_PPV_ARGS(&queue)) ) || !queue)
		{
			finish(false);
			return;
		}

		D3D12_RESOURCE_DESC desc{};
		desc.Dimension        = D3D12_RESOURCE_DIMENSION_TEXTURE2D;
		desc.Width            = static_cast<UINT64>(w);
		desc.Height           = static_cast<UINT>(h);
		desc.DepthOrArraySize = 1;
		desc.MipLevels        = 1;
		desc.Format           = DXGI_FORMAT_R8G8B8A8_UNORM;
		desc.SampleDesc.Count = 1;
		desc.Layout           = D3D12_TEXTURE_LAYOUT_UNKNOWN;
		desc.Flags            = D3D12_RESOURCE_FLAG_NONE;

		D3D12_HEAP_PROPERTIES defHeap{};
		defHeap.Type = D3D12_HEAP_TYPE_DEFAULT;

		D3D12_HEAP_PROPERTIES upHeap{};
		upHeap.Type = D3D12_HEAP_TYPE_UPLOAD;

		ID3D12Resource* tex    = nullptr;
		ID3D12Resource* upload = nullptr;
		ID3D12CommandAllocator* alloc = nullptr;
		ID3D12GraphicsCommandList* list = nullptr;
		ID3D12Fence* fence = nullptr;
		HANDLE evt = nullptr;
		bool ok = false;

		do
		{
			HRESULT hr = dev->CreateCommittedResource(&defHeap, D3D12_HEAP_FLAG_NONE, &desc, D3D12_RESOURCE_STATE_COPY_DEST, nullptr, IID_PPV_ARGS(&tex));
			if (FAILED(hr) || !tex)
			{
				LOG(INFO) << "Theme: CreateCommittedResource(tex) hr=" << (long)hr;
				break;
			}

			D3D12_PLACED_SUBRESOURCE_FOOTPRINT layout{};
			UINT rows = 0;
			UINT64 rowSize = 0, totalBytes = 0;
			dev->GetCopyableFootprints(&desc, 0, 1, 0, &layout, &rows, &rowSize, &totalBytes);

			// 上传资源必须是 BUFFER + ROW_MAJOR，不能照抄纹理描述（否则 E_INVALIDARG）
			D3D12_RESOURCE_DESC bufDesc{};
			bufDesc.Dimension        = D3D12_RESOURCE_DIMENSION_BUFFER;
			bufDesc.Width            = totalBytes;
			bufDesc.Height           = 1;
			bufDesc.DepthOrArraySize = 1;
			bufDesc.MipLevels        = 1;
			bufDesc.Format           = DXGI_FORMAT_UNKNOWN;
			bufDesc.SampleDesc.Count = 1;
			bufDesc.Layout           = D3D12_TEXTURE_LAYOUT_ROW_MAJOR;

			hr = dev->CreateCommittedResource(&upHeap, D3D12_HEAP_FLAG_NONE, &bufDesc, D3D12_RESOURCE_STATE_GENERIC_READ, nullptr, IID_PPV_ARGS(&upload));
			if (FAILED(hr) || !upload)
			{
				LOG(INFO) << "Theme: CreateCommittedResource(upload) hr=" << (long)hr;
				break;
			}

			void* mapped = nullptr;
			hr = upload->Map(0, nullptr, &mapped);
			if (FAILED(hr) || !mapped)
			{
				LOG(INFO) << "Theme: Map(upload) hr=" << (long)hr;
				break;
			}
			for (int y = 0; y < h; y++)
				memcpy(reinterpret_cast<std::uint8_t*>(mapped) + layout.Offset + static_cast<size_t>(y) * layout.Footprint.RowPitch,
				    pixels.data() + static_cast<size_t>(y) * w * 4,
				    static_cast<size_t>(w) * 4);
			upload->Unmap(0, nullptr);

			hr = dev->CreateCommandAllocator(D3D12_COMMAND_LIST_TYPE_DIRECT, IID_PPV_ARGS(&alloc));
			if (FAILED(hr) || !alloc)
			{
				LOG(INFO) << "Theme: CreateCommandAllocator hr=" << (long)hr;
				break;
			}

			hr = dev->CreateCommandList(0, D3D12_COMMAND_LIST_TYPE_DIRECT, alloc, nullptr, IID_PPV_ARGS(&list));
			if (FAILED(hr) || !list)
			{
				LOG(INFO) << "Theme: CreateCommandList hr=" << (long)hr;
				break;
			}

			D3D12_TEXTURE_COPY_LOCATION srcLoc{};
			srcLoc.pResource       = upload;
			srcLoc.Type            = D3D12_TEXTURE_COPY_TYPE_PLACED_FOOTPRINT;
			srcLoc.PlacedFootprint = layout;

			D3D12_TEXTURE_COPY_LOCATION dstLoc{};
			dstLoc.pResource        = tex;
			dstLoc.Type             = D3D12_TEXTURE_COPY_TYPE_SUBRESOURCE_INDEX;
			dstLoc.SubresourceIndex = 0;
			list->CopyTextureRegion(&dstLoc, 0, 0, 0, &srcLoc, nullptr);

			D3D12_RESOURCE_BARRIER barrier{};
			barrier.Type                   = D3D12_RESOURCE_BARRIER_TYPE_TRANSITION;
			barrier.Transition.pResource   = tex;
			barrier.Transition.Subresource = D3D12_RESOURCE_BARRIER_ALL_SUBRESOURCES;
			barrier.Transition.StateBefore = D3D12_RESOURCE_STATE_COPY_DEST;
			barrier.Transition.StateAfter  = D3D12_RESOURCE_STATE_PIXEL_SHADER_RESOURCE;
			list->ResourceBarrier(1, &barrier);

			hr = list->Close();
			if (FAILED(hr))
			{
				LOG(INFO) << "Theme: Close(list) hr=" << (long)hr;
				break;
			}

			ID3D12CommandList* lists[] = {list};
			queue->ExecuteCommandLists(1, lists);

			if (FAILED(dev->CreateFence(0, D3D12_FENCE_FLAG_NONE, IID_PPV_ARGS(&fence)) ) || !fence)
			{
				LOG(INFO) << "Theme: CreateFence failed";
				break;
			}
			evt = CreateEventA(nullptr, FALSE, FALSE, nullptr);
			if (!evt)
			{
				LOG(INFO) << "Theme: CreateEvent failed";
				break;
			}

			hr = queue->Signal(fence, 1);
			if (FAILED(hr))
			{
				LOG(INFO) << "Theme: queue Signal hr=" << (long)hr;
				break;
			}

			fence->SetEventOnCompletion(1, evt);
			const DWORD wr = WaitForSingleObject(evt, 5000);
			if (wr != WAIT_OBJECT_0)
			{
				LOG(INFO) << "Theme: fence wait=" << wr << ", texture path disabled";
				s_TexDisabled = true;
				break;
			}

			// 只把纹理交给渲染线程，描述符由渲染线程自己写（跨线程写描述符堆会直接把设备搞挂）
			{
				std::lock_guard<std::mutex> lk(s_TexMutex);
				if (s_TexCount >= kTexCacheMax)
				{
					LOG(INFO) << "Theme: texture cache full, fallback blocks";
					break;
				}
				s_TexList[s_TexCount++] = tex;
			}

			s_PendingTheme = themeIdx;
			s_PendingTex   = tex;
			LOG(INFO) << "Theme: async texture ready " << w << "x" << h << " theme " << themeIdx;
			ok = true;
		} while (false);

		if (list) list->Release();
		if (alloc) alloc->Release();
		if (fence) fence->Release();
		if (evt) CloseHandle(evt);
		if (upload) upload->Release();
		if (!ok && tex)
			tex->Release();
		if (queue) queue->Release();

		finish(ok);
	}

	// 已建好描述符的主题句柄（只在渲染线程读写）
	// 每张纹理固定占一个轮换槽，4 槽轮换，不会被连续帧覆盖
	struct TexSlotEntry
	{
		int   theme = -1;
		UINT  slot  = 0;
		ImTextureID id = 0;
		bool  used  = false;
	};
	static TexSlotEntry s_TexSlots[kTexCacheMax];

	// 渲染线程：把后台线程上传好的纹理换成 ImGui 可用的句柄
	static ImTextureID PublishPendingTexture()
	{
		ID3D12Resource* tex = s_PendingTex.load();
		const int idx = s_PendingTheme.load();
		if (!tex || idx < 0)
			return 0;

		ID3D12Device* dev = Renderer::GetDX12Device();
		ID3D12DescriptorHeap* srvHeap = Renderer::GetDX12SrvHeap();
		if (!dev || !srvHeap)
			return 0;

		if (FAILED(dev->GetDeviceRemovedReason()))
		{
			s_PendingTex = nullptr;
			s_PendingTheme = -1;
			s_TexFailTheme = idx;
			s_TexDisabled = true;
			LOG(INFO) << "Theme: device removed, texture disabled";
			return 0;
		}

		// 槽位只取"保留区"的最后 4 个，并严格按堆的真实大小夹住，绝不越界写描述符
		const UINT heapSize = srvHeap->GetDesc().NumDescriptors;
		if (heapSize < static_cast<UINT>(kTexSlots + 1))
		{
			s_PendingTex = nullptr;
			s_PendingTheme = -1;
			s_TexFailTheme = idx;
			LOG(INFO) << "Theme: srv heap too small for theme texture";
			return 0;
		}

		const UINT base = heapSize - static_cast<UINT>(kTexSlots);
		int freeIndex = -1;
		for (int i = 0; i < kTexCacheMax; i++)
		{
			if (!s_TexSlots[i].used)
			{
				freeIndex = i;
				break;
			}
		}
		if (freeIndex < 0)
			return 0;

		const UINT slot = base + static_cast<UINT>(s_SlotSeq % static_cast<unsigned>(kTexSlots));
		s_SlotSeq++;

		const UINT inc = dev->GetDescriptorHandleIncrementSize(D3D12_DESCRIPTOR_HEAP_TYPE_CBV_SRV_UAV);
		D3D12_CPU_DESCRIPTOR_HANDLE cpu = srvHeap->GetCPUDescriptorHandleForHeapStart();
		cpu.ptr += inc * slot;

		D3D12_SHADER_RESOURCE_VIEW_DESC srv{};
		srv.Format                  = DXGI_FORMAT_R8G8B8A8_UNORM;
		srv.ViewDimension           = D3D12_SRV_DIMENSION_TEXTURE2D;
		srv.Shader4ComponentMapping = D3D12_DEFAULT_SHADER_4_COMPONENT_MAPPING;
		srv.Texture2D.MipLevels     = 1;
		dev->CreateShaderResourceView(tex, &srv, cpu);

		D3D12_GPU_DESCRIPTOR_HANDLE gpu = srvHeap->GetGPUDescriptorHandleForHeapStart();
		gpu.ptr += inc * slot;

		s_TexSlots[freeIndex].theme = idx;
		s_TexSlots[freeIndex].slot  = slot;
		s_TexSlots[freeIndex].id    = reinterpret_cast<ImTextureID>(static_cast<UINT_PTR>(gpu.ptr));
		s_TexSlots[freeIndex].used  = true;

		s_PendingTex   = nullptr;
		s_PendingTheme = -1;
		LOG(INFO) << "Theme: texture published theme " << idx;
		return s_TexSlots[freeIndex].id;
	}

	// 渲染线程只调这个：命中就直接返回句柄，没命中就触发一次后台任务并返回 0
	static ImTextureID TextureForTheme(int idx)
	{
		if (!s_UseTexture || s_TexDisabled.load() || !Renderer::IsDX12Backend())
			return 0;

		for (int i = 0; i < kTexCacheMax; i++)
			if (s_TexSlots[i].used && s_TexSlots[i].theme == idx)
				return s_TexSlots[i].id;

		if (s_TexFailTheme.load() == idx)
			return 0;

		PublishPendingTexture();
		for (int i = 0; i < kTexCacheMax; i++)
			if (s_TexSlots[i].used && s_TexSlots[i].theme == idx)
				return s_TexSlots[i].id;

		if (s_TexBusy.load())
			return 0;

		const std::wstring path = ThemeImagePath(idx);
		if (path.empty())
		{
			s_TexFailTheme = idx;
			return 0;
		}

		if (s_TexBusy.exchange(true))
			return 0;

		const int blurPx = static_cast<int>(s_Blur * 8.0f);
		std::thread(UploadTextureWorker, idx, path, blurPx).detach();
		return 0;
	}

	// ---------------- 统一索引 ----------------
	int ThemeCount()
	{
		return BuiltinThemeCount() + static_cast<int>(s_External.size());
	}

	const char* ThemeName(int idx)
	{
		if (idx < 0)
			idx = GetTheme();
		if (idx < BuiltinThemeCount())
			return BuiltinThemeName(idx);
		const int i = idx - BuiltinThemeCount();
		if (i >= 0 && i < static_cast<int>(s_External.size()))
			return s_External[static_cast<size_t>(i)].name.c_str();
		return BuiltinThemeName(DefaultThemeIndex());
	}

	const std::uint8_t* ThemeGrid(int idx)
	{
		if (idx < 0)
			idx = GetTheme();
		if (idx < BuiltinThemeCount())
			return BuiltinThemeGrid(idx);
		const int i = idx - BuiltinThemeCount();
		if (i >= 0 && i < static_cast<int>(s_External.size()))
			return s_External[static_cast<size_t>(i)].grid.data();
		return BuiltinThemeGrid(DefaultThemeIndex());
	}

	int GetTheme()
	{
		if (s_ThemeIndex < 0)
			s_ThemeIndex = DefaultThemeIndex();
		if (s_ThemeIndex >= ThemeCount())
			s_ThemeIndex = DefaultThemeIndex();
		return s_ThemeIndex;
	}

	void SetTheme(int idx)
	{
		if (idx < 0 || idx >= ThemeCount())
			return;
		s_ThemeIndex = idx;
	}

	float GetBrightness() { return s_Bright; }
	void SetBrightness(float v) { s_Bright = std::clamp(v, 0.6f, 1.8f); }
	float GetBackdropAlpha() { return s_Alpha; }
	void SetBackdropAlpha(float v) { s_Alpha = std::clamp(v, 0.0f, 1.0f); }
	float GetBlur() { return s_Blur; }
	void SetBlur(float v) { s_Blur = std::clamp(v, 0.0f, 3.0f); }

	// ---------------- 样式 ----------------
	void ApplyGlassStyle()
	{
		ImGuiStyle& style = ImGui::GetStyle();

		style.Colors[ImGuiCol_Text]                 = ImVec4(0.878f, 0.894f, 0.922f, 1.00f);
		style.Colors[ImGuiCol_TextDisabled]         = ImVec4(0.573f, 0.596f, 0.635f, 1.00f);
		style.Colors[ImGuiCol_WindowBg]             = ImVec4(0.020f, 0.024f, 0.033f, 0.40f); // 暗底，主题图才透得出来
		style.Colors[ImGuiCol_ChildBg]              = ImVec4(1.000f, 1.000f, 1.000f, 0.045f);
		style.Colors[ImGuiCol_PopupBg]              = ImVec4(0.050f, 0.058f, 0.072f, 0.95f);
		style.Colors[ImGuiCol_Border]               = ImVec4(1.000f, 1.000f, 1.000f, 0.13f);
		style.Colors[ImGuiCol_BorderShadow]         = ImVec4(0.000f, 0.000f, 0.000f, 0.00f);
		style.Colors[ImGuiCol_FrameBg]              = ImVec4(0.000f, 0.000f, 0.000f, 0.28f);
		style.Colors[ImGuiCol_FrameBgHovered]       = ImVec4(1.000f, 1.000f, 1.000f, 0.10f);
		style.Colors[ImGuiCol_FrameBgActive]        = ImVec4(1.000f, 1.000f, 1.000f, 0.16f);
		style.Colors[ImGuiCol_TitleBg]              = ImVec4(0.000f, 0.000f, 0.000f, 0.00f);
		style.Colors[ImGuiCol_TitleBgActive]        = ImVec4(0.000f, 0.000f, 0.000f, 0.00f);
		style.Colors[ImGuiCol_TitleBgCollapsed]     = ImVec4(0.000f, 0.000f, 0.000f, 0.00f);
		style.Colors[ImGuiCol_MenuBarBg]            = ImVec4(0.000f, 0.000f, 0.000f, 0.00f);
		style.Colors[ImGuiCol_ScrollbarBg]          = ImVec4(1.000f, 1.000f, 1.000f, 0.03f);
		style.Colors[ImGuiCol_ScrollbarGrab]        = ImVec4(1.000f, 1.000f, 1.000f, 0.16f);
		style.Colors[ImGuiCol_ScrollbarGrabHovered] = ImVec4(1.000f, 1.000f, 1.000f, 0.24f);
		style.Colors[ImGuiCol_ScrollbarGrabActive]  = ImVec4(1.000f, 1.000f, 1.000f, 0.32f);
		style.Colors[ImGuiCol_CheckMark]            = ImVec4(0.969f, 0.690f, 0.369f, 1.00f);
		style.Colors[ImGuiCol_SliderGrab]           = ImVec4(0.969f, 0.690f, 0.369f, 0.90f);
		style.Colors[ImGuiCol_SliderGrabActive]     = ImVec4(1.000f, 0.820f, 0.600f, 1.00f);
		style.Colors[ImGuiCol_Button]               = ImVec4(1.000f, 1.000f, 1.000f, 0.09f);
		style.Colors[ImGuiCol_ButtonHovered]        = ImVec4(1.000f, 1.000f, 1.000f, 0.16f);
		style.Colors[ImGuiCol_ButtonActive]         = ImVec4(1.000f, 1.000f, 1.000f, 0.22f);
		style.Colors[ImGuiCol_Header]               = ImVec4(0.969f, 0.690f, 0.369f, 0.18f);
		style.Colors[ImGuiCol_HeaderHovered]        = ImVec4(1.000f, 1.000f, 1.000f, 0.10f);
		style.Colors[ImGuiCol_HeaderActive]         = ImVec4(0.969f, 0.690f, 0.369f, 0.26f);
		style.Colors[ImGuiCol_Separator]            = style.Colors[ImGuiCol_Border];
		style.Colors[ImGuiCol_SeparatorHovered]     = ImVec4(0.969f, 0.690f, 0.369f, 0.40f);
		style.Colors[ImGuiCol_SeparatorActive]      = ImVec4(0.969f, 0.690f, 0.369f, 0.70f);
		style.Colors[ImGuiCol_ResizeGrip]           = ImVec4(0.000f, 0.000f, 0.000f, 0.00f);
		style.Colors[ImGuiCol_ResizeGripHovered]    = ImVec4(0.969f, 0.690f, 0.369f, 0.35f);
		style.Colors[ImGuiCol_ResizeGripActive]     = ImVec4(0.969f, 0.690f, 0.369f, 0.65f);
		style.Colors[ImGuiCol_Tab]                  = ImVec4(1.000f, 1.000f, 1.000f, 0.06f);
		style.Colors[ImGuiCol_TabHovered]           = ImVec4(1.000f, 1.000f, 1.000f, 0.14f);
		style.Colors[ImGuiCol_TabActive]            = ImVec4(0.969f, 0.690f, 0.369f, 0.20f);
		style.Colors[ImGuiCol_TabUnfocused]         = ImVec4(1.000f, 1.000f, 1.000f, 0.05f);
		style.Colors[ImGuiCol_TabUnfocusedActive]   = ImVec4(1.000f, 1.000f, 1.000f, 0.10f);
		style.Colors[ImGuiCol_PlotLines]            = ImVec4(0.800f, 0.820f, 0.850f, 1.00f);
		style.Colors[ImGuiCol_PlotLinesHovered]     = ImVec4(1.000f, 0.600f, 0.350f, 1.00f);
		style.Colors[ImGuiCol_PlotHistogram]        = ImVec4(0.969f, 0.690f, 0.369f, 1.00f);
		style.Colors[ImGuiCol_PlotHistogramHovered] = ImVec4(1.000f, 0.820f, 0.600f, 1.00f);
		style.Colors[ImGuiCol_TextSelectedBg]       = ImVec4(0.969f, 0.690f, 0.369f, 0.25f);
		style.Colors[ImGuiCol_DragDropTarget]       = ImVec4(0.969f, 0.690f, 0.369f, 1.00f);
		style.Colors[ImGuiCol_NavHighlight]         = ImVec4(0.969f, 0.690f, 0.369f, 1.00f);
		style.Colors[ImGuiCol_NavWindowingHighlight]= ImVec4(1.000f, 1.000f, 1.000f, 0.70f);
		style.Colors[ImGuiCol_NavWindowingDimBg]    = ImVec4(0.000f, 0.000f, 0.000f, 0.25f);
		style.Colors[ImGuiCol_ModalWindowDimBg]     = ImVec4(0.000f, 0.000f, 0.000f, 0.55f);

		style.WindowRounding    = 16.0f;
		style.ChildRounding     = 14.0f;
		style.FrameRounding     = 8.0f;
		style.PopupRounding     = 12.0f;
		style.ScrollbarRounding = 8.0f;
		style.GrabRounding      = 6.0f;
		style.TabRounding       = 10.0f;

		style.WindowBorderSize = 1.0f;
		style.ChildBorderSize  = 1.0f;
		style.FrameBorderSize  = 0.0f;
		style.PopupBorderSize  = 1.0f;

		style.WindowPadding    = ImVec2(16.0f, 14.0f);
		style.FramePadding     = ImVec2(10.0f, 6.0f);
		style.ItemSpacing      = ImVec2(10.0f, 8.0f);
		style.ItemInnerSpacing = ImVec2(8.0f, 6.0f);
		style.ScrollbarSize    = 12.0f;
		style.GrabMinSize      = 10.0f;

		style.AntiAliasedLines = true;
		style.AntiAliasedFill  = true;
	}

	// ---------------- 绘制背景 ----------------
	void DrawBackdrop(ImVec2 pos, ImVec2 size, float alpha)
	{
		if (size.x < 8.0f || size.y < 8.0f || s_Alpha <= 0.01f)
			return;

		const std::uint8_t* grid = ThemeGrid(GetTheme());
		const int cols           = BackdropCols();
		const int rows           = BackdropRows();
		if (!grid || cols <= 1 || rows <= 1)
			return;

		const float inset = 3.0f;
		ImVec2 p0(pos.x + inset, pos.y + inset);
		ImVec2 p1(pos.x + size.x - inset, pos.y + size.y - inset);

		ImDrawList* dl = ImGui::GetBackgroundDrawList();

		// 优先用真正的原图纹理（DX12），这样 4K 主题图不会被压成色块
		if (const ImTextureID texId = TextureForTheme(GetTheme()))
		{
			const float k = alpha * s_Alpha;
			ImU32 tint    = IM_COL32(255, 255, 255, static_cast<int>(k * 255));
			if (s_Bright < 1.0f)
			{
				const float d = s_Bright;
				tint          = IM_COL32(static_cast<int>(255 * d), static_cast<int>(255 * d), static_cast<int>(255 * d), static_cast<int>(k * 255));
			}
			dl->AddImageRounded(texId, p0, p1, ImVec2(0.0f, 0.0f), ImVec2(1.0f, 1.0f), tint, 15.0f);
			if (s_Bright > 1.0f)
			{
				const int wa = static_cast<int>(std::min(120.0f, (s_Bright - 1.0f) * 110.0f) * k);
				dl->AddRectFilled(p0, p1, IM_COL32(255, 255, 255, wa), 15.0f);
			}
			return;
		}

		const float cw = (p1.x - p0.x) / cols;
		const float ch = (p1.y - p0.y) / rows;

		const float bright = s_Bright;
		const int radius   = static_cast<int>(s_Blur * 1.5f);

		auto sample = [&](int x, int y, int out[4]) {
			std::int32_t sr = 0, sg = 0, sb = 0, sa = 0, n = 0;
			const int x0 = std::max(0, x - radius), x1 = std::min(cols - 1, x + radius);
			const int y0 = std::max(0, y - radius), y1 = std::min(rows - 1, y + radius);
			for (int yy = y0; yy <= y1; yy++)
			{
				for (int xx = x0; xx <= x1; xx++)
				{
					const std::uint8_t* p = grid + (static_cast<std::size_t>(yy) * cols + xx) * 4;
					sr += p[0];
					sg += p[1];
					sb += p[2];
					sa += p[3];
					n++;
				}
			}
			n              = n ? n : 1;
			out[0]         = static_cast<int>(sr / n);
			out[1]         = static_cast<int>(sg / n);
			out[2]         = static_cast<int>(sb / n);
			out[3]         = static_cast<int>(sa / n);
		};

		auto col = [&](int r, int g, int b, int a) {
			const float k = alpha * s_Alpha * (a / 255.0f);
			r = std::min(255, static_cast<int>(r * bright));
			g = std::min(255, static_cast<int>(g * bright));
			b = std::min(255, static_cast<int>(b * bright));
			return IM_COL32(r, g, b, static_cast<int>(k * 255));
		};

		for (int cy = 0; cy < rows - 1; cy++)
		{
			for (int cx = 0; cx < cols - 1; cx++)
			{
				int c00[4], c10[4], c11[4], c01[4];
				sample(cx, cy, c00);
				sample(cx + 1, cy, c10);
				sample(cx + 1, cy + 1, c11);
				sample(cx, cy + 1, c01);

				ImVec2 a(p0.x + cx * cw, p0.y + cy * ch);
				ImVec2 b(p0.x + (cx + 1) * cw, p0.y + (cy + 1) * ch);
				dl->AddRectFilledMultiColor(a,
				    b,
				    col(c00[0], c00[1], c00[2], c00[3]),
				    col(c10[0], c10[1], c10[2], c10[3]),
				    col(c11[0], c11[1], c11[2], c11[3]),
				    col(c01[0], c01[1], c01[2], c01[3]));
			}
		}
	}
}
