#include "Menu.hpp"

#include "core/commands/Commands.hpp"
#include "core/frontend/manager/UIManager.hpp"
#include "core/renderer/Renderer.hpp"
#include "game/backend/FiberPool.hpp"
#include "game/backend/ScriptMgr.hpp"
#include "game/frontend/Logo.hpp"
#include "game/frontend/Theme.hpp"
#include "game/frontend/fonts/Fonts.hpp"
#include "game/pointers/Pointers.hpp"
#include "submenus/Debug.hpp"
#include "submenus/ModPacks.hpp"
#include "submenus/Network.hpp"
#include "submenus/Players.hpp"
#include "submenus/Self.hpp"
#include "submenus/Scripts.hpp"
#include "submenus/Settings.hpp"
#include "submenus/Teleport.hpp"
#include "submenus/World.hpp"
#include "submenus/Recovery.hpp"
#include "core/frontend/Localization.hpp"

namespace YimMenu
{
	void Menu::Init()
	{
		// Arguably the only place this file should be edited at for more menus
		UIManager::AddSubmenu(std::make_shared<Submenus::Self>());
		UIManager::AddSubmenu(std::make_shared<Submenus::Teleport>());
		UIManager::AddSubmenu(std::make_shared<Submenus::Network>());
		UIManager::AddSubmenu(std::make_shared<Submenus::Players>());
		UIManager::AddSubmenu(std::make_shared<Submenus::World>());
		UIManager::AddSubmenu(std::make_shared<Submenus::ModPacks>());
		UIManager::AddSubmenu(std::make_shared<Submenus::Scripts>());
		UIManager::AddSubmenu(std::make_shared<Submenus::Recovery>());
		UIManager::AddSubmenu(std::make_shared<Submenus::Settings>());
		UIManager::AddSubmenu(std::make_shared<Submenus::Debug>());

		Renderer::AddRendererCallBack(
		    [&] {
			    if (!GUI::IsOpen())
				    return;

			    ImGui::PushFont(Menu::Font::g_DefaultFont);

			    // 主题背景图：绘制在窗口内容之下，毛玻璃面板半透明可透出画面
			    static ImVec2 s_LastPos{-1.0f, -1.0f};
			    static ImVec2 s_LastSize{-1.0f, -1.0f};
			    if (s_LastSize.x > 1.0f)
				    Theme::DrawBackdrop(s_LastPos, s_LastSize, 1.0f);

			    // Think this add HTML&PHP with no CSS. Lol just for testing.
			    ImGui::SetNextWindowSize(ImVec2((*Pointers.ScreenResX / 2.5), (*Pointers.ScreenResY / 2.5)), ImGuiCond_Once);
			    if (ImGui::Begin("人民万岁菜单", nullptr, ImGuiWindowFlags_NoDecoration))
			    {
				    s_LastPos  = ImGui::GetWindowPos();
				    s_LastSize = ImGui::GetWindowSize();

				    {
					    ImTextureID logo = Logo::Tex();
					    if (logo)
					    {
						    ImGui::Image(logo, ImVec2(44.0f, 44.0f));
						    ImGui::SameLine();
					    }
					    ImGui::AlignTextToFramePadding();
					    ImGui::Text("人民万岁菜单");
				    }
				    ImGui::Spacing();

				    //ImGui::BeginDisabled(*Pointers.IsSessionStarted);
				    if (ImGui::Button(LH("Unload"), ImVec2(120, 0)))
				    {
					    if (ScriptMgr::CanTick())
					    {
						    FiberPool::Push([] {
							    Commands::Shutdown();
							    g_Running = false;
						    });
					    }
					    else
					    {
						    g_Running = false;
					    }
				    }
				    //ImGui::EndDisabled();

				    UIManager::Draw();

				    ImGui::End();
			    }

			    ImGui::PopFont();
		    },
		    -1);
	}

	void Menu::SetupStyle()
	{
		// 半透明毛玻璃 + 圆角卡片 + 琥珀强调色（实现见 Theme.cpp）
		Theme::ApplyGlassStyle();

		// 首次进来时扫一遍 themes 文件夹（%APPDATA%\PeopleMenu\themes、游戏目录\themes）
		static bool s_ThemesLoaded = false;
		if (!s_ThemesLoaded)
		{
			Theme::LoadExternalThemes();
			s_ThemesLoaded = true;
		}
	}

	void Menu::SetupFonts()
	{
		auto& IO = ImGui::GetIO();
		ImFontConfig FontCfg{};
		FontCfg.FontDataOwnedByAtlas = false;
		FontCfg.GlyphRanges          = Fonts::ChineseGlyphRanges; // 中文字形范围

		Menu::Font::g_DefaultFont = IO.Fonts->AddFontFromMemoryTTF(const_cast<std::uint8_t*>(Fonts::ChineseFont), Fonts::ChineseFontLen, Menu::Font::g_DefaultFontSize, &FontCfg);
		Menu::Font::g_OptionsFont = IO.Fonts->AddFontFromMemoryTTF(const_cast<std::uint8_t*>(Fonts::ChineseFont), Fonts::ChineseFontLen, Menu::Font::g_OptionsFontSize, &FontCfg);
		Menu::Font::g_ChildTitleFont = IO.Fonts->AddFontFromMemoryTTF(const_cast<std::uint8_t*>(Fonts::ChineseFont), Fonts::ChineseFontLen, Menu::Font::g_ChildTitleFontSize, &FontCfg);
		Menu::Font::g_ChatFont = IO.Fonts->AddFontFromMemoryTTF(const_cast<std::uint8_t*>(Fonts::ChineseFont), Fonts::ChineseFontLen, Menu::Font::g_ChatFontSize, &FontCfg);
		Menu::Font::g_OverlayFont = IO.Fonts->AddFontFromMemoryTTF(const_cast<std::uint8_t*>(Fonts::ChineseFont), Fonts::ChineseFontLen, Menu::Font::g_OverlayFontSize, &FontCfg);
		UIManager::SetOptionsFont(Menu::Font::g_OptionsFont);
	}
}
