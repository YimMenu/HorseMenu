#include "Logo.hpp"

#include "core/renderer/Renderer.hpp"

#include <windows.h>
#include <wincodec.h>
#include <d3d12.h>
#include <atomic>
#include <cstdlib>
#include <filesystem>
#include <string>
#include <thread>
#include <vector>

#pragma comment(lib, "windowscodecs.lib")
#pragma comment(lib, "ole32.lib")
#pragma comment(lib, "d3d12.lib")

namespace YimMenu::Logo
{
	namespace
	{
		std::atomic<ID3D12Resource*> s_Pending{nullptr};
		std::atomic_bool s_Tried{false};
		ImTextureID s_ReadyId = 0;
		ID3D12Resource* s_Held = nullptr; // 纹理常驻，不释放

		bool DecodeImage(const std::wstring& path, std::vector<std::uint8_t>& out, int& w, int& h)
		{
			IWICImagingFactory* factory   = nullptr;
			IWICBitmapDecoder* decoder    = nullptr;
			IWICBitmapFrameDecode* frame  = nullptr;
			IWICFormatConverter* conv     = nullptr;
			bool ok = false;

			do
			{
				HRESULT hr = CoCreateInstance(CLSID_WICImagingFactory, nullptr, CLSCTX_INPROC_SERVER, __uuidof(IWICImagingFactory), reinterpret_cast<LPVOID*>(&factory));
				if (FAILED(hr) || !factory)
					break;
				hr = factory->CreateDecoderFromFilename(path.c_str(), nullptr, GENERIC_READ, WICDecodeMetadataCacheOnLoad, &decoder);
				if (FAILED(hr) || !decoder)
					break;
				hr = decoder->GetFrame(0, &frame);
				if (FAILED(hr) || !frame)
					break;
				hr = factory->CreateFormatConverter(&conv);
				if (FAILED(hr) || !conv)
					break;
				hr = conv->Initialize(frame, GUID_WICPixelFormat32bppRGBA, WICBitmapDitherTypeNone, nullptr, 0.0, WICBitmapPaletteTypeCustom);
				if (FAILED(hr))
					break;

				UINT ww = 0, hh = 0;
				conv->GetSize(&ww, &hh);
				if (!ww || !hh)
					break;

				out.resize(static_cast<size_t>(ww) * hh * 4);
				hr = conv->CopyPixels(nullptr, ww * 4, static_cast<UINT>(out.size()), out.data());
				if (FAILED(hr))
					break;

				w  = static_cast<int>(ww);
				h  = static_cast<int>(hh);
				ok = true;
			} while (false);

			if (conv) conv->Release();
			if (frame) frame->Release();
			if (decoder) decoder->Release();
			if (factory) factory->Release();
			return ok;
		}

		// 缩到最长边 192，图标够用也不吃显存
		void Resize(std::vector<std::uint8_t>& px, int& w, int& h, int maxSide)
		{
			if (w <= maxSide && h <= maxSide)
				return;
			const float k = static_cast<float>(maxSide) / static_cast<float>(w > h ? w : h);
			const int nw = std::max(1, static_cast<int>(w * k));
			const int nh = std::max(1, static_cast<int>(h * k));
			std::vector<std::uint8_t> dst(static_cast<size_t>(nw) * nh * 4);
			for (int y = 0; y < nh; y++)
			{
				const int sy = std::min(h - 1, y * h / nh);
				for (int x = 0; x < nw; x++)
				{
					const int sx = std::min(w - 1, x * w / nw);
					memcpy(&dst[(static_cast<size_t>(y) * nw + x) * 4], &px[(static_cast<size_t>(sy) * w + sx) * 4], 4);
				}
			}
			px.swap(dst);
			w = nw;
			h = nh;
		}

		std::wstring FindIcon()
		{
			std::vector<std::filesystem::path> dirs;
			dirs.emplace_back(std::filesystem::path("C:\\PeopleMenu") / "icon");
			if (const char* appdata = std::getenv("appdata"))
				dirs.push_back(std::filesystem::path(appdata) / "PeopleMenu" / "icon");
			WCHAR exe[MAX_PATH]{};
			if (GetModuleFileNameW(nullptr, exe, MAX_PATH))
				dirs.push_back(std::filesystem::path(exe).parent_path() / "icon");

			const wchar_t* names[] = {L"人民万岁.png", L"logo.png", L"icon.png", L"人民万岁.jpg", L"logo.jpg"};
			for (auto& d : dirs)
				for (auto n : names)
				{
					auto p = d / n;
					std::error_code ec;
					if (std::filesystem::exists(p, ec))
						return p.wstring();
				}
			return std::wstring();
		}

		void Worker(std::wstring path)
		{
			CoInitializeEx(nullptr, COINIT_APARTMENTTHREADED);

			std::vector<std::uint8_t> px;
			int w = 0, h = 0;
			if (!DecodeImage(path, px, w, h))
			{
				LOG(INFO) << "Logo: decode failed";
				CoUninitialize();
				return;
			}
			Resize(px, w, h, 192);

			ID3D12Device* dev = Renderer::GetDX12Device();
			if (!dev)
			{
				CoUninitialize();
				return;
			}

			ID3D12CommandQueue* queue = nullptr;
			D3D12_COMMAND_QUEUE_DESC qd{};
			qd.Type = D3D12_COMMAND_LIST_TYPE_DIRECT;
			if (FAILED(dev->CreateCommandQueue(&qd, IID_PPV_ARGS(&queue)) ) || !queue)
			{
				CoUninitialize();
				return;
			}

			D3D12_RESOURCE_DESC desc{};
			desc.Dimension        = D3D12_RESOURCE_DIMENSION_TEXTURE2D;
			desc.Width            = static_cast<UINT64>(w);
			desc.Height           = static_cast<UINT>(h);
			desc.DepthOrArraySize = 1;
			desc.MipLevels        = 1;
			desc.Format           = DXGI_FORMAT_R8G8B8A8_UNORM;
			desc.SampleDesc.Count = 1;
			desc.Layout           = D3D12_TEXTURE_LAYOUT_UNKNOWN;

			D3D12_HEAP_PROPERTIES defHeap{};
			defHeap.Type = D3D12_HEAP_TYPE_DEFAULT;
			D3D12_HEAP_PROPERTIES upHeap{};
			upHeap.Type = D3D12_HEAP_TYPE_UPLOAD;

			ID3D12Resource* tex           = nullptr;
			ID3D12Resource* upload        = nullptr;
			ID3D12CommandAllocator* alloc = nullptr;
			ID3D12GraphicsCommandList* list = nullptr;
			ID3D12Fence* fence            = nullptr;
			HANDLE evt                    = nullptr;
			bool ok = false;

			do
			{
				if (FAILED(dev->CreateCommittedResource(&defHeap, D3D12_HEAP_FLAG_NONE, &desc, D3D12_RESOURCE_STATE_COPY_DEST, nullptr, IID_PPV_ARGS(&tex)))
				    || !tex)
					break;

				D3D12_PLACED_SUBRESOURCE_FOOTPRINT layout{};
				UINT rows = 0;
				UINT64 rowSize = 0, total = 0;
				dev->GetCopyableFootprints(&desc, 0, 1, 0, &layout, &rows, &rowSize, &total);

				D3D12_RESOURCE_DESC bufDesc{};
				bufDesc.Dimension        = D3D12_RESOURCE_DIMENSION_BUFFER;
				bufDesc.Width            = total;
				bufDesc.Height           = 1;
				bufDesc.DepthOrArraySize = 1;
				bufDesc.MipLevels        = 1;
				bufDesc.Layout           = D3D12_TEXTURE_LAYOUT_ROW_MAJOR;
				bufDesc.SampleDesc.Count = 1;
				if (FAILED(dev->CreateCommittedResource(&upHeap, D3D12_HEAP_FLAG_NONE, &bufDesc, D3D12_RESOURCE_STATE_GENERIC_READ, nullptr, IID_PPV_ARGS(&upload)))
				    || !upload)
					break;

				void* mapped = nullptr;
				if (FAILED(upload->Map(0, nullptr, &mapped)) || !mapped)
					break;
				for (int y = 0; y < h; y++)
					memcpy(reinterpret_cast<std::uint8_t*>(mapped) + layout.Offset + static_cast<size_t>(y) * layout.Footprint.RowPitch,
					    px.data() + static_cast<size_t>(y) * w * 4,
					    static_cast<size_t>(w) * 4);
				upload->Unmap(0, nullptr);

				if (FAILED(dev->CreateCommandAllocator(D3D12_COMMAND_LIST_TYPE_DIRECT, IID_PPV_ARGS(&alloc)) ) || !alloc)
					break;
				if (FAILED(dev->CreateCommandList(0, D3D12_COMMAND_LIST_TYPE_DIRECT, alloc, nullptr, IID_PPV_ARGS(&list)) ) || !list)
					break;

				D3D12_TEXTURE_COPY_LOCATION src{};
				src.pResource       = upload;
				src.Type            = D3D12_TEXTURE_COPY_TYPE_PLACED_FOOTPRINT;
				src.PlacedFootprint = layout;

				D3D12_TEXTURE_COPY_LOCATION dst{};
				dst.pResource        = tex;
				dst.Type             = D3D12_TEXTURE_COPY_TYPE_SUBRESOURCE_INDEX;
				dst.SubresourceIndex = 0;
				list->CopyTextureRegion(&dst, 0, 0, 0, &src, nullptr);

				D3D12_RESOURCE_BARRIER barrier{};
				barrier.Type                   = D3D12_RESOURCE_BARRIER_TYPE_TRANSITION;
				barrier.Transition.pResource   = tex;
				barrier.Transition.Subresource = D3D12_RESOURCE_BARRIER_ALL_SUBRESOURCES;
				barrier.Transition.StateBefore = D3D12_RESOURCE_STATE_COPY_DEST;
				barrier.Transition.StateAfter  = D3D12_RESOURCE_STATE_PIXEL_SHADER_RESOURCE;
				list->ResourceBarrier(1, &barrier);

				if (FAILED(list->Close()))
					break;

				ID3D12CommandList* lists[] = {list};
				queue->ExecuteCommandLists(1, lists);

				if (FAILED(dev->CreateFence(0, D3D12_FENCE_FLAG_NONE, IID_PPV_ARGS(&fence)) ) || !fence)
					break;
				evt = CreateEventA(nullptr, FALSE, FALSE, nullptr);
				if (!evt)
					break;
				queue->Signal(fence, 1);
				fence->SetEventOnCompletion(1, evt);
				if (WaitForSingleObject(evt, 5000) != WAIT_OBJECT_0)
					break;

				s_Pending = tex;
				ok        = true;
			} while (false);

			if (list) list->Release();
			if (alloc) alloc->Release();
			if (fence) fence->Release();
			if (evt) CloseHandle(evt);
			if (upload) upload->Release();
			if (queue) queue->Release();
			if (!ok && tex)
				tex->Release();

			LOG(INFO) << "Logo: upload " << (ok ? "ok" : "failed") << " " << w << "x" << h;
			CoUninitialize();
		}
	}

	void Init()
	{
		if (s_Tried.exchange(true))
			return;
		if (!Renderer::IsDX12Backend())
			return;

		auto path = FindIcon();
		if (path.empty())
		{
			LOG(INFO) << "Logo: icon file not found (C:\\PeopleMenu\\icon\\人民万岁.png)";
			return;
		}
		std::thread(Worker, path).detach();
	}

	ImTextureID Tex()
	{
		// 渲染线程：先把后台线程上传好的纹理写成描述符，之后一直返回同一个句柄
		if (s_ReadyId)
			return s_ReadyId;

		ID3D12Resource* tex = s_Pending.exchange(nullptr);
		if (!tex)
			return 0;

		ID3D12Device* dev = Renderer::GetDX12Device();
		ID3D12DescriptorHeap* heap = Renderer::GetDX12SrvHeap();
		if (!dev || !heap || FAILED(dev->GetDeviceRemovedReason()))
		{
			tex->Release();
			return 0;
		}

		// 主题用了堆尾的 4 个槽，这里占再往前 1 个，绝不和主题抢
		const UINT heapSize = heap->GetDesc().NumDescriptors;
		if (heapSize < 6)
		{
			tex->Release();
			return 0;
		}
		const UINT slot = heapSize - 5;
		const UINT inc  = dev->GetDescriptorHandleIncrementSize(D3D12_DESCRIPTOR_HEAP_TYPE_CBV_SRV_UAV);

		D3D12_CPU_DESCRIPTOR_HANDLE cpu = heap->GetCPUDescriptorHandleForHeapStart();
		cpu.ptr += inc * slot;

		D3D12_SHADER_RESOURCE_VIEW_DESC srv{};
		srv.Format                  = DXGI_FORMAT_R8G8B8A8_UNORM;
		srv.ViewDimension           = D3D12_SRV_DIMENSION_TEXTURE2D;
		srv.Shader4ComponentMapping = D3D12_DEFAULT_SHADER_4_COMPONENT_MAPPING;
		srv.Texture2D.MipLevels     = 1;
		dev->CreateShaderResourceView(tex, &srv, cpu);

		D3D12_GPU_DESCRIPTOR_HANDLE gpu = heap->GetGPUDescriptorHandleForHeapStart();
		gpu.ptr += inc * slot;

		s_Held    = tex; // 不释放，纹理常驻
		s_ReadyId = reinterpret_cast<ImTextureID>(static_cast<UINT_PTR>(gpu.ptr));
		return s_ReadyId;
	}
}
