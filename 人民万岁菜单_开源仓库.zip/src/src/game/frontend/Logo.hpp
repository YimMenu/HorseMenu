#pragma once
#include "imgui.h"

namespace YimMenu
{
	// 菜单图标（人民万岁）：启动时后台线程读 C:\PeopleMenu\icon 下的 png，上传成 DX12 纹理
	// 读不到/非 DX12 就返回 0，界面自动只显示文字，绝不影响菜单本身
	namespace Logo
	{
		void Init();
		ImTextureID Tex(); // 只在渲染线程调用
	}
}
