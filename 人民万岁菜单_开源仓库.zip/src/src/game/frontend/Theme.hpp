#pragma once

#include "imgui.h"
#include <cstdint>

namespace YimMenu::Theme
{
	// —— 内置主题：烘焙进 DLL 的色块网格（后端无关，DX12/Vulkan 通用）——
	const std::uint8_t* BuiltinThemeGrid(int idx);
	int BuiltinThemeCount();
	const char* BuiltinThemeName(int idx);
	int DefaultThemeIndex();

	// 内置主题的原图（jpg 原始字节，运行时解码成纹理，保证不是压缩色块）
	bool BuiltinThemeJpeg(int idx, const std::uint8_t** data, std::uint32_t* size);

	// —— 外部主题：themes 文件夹里的 jpg/png/jpeg/bmp ——
	//   扫描位置：%APPDATA%\PeopleMenu\themes 以及 游戏目录\themes
	void LoadExternalThemes();
	int ExternalThemeCount();
	const char* ExternalThemesFolder();

	// —— 统一索引：0 ~ BuiltinThemeCount()-1 是内置，之后依次是外部主题 ——
	int ThemeCount();
	const char* ThemeName(int idx);
	const std::uint8_t* ThemeGrid(int idx);

	int BackdropCols();
	int BackdropRows();

	void SetTheme(int idx);
	int GetTheme();

	// —— 显示参数（设置页面里可调）——
	float GetBrightness();     // 背景亮度 0.6 ~ 1.8
	void SetBrightness(float v);
	float GetBackdropAlpha();  // 背景不透明度 0.0 ~ 1.0
	void SetBackdropAlpha(float v);
	float GetBlur();           // 磨砂程度 0 ~ 3（越大越糊）
	void SetBlur(float v);

	// 高清背景（DX12 纹理，异步上传）。关闭后只画色块，任何机器都不会卡
	bool GetUseTexture();
	void SetUseTexture(bool v);

	// 在指定矩形内绘制当前主题背景图（四角自带渐隐）
	void DrawBackdrop(ImVec2 pos, ImVec2 size, float alpha = 1.0f);

	void ApplyGlassStyle();
}
