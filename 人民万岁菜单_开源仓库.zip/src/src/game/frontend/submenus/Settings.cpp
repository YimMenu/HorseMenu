#include "settings.hpp"

#include "core/commands/Commands.hpp"
#include "core/commands/BoolCommand.hpp"
#include "core/commands/HotkeySystem.hpp"
#include "core/frontend/Notifications.hpp"
#include "game/backend/Self.hpp"
#include "game/features/Features.hpp"
#include "game/frontend/items/Items.hpp"
#include "game/frontend/Theme.hpp"
#include "core/frontend/Localization.hpp"

#include <array>

namespace YimMenu::Submenus
{
	// TODO: refactor this
	static void Hotkeys()
	{
		ImGui::BulletText(LH("Hold the command name clicked to change its hotkey"));
		ImGui::BulletText(LH("Press any registered key to remove"));

		ImGui::Spacing();
		ImGui::Separator();
		ImGui::Spacing();

		for (auto& [Hash, Command] : Commands::GetCommands())
		{
			ImGui::PushID(Hash);

			if (g_HotkeySystem.m_CommandHotkeys.find(Hash) != g_HotkeySystem.m_CommandHotkeys.end())
				HotkeySetter(Hash).Draw();

			ImGui::Spacing();

			ImGui::PopID();
		}
	};

	Settings::Settings() :
	    Submenu::Submenu("Settings")
	{
		auto hotkeys           = std::make_shared<Category>("Hotkeys");
		auto gui               = std::make_shared<Category>("GUI");
		auto protections       = std::make_shared<Category>("Protection");
		auto syncGroup         = std::make_shared<Group>("Sync");
		auto networkEventGroup = std::make_shared<Group>("Network Events");
		auto scriptEventGroup  = std::make_shared<Group>("Script Events");
		auto playerEsp         = std::make_shared<Group>("Player ESP", 10);
		auto pedEsp            = std::make_shared<Group>("Ped ESP", 10);
		auto overlay            = std::make_shared<Group>("Overlay");
		auto context           = std::make_shared<Group>("Context Menu");
		auto misc              = std::make_shared<Group>("Misc");

		hotkeys->AddItem(std::make_shared<ImGuiItem>(Hotkeys));

		// Players
		playerEsp->AddItem(std::make_shared<BoolCommandItem>("espdrawplayers"_J));
		playerEsp->AddItem(std::make_shared<ConditionalItem>("espdrawplayers"_J, std::make_shared<BoolCommandItem>("espdrawdeadplayers"_J)));

		playerEsp->AddItem(std::make_shared<ConditionalItem>("espdrawplayers"_J, std::make_shared<BoolCommandItem>("espnameplayers"_J, "Player Name")));
		playerEsp->AddItem(std::make_shared<ConditionalItem>("espdrawplayers"_J, std::make_shared<ColorCommandItem>("namecolorplayers"_J)));

		playerEsp->AddItem(std::make_shared<ConditionalItem>("espdrawplayers"_J, std::make_shared<BoolCommandItem>("espdistanceplayers"_J, "Player Distance")));
		//playerEsp->AddItem(std::make_shared<ConditionalItem>("espdrawplayers"_J, std::make_shared<ColorCommandItem>("distancecolorplayers"_J))); // TO DO

		playerEsp->AddItem(std::make_shared<ConditionalItem>("espdrawplayers"_J, std::make_shared<BoolCommandItem>("espskeletonplayers"_J, "Player Skeleton")));
		playerEsp->AddItem(std::make_shared<ConditionalItem>("espdrawplayers"_J, std::make_shared<ColorCommandItem>("skeletoncolorplayers"_J)));

		// Peds
		pedEsp->AddItem(std::make_shared<BoolCommandItem>("espdrawpeds"_J));
		pedEsp->AddItem(std::make_shared<ConditionalItem>("espdrawpeds"_J, std::make_shared<BoolCommandItem>("espdrawdeadpeds"_J)));

		pedEsp->AddItem(std::make_shared<ConditionalItem>("espdrawpeds"_J, std::make_shared<BoolCommandItem>("espmodelspeds"_J, "Ped Hashes")));
		pedEsp->AddItem(std::make_shared<ConditionalItem>("espdrawpeds"_J, std::make_shared<ColorCommandItem>("hashcolorpeds"_J)));

		pedEsp->AddItem(std::make_shared<ConditionalItem>("espdrawpeds"_J, std::make_shared<BoolCommandItem>("espnetinfopeds"_J, "Ped Net Info")));
		pedEsp->AddItem(std::make_shared<ConditionalItem>("espdrawpeds"_J, std::make_shared<BoolCommandItem>("espscriptinfopeds"_J, "Ped Script Info")));

		pedEsp->AddItem(std::make_shared<ConditionalItem>("espdrawpeds"_J, std::make_shared<BoolCommandItem>("espdistancepeds"_J, "Ped Distance")));
		//pedEsp->AddItem(std::make_shared<ConditionalItem>("espdrawpeds"_J, std::make_shared<ColorCommandItem>("distancecolorpeds"_J))); // TO DO

		pedEsp->AddItem(std::make_shared<ConditionalItem>("espdrawpeds"_J, std::make_shared<BoolCommandItem>("espskeletonpeds"_J, "Ped Skeleton")));
		pedEsp->AddItem(std::make_shared<ConditionalItem>("espdrawpeds"_J, std::make_shared<ColorCommandItem>("skeletoncolorpeds"_J)));

		pedEsp->AddItem(std::make_shared<ConditionalItem>("espdrawpeds"_J, std::make_shared<BoolCommandItem>("espskeletonhorse"_J, "Horse Skeleton")));
		pedEsp->AddItem(std::make_shared<ConditionalItem>("espdrawpeds"_J, std::make_shared<ColorCommandItem>("skeletoncolorhorse"_J)));

		overlay->AddItem(std::make_shared<BoolCommandItem>("overlay"_J));
		overlay->AddItem(std::make_shared<ConditionalItem>("overlay"_J, std::make_shared<BoolCommandItem>("overlayfps"_J)));

		context->AddItem(std::make_shared<BoolCommandItem>("ctxmenu"_J));
		context->AddItem(std::make_shared<ConditionalItem>("ctxmenu"_J, std::make_shared<BoolCommandItem>("ctxmenuplayers"_J, "Players")));
		context->AddItem(std::make_shared<ConditionalItem>("ctxmenu"_J, std::make_shared<BoolCommandItem>("ctxmenupeds"_J, "Peds")));
		context->AddItem(std::make_shared<ConditionalItem>("ctxmenu"_J, std::make_shared<BoolCommandItem>("ctxmenuvehicles"_J, "Vehicles")));
		context->AddItem(std::make_shared<ConditionalItem>("ctxmenu"_J, std::make_shared<BoolCommandItem>("ctxmenuobjects"_J, "Objects")));

		syncGroup->AddItem(std::make_shared<BoolCommandItem>("blockspectate"_J));
		syncGroup->AddItem(std::make_shared<BoolCommandItem>("blockspectatesession"_J));
		syncGroup->AddItem(std::make_shared<BoolCommandItem>("blockattach"_J));
		syncGroup->AddItem(std::make_shared<BoolCommandItem>("blockvehflood"_J));
		syncGroup->AddItem(std::make_shared<BoolCommandItem>("blockghostpeds"_J));
		syncGroup->AddItem(std::make_shared<BoolCommandItem>("locklobby"_J));

		networkEventGroup->AddItem(std::make_shared<BoolCommandItem>("blockexplosions"_J));
		networkEventGroup->AddItem(std::make_shared<BoolCommandItem>("blockptfx"_J));
		networkEventGroup->AddItem(std::make_shared<BoolCommandItem>("blockclearpedtasks"_J));
		networkEventGroup->AddItem(std::make_shared<BoolCommandItem>("blockscriptcommand"_J));
		networkEventGroup->AddItem(std::make_shared<BoolCommandItem>("userelaycxns"_J));

		scriptEventGroup->AddItem(std::make_shared<BoolCommandItem>("blockhonormanipulation"_J));
		scriptEventGroup->AddItem(std::make_shared<BoolCommandItem>("blockdefensive"_J));
		scriptEventGroup->AddItem(std::make_shared<BoolCommandItem>("blockoffensive"_J));
		scriptEventGroup->AddItem(std::make_shared<BoolCommandItem>("blockpresscharges"_J));
		scriptEventGroup->AddItem(std::make_shared<BoolCommandItem>("blockstartparlay"_J));
		scriptEventGroup->AddItem(std::make_shared<BoolCommandItem>("blockendparlay"_J));
		scriptEventGroup->AddItem(std::make_shared<BoolCommandItem>("blocktickerspam"_J));
		scriptEventGroup->AddItem(std::make_shared<BoolCommandItem>("blockstableevents"_J));
		scriptEventGroup->AddItem(std::make_shared<BoolCommandItem>("blockkickfrommissionlobby"_J));

		gui->AddItem(playerEsp);
		gui->AddItem(pedEsp);
		gui->AddItem(overlay);
		gui->AddItem(context);
		gui->AddItem(misc);

		protections->AddItem(syncGroup);
		protections->AddItem(networkEventGroup);
		protections->AddItem(scriptEventGroup);

		// —— 一键防护：防止被付费菜单的崩溃/锁人手段搞崩 ——
		auto allProtections = std::to_array<const char*>({
		    "blockspectate",
		    "blockspectatesession",
		    "blockattach",
		    "blockvehflood",
		    "blockghostpeds",
		    "blockexplosions",
		    "blockptfx",
		    "blockclearpedtasks",
		    "blockscriptcommand",
		    "blockhonormanipulation",
		    "blockdefensive",
		    "blockoffensive",
		    "blockpresscharges",
		    "blockstartparlay",
		    "blockendparlay",
		    "blocktickerspam",
		    "blockstableevents",
		    "blockkickfrommissionlobby",
		});

		auto quickProtect = std::make_shared<Group>("一键防护");
		quickProtect->AddItem(std::make_shared<ImGuiItem>([=] {
			static bool s_LastAllOn = false;
			ImGui::TextWrapped(LH("把下面所有防护一次全开。别人用付费菜单甩崩溃事件、强制附身、刷载具、刷幽灵行人时，都会在这里被挡掉，菜单本身不会被拖崩。"));
			ImGui::Spacing();

			if (ImGui::Button(LH("一键全开防护"), ImVec2(180, 0)))
			{
				for (auto name : allProtections)
					if (auto cmd = Commands::GetCommand<BoolCommand>(Joaat(name)))
						cmd->SetState(true);
				s_LastAllOn = true;
				Notifications::Show("Protection", "已开启全部防护", NotificationType::Success);
			}
			ImGui::SameLine();
			if (ImGui::Button(LH("一键全关防护"), ImVec2(180, 0)))
			{
				for (auto name : allProtections)
					if (auto cmd = Commands::GetCommand<BoolCommand>(Joaat(name)))
						cmd->SetState(false);
				s_LastAllOn = false;
			}

			ImGui::SameLine();
			ImGui::TextDisabled(s_LastAllOn ? LH("当前：全部防护已开启") : LH("当前：未全部开启"));
		}));
		protections->AddItem(quickProtect);
		// 主题背景（15 张主题图烘焙进 DLL，默认第 4 张「人民万岁」）
		auto themeCat = std::make_shared<Category>("主题");
		themeCat->AddItem(std::make_shared<ImGuiItem>([] {
			ImGui::Text(LH("主题背景  %d / %d"), Theme::GetTheme() + 1, Theme::ThemeCount());
			ImGui::Spacing();
			for (int i = 0; i < Theme::ThemeCount(); i++)
			{
				auto label = std::format("{}  {}", i + 1, Theme::ThemeName(i));
				if (ImGui::Selectable(label.c_str(), Theme::GetTheme() == i, 0, ImVec2(158, 0)))
					Theme::SetTheme(i);
				if ((i % 3) != 2)
					ImGui::SameLine();
				else
					ImGui::Spacing();
			}
			ImGui::Spacing();
			ImGui::TextDisabled(LH("预览站与安装器默认使用第 4 张「人民万岁」"));

			ImGui::Separator();
			ImGui::Text(LH("背景调节（看不清楚就调这里）"));
			ImGui::Spacing();

			float bright = Theme::GetBrightness();
			if (ImGui::SliderFloat(LH("背景亮度"), &bright, 0.60f, 1.80f, "%.2f"))
				Theme::SetBrightness(bright);

			float alpha = Theme::GetBackdropAlpha();
			if (ImGui::SliderFloat(LH("背景不透明度"), &alpha, 0.00f, 1.00f, "%.2f"))
				Theme::SetBackdropAlpha(alpha);

			float blur = Theme::GetBlur();
			if (ImGui::SliderFloat(LH("磨砂模糊"), &blur, 0.00f, 3.00f, "%.2f"))
				Theme::SetBlur(blur);

			ImGui::Spacing();
			ImGui::TextDisabled(LH("亮度 1.00 / 不透明度 1.00 / 磨砂 0.00 = 图片完全清晰"));
			ImGui::Spacing();

			bool useTex = Theme::GetUseTexture();
			if (ImGui::Checkbox(LH("高清背景（原图纹理）"), &useTex))
				Theme::SetUseTexture(useTex);
			ImGui::SameLine();
			ImGui::TextDisabled(LH("关掉就只画色块；机器吃不消时取消勾选"));

			ImGui::Spacing();

			if (ImGui::Button(LH("重新扫描主题文件夹"), ImVec2(196, 0)))
				Theme::LoadExternalThemes();
			ImGui::SameLine();
			ImGui::TextDisabled(LH("外部主题 %d 张"), Theme::ExternalThemeCount());
			ImGui::TextWrapped(LH("主题文件夹：%s"), Theme::ExternalThemesFolder());
			ImGui::TextDisabled(LH("把 jpg / png 放进 themes 文件夹，点上面的按钮即可出现在上面列表"));
		}));

		// 关于
		auto aboutCat = std::make_shared<Category>("关于");
		aboutCat->AddItem(std::make_shared<ImGuiItem>([] {
			ImGui::Text(LH("人民万岁菜单"));
			ImGui::TextDisabled(LH("Terminus 中文重制版 · 作者：kylie"));
			ImGui::Separator();
			ImGui::Spacing();
			ImGui::TextWrapped(LH("读陆游咏梅词，反其意而用之。"));
			ImGui::TextWrapped(LH("风雨送春归，飞雪迎春到。"));
			ImGui::TextWrapped(LH("已是悬崖百丈冰，犹有花枝俏。"));
			ImGui::TextWrapped(LH("俏也不争春，只把春来报。"));
			ImGui::TextWrapped(LH("待到山花烂漫时，她在丛中笑。"));
			ImGui::Spacing();
			ImGui::Separator();
			ImGui::TextDisabled(LH("INSERT 显示 / 隐藏菜单 · 方向键切换分类"));
		}));

		AddCategory(std::move(hotkeys));
		AddCategory(std::move(gui));
		AddCategory(std::move(themeCat));
		AddCategory(std::move(aboutCat));
		AddCategory(std::move(protections));
	}
}