#include "ModPacks.hpp"

#include "core/frontend/Notifications.hpp"
#include "game/backend/Mods.hpp"
#include "game/frontend/items/Items.hpp"

namespace YimMenu::Submenus
{
	namespace
	{
		char s_Search[Mods::KindCount][64]{};

		void DrawModList(Mods::Kind kind)
		{
			auto& group = Mods::Get(kind);
			const int k = static_cast<int>(kind);

			ImGui::InputTextWithHint("##modsearch", "搜索：火焰马 / V001 / 瓦伦丁", s_Search[k], sizeof(s_Search[k]));

			if (!group.Loaded)
			{
				ImGui::TextColored(ImVec4(1.0f, 0.72f, 0.37f, 1.0f), "清单未加载：%s", Mods::LastError().c_str());
				ImGui::TextWrapped("把 人民万岁模组包 解压到 C:\\PeopleMenu\\mods\\（要有 index.json 和 mods 文件夹），再点“重新加载清单”。");
				return;
			}

			ImGui::Text("共 %d 个模组 / %d 个物件", static_cast<int>(group.Items.size()), group.ItemTotal);
			ImGui::SameLine();
			if (Mods::IsBusy())
				ImGui::TextColored(ImVec4(1.0f, 0.8f, 0.3f, 1.0f), "生成中…（%d）", Mods::SpawnedCount());
			else
				ImGui::TextDisabled("场上 %d 个实体", Mods::SpawnedCount());

			ImGui::Separator();

			std::string filter = s_Search[k];
			ImGui::BeginChild(k == 0 ? "##veh" : (k == 1 ? "##hor" : "##wld"), ImVec2(0, 400), true);
			for (auto& e : group.Items)
			{
				if (!filter.empty())
				{
					std::string hay = e.Id + " " + e.Label + " " + e.Note;
					if (hay.find(filter) == std::string::npos)
						continue;
				}

				if (e.Heavy)
					ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(1.0f, 0.45f, 0.45f, 1.0f));

				std::string row = std::format("{}  {}（{}）", e.Id, e.Label, e.Count);
				if (ImGui::Selectable(row.c_str()))
					Mods::Spawn(kind, e.Id);

				if (e.Heavy)
					ImGui::PopStyleColor();

				if (ImGui::IsItemHovered())
					ImGui::SetTooltip("%s\n%s", e.Note.c_str(), e.File.c_str());
			}
			ImGui::EndChild();
		}
	}

	ModPacks::ModPacks() :
	    Submenu::Submenu("模组")
	{
		auto vehicles = std::make_shared<Category>("载具模组");
		auto horses   = std::make_shared<Category>("马匹模组");
		auto world    = std::make_shared<Category>("世界模组");
		auto manage   = std::make_shared<Category>("管理");

		vehicles->AddItem(std::make_shared<ImGuiItem>([] {
			DrawModList(Mods::Vehicle);
		}));
		horses->AddItem(std::make_shared<ImGuiItem>([] {
			DrawModList(Mods::Horse);
		}));
		world->AddItem(std::make_shared<ImGuiItem>([] {
			DrawModList(Mods::World);
		}));

		manage->AddItem(std::make_shared<ImGuiItem>([] {
			ImGui::TextWrapped("模组目录：%s", (Mods::Root() / "mods").string().c_str());
			ImGui::Spacing();

			if (ImGui::Button("重新加载清单", ImVec2(200, 30)))
			{
				Mods::Load();
				if (Mods::IsLoaded())
					Notifications::Show("人民万岁 · 模组", "清单已重新加载", NotificationType::Success);
				else
					Notifications::Show("人民万岁 · 模组", Mods::LastError(), NotificationType::Error);
			}

			ImGui::Spacing();
			if (ImGui::Button("清场（删除所有模组实体）", ImVec2(260, 30)))
			{
				Mods::Clear();
				Notifications::Show("人民万岁 · 模组", "已清场", NotificationType::Info);
			}

			ImGui::Spacing();
			ImGui::TextDisabled("规则：载具/马匹 8 个挂件一帧，世界 4 个物件一帧；");
			ImGui::TextDisabled("挂件全部关闭碰撞、生成即同步到联机，单次最多 400 个实体。");

			auto status = Mods::StatusText();
			if (!status.empty())
				ImGui::TextColored(ImVec4(0.6f, 1.0f, 0.7f, 1.0f), "%s", status.c_str());
		}));

		AddCategory(std::move(vehicles));
		AddCategory(std::move(horses));
		AddCategory(std::move(world));
		AddCategory(std::move(manage));
	}
}
