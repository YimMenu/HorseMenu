#include "Scripts.hpp"

#include "core/frontend/Notifications.hpp"
#include "core/lua/LuaScripts.hpp"
#include "game/frontend/items/Items.hpp"

namespace YimMenu::Submenus
{
	Scripts::Scripts() :
	    Submenu::Submenu("脚本")
	{
		auto loaded = std::make_shared<Category>("已加载脚本");
		auto api    = std::make_shared<Category>("脚本 API");
		auto help   = std::make_shared<Category>("怎么用");

		loaded->AddItem(std::make_shared<ImGuiItem>([] {
			ImGui::Text("目录：C:\\PeopleMenu\\scripts\\*.lua");
			ImGui::SameLine();
			ImGui::TextDisabled("（%s）", LuaScripts::Status().c_str());
			ImGui::Spacing();

			if (ImGui::Button("重新加载脚本", ImVec2(180, 30)))
			{
				LuaScripts::LoadAll();
				Notifications::Show("人民万岁 · 脚本", "正在重新加载…", NotificationType::Info);
			}
			ImGui::SameLine();
			if (ImGui::Button("全部卸载", ImVec2(140, 30)))
			{
				LuaScripts::Unload();
				Notifications::Show("人民万岁 · 脚本", "已卸载所有脚本", NotificationType::Info);
			}

			ImGui::Separator();
			ImGui::BeginChild("##scripts", ImVec2(0, 260), true);
			auto& list = LuaScripts::Entries();
			if (list.empty())
				ImGui::TextDisabled("还没有脚本，把 .lua 丢进 C:\\PeopleMenu\\scripts 再重载");
			for (auto& e : list)
			{
				const bool bad = e.second.find("失败") != std::string::npos
				              || e.second.find("错误") != std::string::npos;
				if (bad)
					ImGui::TextColored(ImVec4(1.0f, 0.45f, 0.45f, 1.0f), "%s  —  %s", e.first.c_str(), e.second.c_str());
				else
					ImGui::TextColored(ImVec4(0.6f, 1.0f, 0.7f, 1.0f), "%s  —  %s", e.first.c_str(), e.second.c_str());
			}
			ImGui::EndChild();
		}));

		api->AddItem(std::make_shared<ImGuiItem>([] {
			ImGui::TextWrapped("全局表 PM 下可用的函数（全部在脚本上下文里安全执行）：");
			ImGui::Spacing();
			ImGui::BulletText("PM.log(msg)                       打印日志到菜单日志");
			ImGui::BulletText("PM.notify(msg[, title])           右下角通知");
			ImGui::BulletText("PM.pos()                          返回 x, y, z");
			ImGui::BulletText("PM.player()                       返回自己 ped 句柄");
			ImGui::BulletText("PM.spawnObject(hash, x, y, z)     生成物体，返回句柄");
			ImGui::BulletText("PM.spawnPed(hash, x, y, z[, h])   生成 NPC/动物");
			ImGui::BulletText("PM.spawnVehicle(hash, x, y, z[, h]) 生成载具");
			ImGui::BulletText("PM.delete(handle)                 删除实体");
			ImGui::BulletText("PM.setPos(handle, x, y, z)        设置坐标");
			ImGui::BulletText("PM.setRot(handle, x, y, z)        设置旋转");
			ImGui::BulletText("PM.freeze(handle, bool)           冻结");
			ImGui::BulletText("PM.collision(handle, bool)        碰撞");
			ImGui::BulletText("PM.invincible(handle, bool)       无敌");
			ImGui::BulletText("PM.sync(handle)                   同步到所有玩家");
			ImGui::BulletText("PM.valid(handle)                  实体是否有效");
			ImGui::BulletText("PM.onTick(function)               每帧回调（约 10 次/秒）");
		}));

		help->AddItem(std::make_shared<ImGuiItem>([] {
			ImGui::TextWrapped("写脚本：新建一个 UTF-8 的 .lua 文件放 C:\\PeopleMenu\\scripts\\，然后点“重新加载脚本”。");
			ImGui::Spacing();
			ImGui::TextWrapped("示例（生成一辆车并同步给所有人）：");
			ImGui::BeginChild("##sample", ImVec2(0, 150), true);
			ImGui::TextUnformatted(
			    "local x, y, z = PM.pos()\n"
			    "local veh = PM.spawnVehicle(0x5E56769C, x + 2, y + 2, z, 0.0)\n"
			    "if veh ~= 0 then\n"
			    "  PM.sync(veh)\n"
			    "  PM.notify(\"生成完成\")\n"
			    "end\n"
			    "\n"
			    "PM.onTick(function()\n"
			    "  -- 每帧跑一次，别写重活\n"
			    "end)");
			ImGui::EndChild();
			ImGui::Spacing();
			ImGui::TextColored(ImVec4(1.0f, 0.72f, 0.37f, 1.0f),
			    "沙箱：没有 io / os / package，脚本读写不了你的文件和进程；");
			ImGui::TextColored(ImVec4(1.0f, 0.72f, 0.37f, 1.0f),
			    "下划线开头的文件（_lib.lua）会被跳过，可以当公共库用。");
		}));

		AddCategory(std::move(loaded));
		AddCategory(std::move(api));
		AddCategory(std::move(help));
	}
}
