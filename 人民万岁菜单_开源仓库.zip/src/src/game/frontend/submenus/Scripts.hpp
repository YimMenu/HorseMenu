#pragma once
#include "core/frontend/manager/UIManager.hpp"

namespace YimMenu::Submenus
{
	class Scripts : public Submenu
	{
	public:
		Scripts();
	};
}
