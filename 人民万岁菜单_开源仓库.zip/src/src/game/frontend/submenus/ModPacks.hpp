#pragma once
#include "core/frontend/manager/UIManager.hpp"

namespace YimMenu::Submenus
{
	class ModPacks : public Submenu
	{
	public:
		ModPacks();
	};
}
