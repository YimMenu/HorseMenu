#include "Helpful.hpp"
#include "core/frontend/Notifications.hpp"
#include "core/frontend/Localization.hpp"
#include "game/backend/FiberPool.hpp"
#include "game/backend/Players.hpp"
#include "game/backend/Self.hpp"
#include "game/backend/ScriptMgr.hpp"
#include "game/rdr/Natives.hpp"
#include "game/rdr/Scripts.hpp"
#include "game/rdr/ScriptFunction.hpp"
#include "game/rdr/Vehicle.hpp"
#include "util/Rewards.hpp"

#include <array>
#include <atomic>
#include <algorithm>
#include <iterator>

namespace YimMenu::Submenus
{
	namespace
	{
		struct CollGroup
		{
			const char* name;
			const Rewards::RewardInfo* items;
			size_t count;
			const char* const* names; // 化石/鸟蛋的 description 是空的，用这张表显示名字
			bool script;              // 化石/鸟蛋只能走脚本奖励
		};

		const char* const g_FossilNames[]{
		    "珊瑚化石", "双壳类化石", "腕足类化石", "角化石", "头足类化石",
		    "隐纹三叶虫", "等尾三叶虫", "巨齿鲨牙", "新石器时代化石", "石核化石",
		    "石化木", "彩虹石化木", "海百合化石", "海蝎化石", "锯齿牙化石",
		    "尾刺化石", "趾爪化石", "霸王龙牙", "塔利怪物", "黄色石化木",
		};

		const char* const g_EggNames[]{
		    "秃鹫蛋", "潜鸟蛋", "鸭蛋", "鹅蛋", "鹭蛋",
		    "白鹭蛋", "鹰蛋", "隼蛋", "琵鹭蛋", "神鹰蛋",
		};

		const CollGroup g_CollGroups[]{
		    {"传家宝", Rewards::Heirlooms, std::size(Rewards::Heirlooms), nullptr, false},
		    {"硬币", Rewards::Coins, std::size(Rewards::Coins), nullptr, false},
		    {"酒瓶", Rewards::AlcBottles, std::size(Rewards::AlcBottles), nullptr, false},
		    {"箭头", Rewards::Arrowheads, std::size(Rewards::Arrowheads), nullptr, false},
		    {"手镯", Rewards::Bracelets, std::size(Rewards::Bracelets), nullptr, false},
		    {"耳环", Rewards::Earrings, std::size(Rewards::Earrings), nullptr, false},
		    {"项链", Rewards::Necklaces, std::size(Rewards::Necklaces), nullptr, false},
		    {"戒指", Rewards::Rings, std::size(Rewards::Rings), nullptr, false},
		    {"塔罗牌 · 圣杯", Rewards::TarotCards_Cups, std::size(Rewards::TarotCards_Cups), nullptr, false},
		    {"塔罗牌 · 星币", Rewards::TarotCards_Pentacles, std::size(Rewards::TarotCards_Pentacles), nullptr, false},
		    {"塔罗牌 · 宝剑", Rewards::TarotCards_Swords, std::size(Rewards::TarotCards_Swords), nullptr, false},
		    {"塔罗牌 · 权杖", Rewards::TarotCards_Wands, std::size(Rewards::TarotCards_Wands), nullptr, false},
		    {"化石", Rewards::Fossils, std::size(Rewards::Fossils), g_FossilNames, true},
		    {"鸟蛋", Rewards::Eggs, std::size(Rewards::Eggs), g_EggNames, true},
		};

		const char* ItemName(const CollGroup& g, int index)
		{
			if (g.names)
				return LH(g.names[index]);
			return LH(g.items[index].description.c_str());
		}

		// 草药清单（和「恢复 → 生成草药」保持一致）
		const std::array<std::pair<joaat_t, const char*>, 40> g_Herbs{{
		    {"HERB_LOOT_ALASKAN_GINSENG"_J, "Alaskan Ginseng"},
		    {"HERB_LOOT_AMERICAN_GINSENG"_J, "American Ginseng"},
		    {"HERB_LOOT_BAY_BOLETE"_J, "Bay Bolete"},
		    {"HERB_LOOT_BLACK_BERRY"_J, "Black Berry"},
		    {"HERB_LOOT_BLACK_CURRANT"_J, "Black Currant"},
		    {"HERB_LOOT_BURDOCK_ROOT"_J, "Burdock Root"},
		    {"HERB_LOOT_CHANTERELLES"_J, "Chanterelles"},
		    {"HERB_LOOT_COMMON_BULRUSH"_J, "Common Bulrush"},
		    {"HERB_LOOT_CREEPING_THYME"_J, "Creeping Thyme"},
		    {"HERB_LOOT_DESERT_SAGE"_J, "Desert Sage"},
		    {"HERB_LOOT_ENGLISH_MACE"_J, "English Mace"},
		    {"HERB_LOOT_EVERGREEN_HUCKLEBERRY"_J, "Evergreen Huckleberry"},
		    {"HERB_LOOT_GOLDEN_CURRANT"_J, "Golden Currant"},
		    {"HERB_LOOT_HUMMINGBIRD_SAGE"_J, "Hummingbird Sage"},
		    {"HERB_LOOT_INDIAN_TOBACCO"_J, "Indian Tobacco"},
		    {"HERB_LOOT_MILKWEED"_J, "Milkweed"},
		    {"HERB_LOOT_OLEANDER_SAGE"_J, "Oleander Sage"},
		    {"HERB_LOOT_OREGANO"_J, "Oregano"},
		    {"HERB_LOOT_PARASOL_MUSHROOM"_J, "Parasol Mushroom"},
		    {"HERB_LOOT_PRAIRIE_POPPY"_J, "Prairie Poppy"},
		    {"HERB_LOOT_RAMS_HEAD"_J, "Rams Head"},
		    {"HERB_LOOT_RED_RASPBERRY"_J, "Red Raspberry"},
		    {"HERB_LOOT_RED_SAGE"_J, "Red Sage"},
		    {"HERB_LOOT_VANILLA_FLOWER"_J, "Vanilla Flower"},
		    {"HERB_LOOT_VIOLET_SNOWDROP"_J, "Violet Snowdrop"},
		    {"HERB_LOOT_WILD_CARROTS"_J, "Wild Carrots"},
		    {"HERB_LOOT_WILD_FEVERFEW"_J, "Wild Feverfew"},
		    {"HERB_LOOT_WILD_MINT"_J, "Wild Mint"},
		    {"HERB_LOOT_WINTERGREEN_BERRY"_J, "Wintergreen Berry"},
		    {"HERB_LOOT_YARROW"_J, "Yarrow"},
		    {"HERB_LOOT_AGARITA"_J, "Agarita"},
		    {"HERB_LOOT_BITTERWEED"_J, "Bitterweed"},
		    {"HERB_LOOT_BLUE_BONNET"_J, "Blue Bonnet"},
		    {"HERB_LOOT_BLOOD_FLOWER"_J, "Blood Flower"},
		    {"HERB_LOOT_CARDINAL_FLOWER"_J, "Cardinal Flower"},
		    {"HERB_LOOT_CHOCOLATE_DAISY"_J, "Chocolate Daisy"},
		    {"HERB_LOOT_CREEK_PLUM"_J, "Creek Plum"},
		    {"HERB_LOOT_RHUBARB"_J, "Rhubarb"},
		    {"HERB_LOOT_WISTERIA"_J, "Wisteria"},
		    {"HERB_LOOT_HARRIETUM"_J, "Harrietum"},
		}};

		// —— 生成闸门：一次只跑一个任务，按钮 3 秒冷却，5 秒内最多注册 6 个网络实体 ——
		std::atomic<int> g_SpawnCooldown{0};
		std::atomic<int> g_NetRegCount{0};
		std::atomic<int> g_NetRegStamp{0};

		bool SpawnGuardPass()
		{
			const int now = static_cast<int>(GetTickCount64() / 1000);
			if (now - g_NetRegStamp.load() > 5)
			{
				g_NetRegStamp = now;
				g_NetRegCount = 0;
			}
			return g_NetRegCount.load() < 6;
		}

		void CountNetReg()
		{
			g_NetRegStamp = static_cast<int>(GetTickCount64() / 1000);
			g_NetRegCount++;
		}

		// 在玩家面前摆一个宝箱（模型加载失败就放弃，不会卡住游戏）
		Entity SpawnChestInFront(Player player)
		{
			if (!player.IsValid())
				return Entity(0);

			auto ped = player.GetPed();
			if (ped.GetHandle() == 0 || !ENTITY::DOES_ENTITY_EXIST(ped.GetHandle()))
				return Entity(0);

			auto forward   = ENTITY::GET_ENTITY_FORWARD_VECTOR(ped.GetHandle());
			auto pos       = ped.GetPosition();
			float heading  = ENTITY::GET_ENTITY_HEADING(ped.GetHandle());
			auto chestModel = "p_steamer_trunk_001"_J;

			for (uint8_t i = 0; !STREAMING::HAS_MODEL_LOADED(chestModel) && i < 60; i++)
			{
				STREAMING::REQUEST_MODEL(chestModel, 1);
				ScriptMgr::Yield();
			}
			if (!STREAMING::HAS_MODEL_LOADED(chestModel))
			{
				Notifications::Show(LH("宝箱生成器"), LH("宝箱模型加载失败，换个位置再试"), NotificationType::Error);
				return Entity(0);
			}

			auto chest = Entity(OBJECT::CREATE_OBJECT(chestModel,
			    pos.x + (forward.x * 1.75f),
			    pos.y + (forward.y * 1.75f),
			    pos.z + 1.085f,
			    true,
			    false,
			    true,
			    false,
			    false));

			// 句柄为 0 就立刻收手：拿 0 去调 OBJ_TO_NET / SET_NETWORK_ID_EXISTS_ON_ALL_MACHINES
			// 会把网络对象表写成非法状态，整机卡死大多从这一步来
			if (chest.GetHandle() == 0 || !ENTITY::DOES_ENTITY_EXIST(chest.GetHandle()))
			{
				Notifications::Show(LH("宝箱生成器"), LH("宝箱生成失败，换个位置再试"), NotificationType::Error);
				STREAMING::SET_MODEL_AS_NO_LONGER_NEEDED(chestModel);
				return Entity(0);
			}

			if (SpawnGuardPass())
			{
				OBJECT::PLACE_OBJECT_ON_GROUND_PROPERLY(chest.GetHandle(), true);
				ENTITY::SET_ENTITY_HEADING(chest.GetHandle(), heading);

				int netId = NETWORK::OBJ_TO_NET(chest.GetHandle());
				if (netId != 0)
				{
					NETWORK::NETWORK_REGISTER_ENTITY_AS_NETWORKED(chest.GetHandle());
					NETWORK::SET_NETWORK_ID_EXISTS_ON_ALL_MACHINES(netId, true);
					CountNetReg();
				}
			}

			ScriptMgr::Yield(50ms);
			STREAMING::SET_MODEL_AS_NO_LONGER_NEEDED(chestModel);
			return chest;
		}

		// 在目标玩家面前摆箱子，并把奖励道具实体撒进箱子里：
		// 自己开就是直接进包；给别人刷，箱子里的东西是网络实体，对方走过去自己捡
		void SpawnItemProps(Entity chest, joaat_t model, int amount)
		{
			if (model == 0 || chest.GetHandle() == 0 || !ENTITY::DOES_ENTITY_EXIST(chest.GetHandle()))
				return;

			amount = std::clamp(amount, 1, 3); // 一次最多 3 个，越多越容易把网络对象表顶爆

			for (uint8_t i = 0; !STREAMING::HAS_MODEL_LOADED(model) && i < 60; i++)
			{
				STREAMING::REQUEST_MODEL(model, 1);
				ScriptMgr::Yield();
			}
			if (!STREAMING::HAS_MODEL_LOADED(model))
				return;

			Vector3 boxPos = ENTITY::GET_ENTITY_COORDS(chest.GetHandle(), true, true);
			float heading  = ENTITY::GET_ENTITY_HEADING(chest.GetHandle());

			for (int i = 0; i < amount; ++i)
			{
				if (!SpawnGuardPass())
					break;

				float offsetX = 0.10f * cos(heading) * (1.0f + (float)(i % 3));
				float offsetY = 0.10f * sin(heading) * (1.0f + (float)(i % 3));
				auto prop = Entity(OBJECT::CREATE_OBJECT(model,
				    boxPos.x + offsetX,
				    boxPos.y + offsetY,
				    boxPos.z + 0.15f,
				    true,
				    false,
				    true,
				    false,
				    false));

				if (prop.GetHandle() == 0 || !ENTITY::DOES_ENTITY_EXIST(prop.GetHandle()))
					continue;

				ENTITY::SET_ENTITY_HEADING(prop.GetHandle(), heading);
				int id = NETWORK::OBJ_TO_NET(prop.GetHandle());
				if (id == 0)
					continue;

				NETWORK::NETWORK_REGISTER_ENTITY_AS_NETWORKED(prop.GetHandle());
				NETWORK::SET_NETWORK_ID_EXISTS_ON_ALL_MACHINES(id, true);
				CountNetReg();

				// 一个个摆，别在同一帧里连注册多个
				ScriptMgr::Yield(150ms);
			}

			STREAMING::SET_MODEL_AS_NO_LONGER_NEEDED(model);
		}

		bool IsSelf(Player target)
		{
			return target.IsValid() && target.GetId() == Self::GetPlayer().GetId();
		}

		int g_CollGroupIndex = 0;
		int g_CollItemIndex  = 0;
		int g_CollAmount     = 1;
		int g_HerbIndex      = 0;
		int g_HerbAmount     = 5;
		int g_SilverAmount   = 500;
	}

	std::shared_ptr<Category> BuildHelpfulMenu()
	{
		auto menu = std::make_shared<Category>("Helpful");

		menu->AddItem(std::make_shared<PlayerCommandItem>("spawngoldchest"_J));

		menu->AddItem(std::make_shared<ImGuiItem>([] {
			const int nowSec = static_cast<int>(GetTickCount64() / 1000);
			const bool busy  = nowSec < g_SpawnCooldown.load();

			// —— 收藏品宝箱 ——
			if (g_CollGroupIndex >= (int)std::size(g_CollGroups))
				g_CollGroupIndex = 0;
			const auto& group = g_CollGroups[g_CollGroupIndex];
			if (g_CollItemIndex >= (int)group.count)
				g_CollItemIndex = 0;

			// 第一行：类别 + 具体收藏品
			ImGui::SetNextItemWidth(200);
			if (ImGui::BeginCombo(LH("收藏品类别"), LH(group.name)))
			{
				for (int i = 0; i < (int)std::size(g_CollGroups); i++)
				{
					if (ImGui::Selectable(LH(g_CollGroups[i].name), i == g_CollGroupIndex))
					{
						g_CollGroupIndex = i;
						g_CollItemIndex  = 0;
					}
				}
				ImGui::EndCombo();
			}

			ImGui::SameLine();
			ImGui::SetNextItemWidth(240);
			if (ImGui::BeginCombo(LH("收藏品"), ItemName(group, g_CollItemIndex)))
			{
				for (int i = 0; i < (int)group.count; i++)
				{
					if (ImGui::Selectable(ItemName(group, i), i == g_CollItemIndex))
						g_CollItemIndex = i;
				}
				ImGui::EndCombo();
			}

			// 第二行：数量 + 生成按钮（单独一行，否则按钮会被挤出面板）
			ImGui::SetNextItemWidth(120);
			ImGui::SliderInt(LH("数量"), &g_CollAmount, 1, 3);
			ImGui::SameLine();
			if (ImGui::Button(LH("生成收藏品宝箱"), ImVec2(180, 0)))
			{
				if (busy)
				{
					Notifications::Show(LH("宝箱生成器"), LH("刚生成过，等 3 秒再点"), NotificationType::Warning);
				}
				else
				{
					g_SpawnCooldown = nowSec + 3;
					int gi = g_CollGroupIndex;
					int ii = g_CollItemIndex;
					int am = g_CollAmount;
					FiberPool::Push([gi, ii, am] {
						Player target = Players::GetSelected();
						if (!target.IsValid())
							return;

						auto chest = SpawnChestInFront(target);
						if (chest.GetHandle() == 0)
							return;

						const auto& g    = g_CollGroups[gi];
						const auto& info = g.items[ii];

						// 箱子里摆出对应道具实体（给别人刷时，对方走过去自己捡就能进他包里）
						SpawnItemProps(chest, info.model_hash, am);

						if (IsSelf(target))
						{
							for (int i = 0; i < am; i++)
							{
								if (g.script)
									Rewards::GiveScriptReward(info);
								else
									Rewards::GiveReward(info);
							}
							Notifications::Show(LH("宝箱生成器"), LH("收藏品宝箱已生成，东西已进你背包"), NotificationType::Success);
						}
						else
						{
							Notifications::Show(LH("宝箱生成器"),
							    std::format("已给 {} 摆好收藏品宝箱，让他自己过去开", target.GetName()),
							    NotificationType::Success);
						}
					});
				}
			}

			ImGui::Separator();

			// —— 草药宝箱 —：第一行选草药，第二行数量和按钮
			ImGui::SetNextItemWidth(240);
			if (ImGui::BeginCombo(LH("草药"), LH(g_Herbs[g_HerbIndex].second)))
			{
				for (int i = 0; i < (int)g_Herbs.size(); i++)
				{
					if (ImGui::Selectable(LH(g_Herbs[i].second), i == g_HerbIndex))
						g_HerbIndex = i;
				}
				ImGui::EndCombo();
			}

			ImGui::SetNextItemWidth(120);
			ImGui::SliderInt(LH("草药数量"), &g_HerbAmount, 1, 5);
			ImGui::SameLine();
			if (ImGui::Button(LH("生成草药宝箱"), ImVec2(180, 0)))
			{
				if (busy)
				{
					Notifications::Show(LH("宝箱生成器"), LH("刚生成过，等 3 秒再点"), NotificationType::Warning);
				}
				else
				{
					g_SpawnCooldown = nowSec + 3;
					int hi = g_HerbIndex;
					int am = g_HerbAmount;
					FiberPool::Push([hi, am] {
						Player target = Players::GetSelected();
						if (!target.IsValid())
							return;

						auto chest = SpawnChestInFront(target);
						if (chest.GetHandle() == 0)
							return;

						if (IsSelf(target))
						{
							if (!Scripts::RequestScript("interactive_campfire"_J))
							{
								Notifications::Show(LH("宝箱生成器"), LH("营地脚本没起来，等进战局后再试"), NotificationType::Error);
								return;
							}

							for (int i = 0; i < am; i++)
							{
								ScriptFunctions::GiveLootTableAward.StaticCall(g_Herbs[hi].first, 0);
								ScriptMgr::Yield(100ms);
							}

							Notifications::Show(LH("宝箱生成器"), LH("草药宝箱已生成，草药已进你背包"), NotificationType::Success);
						}
						else
						{
							Notifications::Show(LH("宝箱生成器"),
							    std::format("已给 {} 摆好宝箱（草药没法直接塞给别人，箱子是实体，让他自己过去开）", target.GetName()),
							    NotificationType::Success);
						}
					});
				}
			}

			ImGui::Separator();

			// —— 银元宝箱 ——
			ImGui::SetNextItemWidth(200);
			ImGui::SliderInt(LH("银元数量"), &g_SilverAmount, 50, 2000);
			ImGui::SameLine();
			if (ImGui::Button(LH("生成银元宝箱"), ImVec2(180, 0)))
			{
				if (busy)
				{
					Notifications::Show(LH("宝箱生成器"), LH("刚生成过，等 3 秒再点"), NotificationType::Warning);
				}
				else
				{
					g_SpawnCooldown = nowSec + 3;
					int am = g_SilverAmount;
					FiberPool::Push([am] {
						Player target = Players::GetSelected();
						if (!target.IsValid())
							return;

						auto chest = SpawnChestInFront(target);
						if (chest.GetHandle() == 0)
							return;

						if (IsSelf(target))
						{
							// 线上不写钱包，只摆箱子，避免和服务器账本打架把战局拖死
							if (NETWORK::NETWORK_IS_SESSION_ACTIVE())
								Notifications::Show(LH("宝箱生成器"), LH("线上只摆箱子，银元不进钱包（防止卡战局）"), NotificationType::Warning);
							else
								MONEY::_MONEY_INCREMENT_CASH_BALANCE(am, "REWARD_ABANDONED_LOOT_MALE"_J);
							Notifications::Show(LH("宝箱生成器"), LH("银元宝箱已生成"), NotificationType::Success);
						}
						else
						{
							Notifications::Show(LH("宝箱生成器"),
							    std::format("已给 {} 摆好宝箱（箱子是实体，让他自己过去开）", target.GetName()),
							    NotificationType::Success);
						}
					});
				}
			}

			ImGui::Spacing();
			ImGui::TextDisabled(LH("这三个箱子跟着上面「玩家」里选中的人走：选自己是刷自己，选别人就摆在他面前"));
			ImGui::TextDisabled(LH("收藏品箱子里摆的是对应道具实体，对方走过去捡就进他包；草药/银元只能给自己直接到账"));
		}));

		menu->AddItem(std::make_shared<ImGuiItem>([] {
			// TODO: move, refactor, or remove these
			if (ImGui::Button(LH("Spawn Bounty Wagon for Player")))
			{
				FiberPool::Push([] {
					Vector3 coords = ENTITY::GET_ENTITY_COORDS(Players::GetSelected().GetPed().GetHandle(), true, true);
					float rot = ENTITY::GET_ENTITY_ROTATION(Players::GetSelected().GetPed().GetHandle(), 0).z;
					Vehicle::Create("wagonarmoured01x"_J, coords, rot);
					Notifications::Show("Spawned Wagon", "Spawned Bounty Wagon for Player", NotificationType::Success);
				});
			};

			if (ImGui::Button(LH("Spawn Hunting Wagon for Player")))
			{
				FiberPool::Push([] {
					int id   = Players::GetSelected().GetId();
					auto ped = PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(id);
					Vector3 dim1, dim2;
					MISC::GET_MODEL_DIMENSIONS(MISC::GET_HASH_KEY("huntercart01"), &dim1, &dim2);
					float offset = dim2.y * 1.6;

					Vector3 dir = ENTITY::GET_ENTITY_FORWARD_VECTOR(ped);
					float rot   = (ENTITY::GET_ENTITY_ROTATION(ped, 0)).z;
					Vector3 pos = ENTITY::GET_ENTITY_COORDS(ped, true, true);

					Vehicle::Create("huntercart01"_J,
					    Vector3{pos.x + (dir.x * offset), pos.y + (dir.y * offset), pos.z},
					    ENTITY::GET_ENTITY_ROTATION(ped, 0).z);
					Notifications::Show("Spawned Wagon", "Spawned Hunting Wagon for Player", NotificationType::Success);
				});
			}
		}));

		return menu;
	}
}
