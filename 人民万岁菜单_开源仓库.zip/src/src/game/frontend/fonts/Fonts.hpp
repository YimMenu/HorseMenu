#pragma once

#include "imgui.h"
#include "imgui_internal.h"
#include <cstddef>
#include <cstdint>

namespace YimMenu::Fonts
{
	extern const uint8_t MainFont[78948];

	// 微软雅黑子集（含中文与 ASCII），编译进 DLL，不依赖系统字体文件
	extern const uint8_t ChineseFont[];
	extern const size_t ChineseFontLen;
	extern const ImWchar ChineseGlyphRanges[];
}
