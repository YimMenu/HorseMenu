#pragma once
#include <filesystem>
#include <string>
#include <vector>

namespace YimMenu
{
	// 模组包（Rift 那套 165 个模组，已归一化成 人民万岁 的格式）
	// 数据目录：C:\PeopleMenu\mods\index.json + mods/vehicles|horses|world/*.json
	class Mods
	{
	public:
		enum Kind
		{
			Vehicle = 0,
			Horse   = 1,
			World   = 2,
			KindCount
		};

		struct Entry
		{
			std::string Id;
			std::string Label;
			std::string Note;
			std::string File; // 相对 mods 目录
			int Count{};
			bool Heavy{};
		};

		struct Group
		{
			std::vector<Entry> Items;
			int ItemTotal{}; // 物件总数
			bool Loaded{};
		};

		static void Load(); // 读盘，失败只记日志不抛异常
		static bool IsLoaded();
		static const Group& Get(Kind kind);
		static std::filesystem::path Root();
		static std::string LastError();

		// 生成 / 清场：真正的实体创建都在 FiberPool 里按帧分批做，不会卡死游戏
		static bool Spawn(Kind kind, const std::string& id);
		static void Clear();
		static bool IsBusy();
		static int SpawnedCount();
		static std::string StatusText();
	};
}
