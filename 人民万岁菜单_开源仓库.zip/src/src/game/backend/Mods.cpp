#include "Mods.hpp"

#include "FiberPool.hpp"
#include "ScriptMgr.hpp"
#include "Self.hpp"
#include "core/frontend/Notifications.hpp"
#include "game/rdr/Natives.hpp"
#include "game/rdr/Object.hpp"
#include "game/rdr/Ped.hpp"
#include "game/rdr/Vehicle.hpp"

#include <atomic>
#include <cstdlib>
#include <fstream>
#include <mutex>

namespace YimMenu
{
	namespace
	{
		using json = nlohmann::json;

		Mods::Group s_Groups[Mods::KindCount];
		bool s_Loaded      = false;
		std::atomic_bool s_Busy{false};
		std::atomic_int s_Spawned{0};
		std::string s_LastError;
		bool s_StatusDirty = false;
		std::string s_Status;
		std::vector<int> s_Handles; // 只在 fiber 里被 push，UI 线程只在清场时读取
		std::mutex s_HandleMutex;
		constexpr int kMaxEntities = 400;

		std::filesystem::path ConfigRoot()
		{
			std::error_code ec;
			auto root = std::filesystem::path("C:\\PeopleMenu");
			if (std::filesystem::exists(root, ec))
				return root;

			const char* appdata = std::getenv("appdata");
			if (appdata)
				return std::filesystem::path(appdata) / "PeopleMenu";
			return root;
		}

		uint32_t ParseHash(const json& v)
		{
			if (v.is_number_unsigned())
				return v.get<uint32_t>();
			if (v.is_number_integer())
				return static_cast<uint32_t>(v.get<int64_t>());
			if (v.is_string())
			{
				std::string s = v.get<std::string>();
				if (s.size() > 2 && (s[0] == '0') && (s[1] == 'x' || s[1] == 'X'))
					s = s.substr(2);
				return static_cast<uint32_t>(std::strtoul(s.c_str(), nullptr, 16));
			}
			return 0;
		}

		float Num(const json& v, float def = 0.0f)
		{
			if (v.is_number())
				return v.get<float>();
			if (v.is_string())
				return static_cast<float>(std::atof(v.get<std::string>().c_str()));
			return def;
		}

		void Notify(const std::string& msg, NotificationType type)
		{
			Notifications::Show("人民万岁 · 模组", msg, type);
		}
	}

	std::filesystem::path Mods::Root()
	{
		// 模组包根：C:\PeopleMenu，包内 index.json 放在 C:\PeopleMenu\mods\index.json，
		// 每个模组的 file 字段形如 "mods/vehicles/V001_xxx.json"，都以这里为基准
		return ConfigRoot();
	}

	void Mods::Load()
	{
		for (int i = 0; i < KindCount; i++)
		{
			s_Groups[i].Items.clear();
			s_Groups[i].ItemTotal = 0;
			s_Groups[i].Loaded    = false;
		}
		s_Loaded    = false;
		s_LastError.clear();

		auto index_path = Root() / "mods" / "index.json";
		std::ifstream in(index_path, std::ios::binary);
		if (!in.is_open())
		{
			s_LastError = "找不到 " + index_path.string();
			LOG(INFO) << "Mods: " << s_LastError;
			return;
		}

		try
		{
			json doc;
			in >> doc;
			const char* keys[KindCount] = {"vehicle", "horse", "world"};
			for (int i = 0; i < KindCount; i++)
			{
				auto& g = s_Groups[i];
				if (!doc.contains("mods") || !doc["mods"].contains(keys[i]))
					continue;

				for (auto& m : doc["mods"][keys[i]])
				{
					Entry e;
					e.Id    = m.value("id", std::string{});
					e.Label = m.value("label", std::string{});
					e.Note  = m.value("note", std::string{});
					e.File  = m.value("file", std::string{});
					e.Count = m.value("count", 0);
					e.Heavy = m.value("heavy", false);
					g.Items.push_back(std::move(e));
				}
				g.ItemTotal = 0;
				for (auto& e : g.Items)
					g.ItemTotal += e.Count;
				g.Loaded = true;
			}
			s_Loaded = true;
			LOG(INFO) << "Mods: loaded " << s_Groups[Vehicle].Items.size() << " vehicles, "
			          << s_Groups[Horse].Items.size() << " horses, " << s_Groups[World].Items.size() << " world";
		}
		catch (const std::exception& ex)
		{
			s_LastError = std::string("index.json 解析失败：") + ex.what();
			LOG(INFO) << "Mods: " << s_LastError;
		}
	}

	bool Mods::IsLoaded()
	{
		return s_Loaded;
	}

	const Mods::Group& Mods::Get(Kind kind)
	{
		static Group empty;
		if (kind < 0 || kind >= KindCount)
			return empty;
		return s_Groups[kind];
	}

	std::string Mods::LastError()
	{
		return s_LastError;
	}

	bool Mods::IsBusy()
	{
		return s_Busy.load();
	}

	int Mods::SpawnedCount()
	{
		return s_Spawned.load();
	}

	std::string Mods::StatusText()
	{
		if (!s_StatusDirty)
			return s_Status;
		s_StatusDirty = false;
		return s_Status;
	}

	void Mods::Clear()
	{
		std::vector<int> handles;
		{
			std::lock_guard lock(s_HandleMutex);
			handles.swap(s_Handles);
		}
		s_Spawned = 0;
		s_Busy    = false;
		s_Status  = "已清场";
		s_StatusDirty = true;

		FiberPool::Push([handles] {
			for (size_t i = handles.size(); i-- > 0;)
			{
				Entity e(handles[i]);
				if (e)
					e.Delete();
				if ((i % 16) == 0)
					ScriptMgr::Yield();
			}
		});
	}

	bool Mods::Spawn(Kind kind, const std::string& id)
	{
		if (kind < 0 || kind >= KindCount)
			return false;
		if (!s_Loaded)
		{
			Notify("模组清单没加载成功，先点“重新加载清单”", NotificationType::Warning);
			return false;
		}
		if (s_Busy.exchange(true))
		{
			Notify("正在生成中，请稍候", NotificationType::Info);
			return false;
		}
		if (s_Spawned.load() >= kMaxEntities)
		{
			s_Busy = false;
			Notify("场上实体太多，请先清场", NotificationType::Warning);
			return false;
		}

		const Entry* found = nullptr;
		for (auto& e : s_Groups[kind].Items)
			if (e.Id == id)
			{
				found = &e;
				break;
			}
		if (!found)
		{
			s_Busy = false;
			Notify("找不到模组 " + id, NotificationType::Error);
			return false;
		}

		auto entry = *found;
		auto kind_copy = kind;

		FiberPool::Push([entry, kind_copy] {
			auto path = Root() / entry.File;
			std::ifstream in(path, std::ios::binary);
			if (!in.is_open())
			{
				s_Busy = false;
				Notify("读不到模组文件：" + entry.File, NotificationType::Error);
				return;
			}

			json doc;
			try
			{
				in >> doc;
			}
			catch (const std::exception& ex)
			{
				s_Busy = false;
				Notify(std::string("模组文件损坏：") + ex.what(), NotificationType::Error);
				return;
			}

			auto ped     = Self::GetPed();
			auto origin  = ped ? ped.GetPosition() : rage::fvector3{0.0f, 0.0f, 0.0f};
			float heading = ped ? ped.GetRotation().z : 0.0f;

			// 世界模组：一次性占位太多会卡，先清掉上一套
			if (kind_copy == World)
				Clear();

			Entity base{0};
			bool isWorld = (kind_copy == World);

			if (!isWorld)
			{
				auto base_doc = doc.contains("base") ? doc["base"] : json{};
				uint32_t model = kind_copy == Vehicle ? ParseHash(base_doc.value("model", json("0x0")))
				                                      : ParseHash(base_doc.value("horseModel", json("0x0")));

				rage::fvector3 spawn{origin.x + 2.0f, origin.y + 2.0f, origin.z};
				if (kind_copy == Vehicle)
				{
					auto v = Vehicle::Create(model, spawn, heading);
					base   = Entity(v.GetHandle());
				}
				else
				{
					auto p = Ped::Create(model, spawn, heading);
					base   = Entity(p.GetHandle());
				}

				if (!base)
				{
					s_Busy = false;
					s_Status = "基座生成失败";
					s_StatusDirty = true;
					Notify("基座生成失败（模型没加载出来）", NotificationType::Error);
					return;
				}

				base.SetInvincible(true);
				base.ForceSync();
				{
					std::lock_guard lock(s_HandleMutex);
					s_Handles.push_back(base.GetHandle());
				}
				s_Spawned++;
			}

			const int budget = isWorld ? 4 : 8;
			int created = 0;
			int skipped = 0;

			for (auto& it : doc.value("items", json::array()))
			{
				if (s_Spawned.load() >= kMaxEntities)
					break;

				uint32_t model = ParseHash(it.value("model", json("0x0")));
				if (!model)
				{
					skipped++;
					continue;
				}

				int handle = 0;
				if (isWorld)
				{
					rage::fvector3 pos{Num(it["pos"][0]), Num(it["pos"][1]), Num(it["pos"][2])};
					auto o = Object::Create(model, pos);
					if (o)
					{
						handle = o.GetHandle();
						o.SetCollision(false);
						o.SetRotation(rage::fvector3{Num(it["rot"][0]), Num(it["rot"][1]), Num(it["rot"][2])}, 2);
						if (it.value("freeze", true))
							o.SetFrozen(true);
						o.ForceSync();
					}
				}
				else
				{
					auto o = Object::Create(model, base.GetPosition());
					if (o)
					{
						handle = o.GetHandle();
						o.SetCollision(false);
						ENTITY::ATTACH_ENTITY_TO_ENTITY(handle,
						    base.GetHandle(),
						    it.value("bone", 0),
						    Num(it["off"][0]), Num(it["off"][1]), Num(it["off"][2]),
						    Num(it["rot"][0]), Num(it["rot"][1]), Num(it["rot"][2]),
						    false, false, false, false, 2, true, false, false);
						o.ForceSync();
					}
				}

				if (!handle)
				{
					skipped++;
				}
				else
				{
					created++;
					s_Spawned++;
					std::lock_guard lock(s_HandleMutex);
					s_Handles.push_back(handle);
				}

				if ((created % budget) == 0)
					ScriptMgr::Yield(); // 每帧只放这么多个，绝不一口气刷几千个
			}

			s_Busy = false;
			s_Status = std::format("已生成 {}（{} 个实体，跳过 {}）", entry.Label, created, skipped);
			s_StatusDirty = true;
			Notify(s_Status, skipped ? NotificationType::Warning : NotificationType::Success);
			LOG(INFO) << "Mods: spawned " << entry.Id << " created=" << created << " skipped=" << skipped;
		});

		return true;
	}
}
