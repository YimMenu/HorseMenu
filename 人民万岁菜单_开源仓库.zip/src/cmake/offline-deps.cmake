# 离线依赖（不联网、不走 FetchContent）
# 依赖源码已放在 <工程根>/deps/ 下（工程根是 src 的上一级；可用 -DDEPS_ROOT 覆盖）

if(NOT DEFINED DEPS_ROOT OR DEPS_ROOT STREQUAL "")
    if(EXISTS "${CMAKE_CURRENT_SOURCE_DIR}/../deps")
        set(DEPS_ROOT "${CMAKE_CURRENT_SOURCE_DIR}/../deps")
    else()
        set(DEPS_ROOT "${CMAKE_CURRENT_SOURCE_DIR}/deps")
    endif()
endif()
get_filename_component(DEPS_ROOT "${DEPS_ROOT}" ABSOLUTE)
if(NOT EXISTS "${DEPS_ROOT}")
    message(FATAL_ERROR "依赖目录不存在: ${DEPS_ROOT}")
endif()
message(STATUS "DEPS_ROOT: ${DEPS_ROOT}")

# ---------------- Vulkan Headers ----------------
set(vulkan_SOURCE_DIR "${DEPS_ROOT}/vulkan_src/Vulkan-Headers-sdk-1.1.108")
if(NOT EXISTS "${vulkan_SOURCE_DIR}/include/vulkan/vulkan.h")
    message(FATAL_ERROR "Vulkan-Headers 缺失: ${vulkan_SOURCE_DIR}")
endif()
message(STATUS "Vulkan Headers: ${vulkan_SOURCE_DIR}")

# ---------------- imgui ----------------
set(imgui_SOURCE_DIR "${DEPS_ROOT}/imgui_src/imgui-8cc6eee295871bc8852c12372860a50b950d3f56")
if(NOT EXISTS "${imgui_SOURCE_DIR}/imgui.cpp")
    message(FATAL_ERROR "imgui 源码缺失: ${imgui_SOURCE_DIR}")
endif()

file(GLOB SRC_IMGUI
    "${imgui_SOURCE_DIR}/*.cpp"
    "${imgui_SOURCE_DIR}/*.h"
    "${imgui_SOURCE_DIR}/backends/imgui_impl_win32.*"
    "${imgui_SOURCE_DIR}/backends/imgui_impl_dx12.*"
    "${imgui_SOURCE_DIR}/backends/imgui_impl_vulkan.*"
    "${imgui_SOURCE_DIR}/misc/cpp/imgui_stdlib.*"
)

add_library(imgui STATIC ${SRC_IMGUI})
source_group(TREE ${imgui_SOURCE_DIR} PREFIX "imgui" FILES ${SRC_IMGUI})
target_include_directories(imgui PRIVATE
    "${imgui_SOURCE_DIR}"
    "${imgui_SOURCE_DIR}/backends"
    "${imgui_SOURCE_DIR}/misc/cpp"
    "${vulkan_SOURCE_DIR}/include"
)
message(STATUS "imgui: ${imgui_SOURCE_DIR}")

# ---------------- minhook ----------------
set(minhook_SOURCE_DIR "${DEPS_ROOT}/minhook_src/minhook-98b74f1fc12d00313d91f10450e5b3e0036175e3")
add_subdirectory("${minhook_SOURCE_DIR}" "${CMAKE_BINARY_DIR}/_deps/minhook" EXCLUDE_FROM_ALL)

# ---------------- nlohmann json ----------------
add_subdirectory("${DEPS_ROOT}/nlohmann_src/json-3.11.2" "${CMAKE_BINARY_DIR}/_deps/json" EXCLUDE_FROM_ALL)

# ---------------- RDR-Classes ----------------
set(RDR-Classes_SOURCE_DIR "${DEPS_ROOT}/rdrclasses_src/RDR-Classes-a61459d3b100408f736f32046ed2545dc729e617")
add_subdirectory("${RDR-Classes_SOURCE_DIR}" "${CMAKE_BINARY_DIR}/_deps/rdrclasses" EXCLUDE_FROM_ALL)

# ---------------- AsyncLogger ----------------
add_subdirectory("${DEPS_ROOT}/asynclogger_src/AsyncLogger-6fcfd90b3f4ca4dae09c4a96e9a506e6aea06472"
                 "${CMAKE_BINARY_DIR}/_deps/asynclogger" EXCLUDE_FROM_ALL)
# 上游 CMakeLists 忘了把检测结果变成宏，导致头文件去找 fmt；这里补上（MSVC 支持 std::format）
if(MSVC)
    target_compile_definitions(AsyncLogger PUBLIC CXX_FORMAT_SUPPORT=1)
endif()
target_include_directories(AsyncLogger PUBLIC
    "${DEPS_ROOT}/asynclogger_src/AsyncLogger-6fcfd90b3f4ca4dae09c4a96e9a506e6aea06472/include"
)

# ---------------- Lua 5.4 (脚本系统) ----------------
set(lua_SOURCE_DIR "${DEPS_ROOT}/lua_src/lua-5.4.7")
if(NOT EXISTS "${lua_SOURCE_DIR}/src/lua.h")
    message(WARNING "Lua 源码缺失，脚本功能会被禁用: ${lua_SOURCE_DIR}")
    set(LUA_FOUND OFF)
else()
    file(GLOB LUA_SRC_FILES "${lua_SOURCE_DIR}/src/*.c")
    list(REMOVE_ITEM LUA_SRC_FILES
        "${lua_SOURCE_DIR}/src/lua.c"
        "${lua_SOURCE_DIR}/src/luac.c"
        "${lua_SOURCE_DIR}/src/onelua.c")
    add_library(lua STATIC ${LUA_SRC_FILES})
    target_include_directories(lua PUBLIC "${lua_SOURCE_DIR}/src")
    target_compile_definitions(lua PRIVATE LUA_USE_WINDOWS)
    set(LUA_FOUND ON)
    message(STATUS "Lua: ${lua_SOURCE_DIR}")
endif()