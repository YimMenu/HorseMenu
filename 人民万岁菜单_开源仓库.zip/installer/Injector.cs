using System;
using System.Runtime.InteropServices;
using System.Text;

namespace ZunJieSetup
{
    /// <summary>把 DLL 注入到目标进程（CreateRemoteThread + LoadLibraryW）。</summary>
    internal static class Injector
    {
        private const uint PROCESS_ALL_ACCESS = 0x1F0FFF;
        private const uint MEM_COMMIT_RESERVE = 0x3000;
        private const uint PAGE_READWRITE = 0x04;
        private const uint MEM_RELEASE = 0x8000;

        [DllImport("kernel32.dll", SetLastError = true)]
        private static extern IntPtr OpenProcess(uint access, bool inherit, int pid);

        [DllImport("kernel32.dll", SetLastError = true)]
        private static extern IntPtr VirtualAllocEx(IntPtr hProcess, IntPtr lpAddress, uint size, uint type, uint protect);

        [DllImport("kernel32.dll", SetLastError = true)]
        private static extern bool VirtualFreeEx(IntPtr hProcess, IntPtr lpAddress, uint size, uint type);

        [DllImport("kernel32.dll", SetLastError = true)]
        private static extern bool WriteProcessMemory(IntPtr hProcess, IntPtr lpBase, byte[] buffer, uint size, out IntPtr written);

        [DllImport("kernel32.dll", SetLastError = true)]
        private static extern IntPtr GetModuleHandle(string module);

        [DllImport("kernel32.dll", SetLastError = true, CharSet = CharSet.Ansi)]
        private static extern IntPtr GetProcAddress(IntPtr module, string proc);

        [DllImport("kernel32.dll", SetLastError = true)]
        private static extern IntPtr CreateRemoteThread(IntPtr hProcess, IntPtr attr, uint stackSize, IntPtr start, IntPtr param, uint flags, IntPtr threadId);

        [DllImport("kernel32.dll", SetLastError = true)]
        private static extern uint WaitForSingleObject(IntPtr handle, uint milliseconds);

        [DllImport("kernel32.dll", SetLastError = true)]
        private static extern bool CloseHandle(IntPtr handle);

        public static void Inject(int pid, string dllPath)
        {
            if (!System.IO.File.Exists(dllPath))
                throw new System.IO.FileNotFoundException("找不到要注入的 DLL", dllPath);

            IntPtr hProcess = OpenProcess(PROCESS_ALL_ACCESS, false, pid);
            if (hProcess == IntPtr.Zero)
                throw new InvalidOperationException("打开进程失败，错误码 " + Marshal.GetLastWin32Error() + "（请以管理员身份运行）");

            try
            {
                byte[] payload = Encoding.Unicode.GetBytes(dllPath + "\0");
                IntPtr remote = VirtualAllocEx(hProcess, IntPtr.Zero, (uint)payload.Length, MEM_COMMIT_RESERVE, PAGE_READWRITE);
                if (remote == IntPtr.Zero)
                    throw new InvalidOperationException("远程内存分配失败，错误码 " + Marshal.GetLastWin32Error());

                if (!WriteProcessMemory(hProcess, remote, payload, (uint)payload.Length, out _))
                    throw new InvalidOperationException("写入远程内存失败，错误码 " + Marshal.GetLastWin32Error());

                IntPtr loadLibrary = GetProcAddress(GetModuleHandle("kernel32.dll"), "LoadLibraryW");
                if (loadLibrary == IntPtr.Zero)
                    throw new InvalidOperationException("找不到 LoadLibraryW");

                IntPtr thread = CreateRemoteThread(hProcess, IntPtr.Zero, 0, loadLibrary, remote, 0, IntPtr.Zero);
                if (thread == IntPtr.Zero)
                    throw new InvalidOperationException("创建远程线程失败，错误码 " + Marshal.GetLastWin32Error());

                WaitForSingleObject(thread, 15000);
                CloseHandle(thread);
                VirtualFreeEx(hProcess, remote, 0, MEM_RELEASE);
            }
            finally
            {
                CloseHandle(hProcess);
            }
        }
    }
}
