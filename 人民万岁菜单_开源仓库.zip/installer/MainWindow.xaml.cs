﻿using System;
using System.Diagnostics;
using System.IO;
using System.Threading;
using System.Threading.Tasks;
using System.Linq;
using System.Windows;

namespace ZunJieSetup
{
    public partial class MainWindow : Window
    {
        private const string DllName = "Terminus.dll";
        private const string GameExe = "RDR2.exe";
        private const string ProcessName = "RDR2";
        private string _gamePath;

        /// <summary>菜单文件统一放 C 盘，不往游戏根目录写任何东西（跟 Phantom Night 一类菜单一样）。</summary>
        private static readonly string ModDir = @"C:\PeopleMenu";
        private static readonly string ModDll = Path.Combine(ModDir, DllName);
        private static readonly string ThemesDir = Path.Combine(ModDir, "themes");

        public MainWindow()
        {
            InitializeComponent();
            Loaded += (_, __) =>
            {
                Log("注入工具已启动" + (IsElevated() ? "（管理员权限）" : "（未提权，注入游戏需要管理员权限）"));
                Detect();
                EnsureFiles();
                CleanUpLegacyGameFiles();
            };
        }

        /// <summary>把旧版本塞进游戏根目录的 Terminus.dll / themes（只含 01..15.jpg 的）清掉，游戏目录保持干净。</summary>
        private void CleanUpLegacyGameFiles()
        {
            if (string.IsNullOrEmpty(_gamePath))
                return;

            var legacyDll = Path.Combine(_gamePath, DllName);
            if (File.Exists(legacyDll))
            {
                try { File.Delete(legacyDll); Log("已清理游戏根目录里的旧菜单文件：" + legacyDll); }
                catch (Exception ex) { Log("旧菜单文件删不掉（游戏可能在运行）：" + ex.Message); }
            }

            var legacyThemes = Path.Combine(_gamePath, "themes");
            if (Directory.Exists(legacyThemes))
            {
                try
                {
                    var files = Directory.GetFiles(legacyThemes);
                    var onlyOurs = files.Length == 0 || files.All(f =>
                    {
                        var stem = Path.GetFileNameWithoutExtension(f);
                        return stem.Length == 2 && int.TryParse(stem, out var n) && n >= 1 && n <= 15
                               && Path.GetExtension(f).Equals(".jpg", StringComparison.OrdinalIgnoreCase);
                    });
                    if (onlyOurs)
                    {
                        Directory.Delete(legacyThemes, true);
                        Log("已清理游戏根目录里的旧 themes 文件夹（主题图都搬到 C 盘那份了）");
                    }
                    else
                    {
                        Log("游戏目录里的 themes 文件夹里有你自己的图，没动它：" + legacyThemes);
                    }
                }
                catch (Exception ex) { Log("清理旧 themes 失败：" + ex.Message); }
            }
        }

        /// <summary>启动即准备好菜单文件：DLL 放 C:\PeopleMenu，15 张主题原图放 %APPDATA%\PeopleMenu\themes。</summary>
        private void EnsureFiles()
        {
            try
            {
                Directory.CreateDirectory(ModDir);
                if (!ExtractDll(ModDll))
                    return;
                Log("菜单文件已就位：" + ModDll);

                Directory.CreateDirectory(ThemesDir);
                var n = ExtractThemes();
                Log(n > 0 ? ("已放入主题原图 " + n + " 张：" + ThemesDir) : "主题原图已存在，保留你现有的图：" + ThemesDir);
                ThemePathBox.Text = ThemesDir;
            }
            catch (Exception ex)
            {
                Log("准备菜单文件失败：" + ex.Message);
            }
        }

        private static bool IsElevated()
        {
            try
            {
                var identity = System.Security.Principal.WindowsIdentity.GetCurrent();
                var principal = new System.Security.Principal.WindowsPrincipal(identity);
                return principal.IsInRole(System.Security.Principal.WindowsBuiltInRole.Administrator);
            }
            catch
            {
                return false;
            }
        }

        // ---------------- 基础 ----------------

        private void Log(string message)
        {
            LogText.Text += $"[{DateTime.Now:HH:mm:ss}] {message}\n";
            LogScroll.ScrollToEnd();
        }

        private void SetState(string text)
        {
            StateText.Text = text;
        }

        private void Detect()
        {
            var found = GameLocator.Find();
            if (found != null)
            {
                SetGamePath(found);
                Log("已检测到游戏目录：" + found);
            }
            else
            {
                GamePathBox.Text = string.Empty;
                _gamePath = null;
                SetState("未找到游戏");
                Log("未自动检测到 RDR2，请点“手动选择”指定游戏根目录（含 RDR2.exe）");
            }
        }

        private void SetGamePath(string path)
        {
            _gamePath = path;
            GamePathBox.Text = path;
            if (string.IsNullOrEmpty(ThemePathBox.Text))
                ThemePathBox.Text = ThemesDir;
            SetState(File.Exists(ModDll) ? "菜单已就位" : "未就位");
        }

        private void OpenThemes_Click(object sender, RoutedEventArgs e)
        {
            var dir = ThemesDir;
            try
            {
                Directory.CreateDirectory(dir);
                ThemePathBox.Text = dir;
                Process.Start(new ProcessStartInfo("explorer.exe", "\"" + dir + "\"") { UseShellExecute = true });
                Log("已打开主题文件夹：" + dir);
            }
            catch (Exception ex)
            {
                Log("打开主题文件夹失败：" + ex.Message);
            }
        }

        private void CopyThemes_Click(object sender, RoutedEventArgs e)
        {
            var path = ThemePathBox.Text;
            if (string.IsNullOrEmpty(path))
            {
                Log("请先指定游戏目录");
                return;
            }
            try
            {
                Clipboard.SetText(path);
                Log("已复制主题文件夹路径：" + path);
            }
            catch (Exception ex)
            {
                Log("复制失败：" + ex.Message);
            }
        }

        private bool RequireGamePath()
        {
            if (string.IsNullOrEmpty(_gamePath))
            {
                Log("请先指定游戏目录");
                return false;
            }

            if (!File.Exists(Path.Combine(_gamePath, GameExe)))
            {
                Log("该目录下没有 " + GameExe + "，请重新选择");
                return false;
            }

            return true;
        }

        /// <summary>把内嵌的 15 张主题原图释放到 %APPDATA%\PeopleMenu\themes，已存在的不覆盖（玩家自己换的图保留）。</summary>
        private int ExtractThemes()
        {
            var dir = ThemesDir;
            Directory.CreateDirectory(dir);
            int written = 0;
            for (int i = 1; i <= 15; i++)
            {
                var name = i.ToString("00") + ".jpg";
                var target = Path.Combine(dir, name);
                if (File.Exists(target))
                    continue;
                try
                {
                    var uri = new Uri("pack://application:,,,/Assets/themes/" + name);
                    using var stream = System.Windows.Application.GetResourceStream(uri).Stream;
                    using var fs = new FileStream(target, FileMode.Create, FileAccess.Write, FileShare.None);
                    stream.CopyTo(fs);
                    written++;
                }
                catch (Exception ex)
                {
                    Log("释放主题图 " + name + " 失败：" + ex.Message);
                }
            }
            return written;
        }

        /// <summary>把内嵌的 Terminus.dll 释放到游戏目录。</summary>
        private bool ExtractDll(string target)
        {
            try
            {
                var uri = new Uri("pack://application:,,,/Assets/Terminus.dll");
                using var stream = System.Windows.Application.GetResourceStream(uri).Stream;

                // 先去掉隐藏属性，否则 FileStream 覆盖隐藏文件会报 Access denied
                if (File.Exists(target))
                    File.SetAttributes(target, FileAttributes.Normal);

                using (var fs = new FileStream(target, FileMode.Create, FileAccess.Write, FileShare.None))
                {
                    stream.CopyTo(fs);
                }

                // 隐藏 dll，别被人随手拷走（文件夹本身照常可见，主题图也能正常替换）
                File.SetAttributes(target, FileAttributes.Hidden | FileAttributes.System);
                return true;
            }
            catch (Exception ex)
            {
                Log("释放 DLL 失败：" + ex.Message);
                return false;
            }
        }

        // ---------------- 按钮 ----------------

        private void Close_Click(object sender, RoutedEventArgs e) => Close();

        private const string GroupUrl = "https://qm.qq.com/q/EdE7aQ59rW";
        private const string SiteUrl = "https://xn--kiv066b.myweb999.cfd/";

        private void OpenGroup_Click(object sender, RoutedEventArgs e) => OpenUrl(GroupUrl);

        private void OpenSite_Click(object sender, RoutedEventArgs e) => OpenUrl(SiteUrl);

        private void OpenUrl(string url)
        {
            try
            {
                Process.Start(new ProcessStartInfo(url) { UseShellExecute = true });
                Log("已在浏览器打开：" + url);
            }
            catch (Exception ex)
            {
                Log("打开链接失败：" + ex.Message);
            }
        }

        private void Window_MouseLeftButtonDown(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            if (e.ButtonState == System.Windows.Input.MouseButtonState.Pressed)
                DragMove();
        }

        private void Detect_Click(object sender, RoutedEventArgs e) => Detect();

        private void Browse_Click(object sender, RoutedEventArgs e)
        {
            var dialog = new Microsoft.Win32.OpenFolderDialog
            {
                Title = "选择 Red Dead Redemption 2 游戏目录（含 RDR2.exe）",
            };

            if (dialog.ShowDialog() == true)
            {
                SetGamePath(dialog.FolderName);
                Log("已选择目录：" + dialog.FolderName);
            }
        }

        private async void Launch_Click(object sender, RoutedEventArgs e)
        {
            var dll = ModDll;
            if (!File.Exists(dll))
            {
                Directory.CreateDirectory(ModDir);
                if (!ExtractDll(dll))
                    return;
                Log("菜单文件不在，已重新放到 " + dll);
            }

            SetState("注入中…");
            BtnLaunch.IsEnabled = false;

            try
            {
                Process process = FindGameProcess();
                if (process == null)
                {
                    if (string.IsNullOrEmpty(_gamePath))
                    {
                        Log("游戏还没运行，也没检测到游戏目录。请先从这个窗口上面的「自动检测 / 手动选择」指一下游戏目录，或直接从 Steam 启动游戏，进到主界面后再点「加载菜单」。");
                        SetState("游戏未启动");
                        return;
                    }
                    Log("游戏还没运行，先帮你从 Steam 启动；等进到线上 / 线下主界面后再点一次「加载菜单」。");
                    StartGame(_gamePath);

                    // 等 RDR2.exe 进程出现（首次启动可能要 1~3 分钟）
                    var findSw = Stopwatch.StartNew();
                    while (findSw.Elapsed < TimeSpan.FromSeconds(180))
                    {
                        process = FindGameProcess();
                        if (process != null)
                            break;
                        await Task.Delay(700);
                    }

                    if (process == null)
                    {
                        Log("没等到 RDR2.exe 进程。请先在 Steam 里点一次「开始游戏」，确认能进到主菜单，再回来点「加载菜单」。");
                        SetState("未启动");
                        return;
                    }
                    Log("游戏进程已出现（PID " + process.Id + "）");
                }
                else
                {
                    Log("检测到游戏已在运行（PID " + process.Id + "）");
                }

                // 等主窗口就绪（RDR2 渲染窗口出现后才适合注入）
                var winSw = Stopwatch.StartNew();
                while (winSw.Elapsed < TimeSpan.FromSeconds(150))
                {
                    process.Refresh();
                    if (process.HasExited)
                        throw new InvalidOperationException("游戏进程已退出：多半是没走 Steam 登录/DRM 校验，请从 Steam 启动一次。");
                    if (process.MainWindowHandle != IntPtr.Zero)
                        break;
                    await Task.Delay(500);
                }

                if (process.MainWindowHandle == IntPtr.Zero)
                    Log("没等到游戏主窗口，仍然尝试注入（若失败请等进入主菜单后重试）");
                else
                    Log("游戏窗口已就绪，等待 10 秒让脚本系统初始化…");

                await Task.Delay(10000);

                process.Refresh();
                if (process.HasExited)
                    throw new InvalidOperationException("游戏在注入前退出，请从 Steam 正常启动一次后重试");

                Injector.Inject(process.Id, dll);
                Log("加载成功。切回游戏，按 INSERT 呼出菜单（不是 F4、不是 ESC）。");
                MessageBox.Show("加载成功！\n\n切回游戏，按 INSERT 呼出菜单（不是 F4、不是 ESC）。\n如果没反应，退出到主界面再点一次「加载菜单」。",
                                "人民万岁菜单", MessageBoxButton.OK, MessageBoxImage.Information);

                await Task.Delay(3000);
                process.Refresh();
                Log(process.HasExited
                    ? "警告：注入后游戏进程退出，通常是游戏版本与菜单不匹配，请把版本号发我"
                    : "游戏仍在运行，按 INSERT 试试；没反应就退出到主界面再点一次「加载菜单」");
                SetState(process.HasExited ? "注入后退出" : "已注入");
            }
            catch (Exception ex)
            {
                Log("注入失败：" + ex.Message);
                SetState("注入失败");
            }
            finally
            {
                BtnLaunch.IsEnabled = true;
            }
        }

        /// <summary>通过 Steam 启动 RDR2（appid 1174180）。没有 Steam 时退化为直接启动 exe。</summary>
        private void StartGame(string gamePath)
        {
            var steamExe = FindSteamExe();
            if (steamExe != null)
            {
                if (Process.GetProcessesByName("steam").Length == 0)
                {
                    Log("Steam 未运行，先启动 Steam…");
                    Process.Start(new ProcessStartInfo { FileName = steamExe, UseShellExecute = true });
                    Thread.Sleep(4000);
                }
                try
                {
                    Process.Start(new ProcessStartInfo { FileName = "steam://rungameid/1174180", UseShellExecute = true });
                    Log("已通过 Steam 启动 RDR2（steam://rungameid/1174180）");
                    return;
                }
                catch (Exception ex)
                {
                    Log("Steam 启动失败（" + ex.Message + "），改为直接启动 exe");
                }
            }
            else
            {
                Log("没找到 Steam，直接启动 RDR2.exe（若立刻退出请改用 Steam 启动）");
            }

            Process.Start(new ProcessStartInfo
            {
                FileName = Path.Combine(gamePath, GameExe),
                WorkingDirectory = gamePath,
                UseShellExecute = true,
            });
        }

        private static string FindSteamExe()
        {
            try
            {
                using (var key = Microsoft.Win32.Registry.LocalMachine.OpenSubKey(@"SOFTWARE\WOW6432Node\Valve\Steam"))
                {
                    var path = key?.GetValue("InstallPath") as string;
                    if (!string.IsNullOrEmpty(path))
                    {
                        var exe = Path.Combine(path, "steam.exe");
                        if (File.Exists(exe))
                            return exe;
                    }
                }
                using (var key = Microsoft.Win32.Registry.CurrentUser.OpenSubKey(@"SOFTWARE\Valve\Steam"))
                {
                    var path = key?.GetValue("SteamExe") as string;
                    if (!string.IsNullOrEmpty(path) && File.Exists(path))
                        return path;
                }
            }
            catch { }
            foreach (var p in new[] { @"C:\Program Files (x86)\Steam\steam.exe", @"C:\Program Files\Steam\steam.exe" })
                if (File.Exists(p))
                    return p;
            return null;
        }

        private static Process FindGameProcess()
        {
            var byName = Process.GetProcessesByName(ProcessName);
            foreach (var p in byName)
            {
                if (!p.HasExited)
                    return p;
            }
            foreach (var p in Process.GetProcessesByName("RDR2.exe"))
            {
                if (!p.HasExited)
                    return p;
            }
            return null;
        }

        private void Uninstall_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var target = ModDll;
                if (File.Exists(target))
                {
                    File.Delete(target);
                    Log("已删除 " + target);
                }

                SetState("已卸载");
                Log("卸载完成（游戏本体不受影响，主题文件夹和你的图都保留）");
            }
            catch (Exception ex)
            {
                Log("卸载失败（游戏可能正在运行）：" + ex.Message);
            }
        }
    }
}
