using System.Windows;

namespace ZunJieSetup
{
    public partial class App : Application
    {
    }
}
