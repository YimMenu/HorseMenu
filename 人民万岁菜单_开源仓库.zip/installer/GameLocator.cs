using System;
using System.Collections.Generic;
using System.IO;
using System.Text.RegularExpressions;

namespace ZunJieSetup
{
    /// <summary>定位 RDR2 安装目录：Steam 库配置 + 常见路径。</summary>
    internal static class GameLocator
    {
        private const string GameFolder = "Red Dead Redemption 2";
        private const string GameExe = "RDR2.exe";

        public static string Find()
        {
            foreach (var root in SteamLibraryRoots())
            {
                var candidate = Path.Combine(root, "steamapps", "common", GameFolder);
                if (File.Exists(Path.Combine(candidate, GameExe)))
                    return candidate;
            }

            foreach (var drive in new[] { "C:", "D:", "E:", "F:", "G:" })
            {
                foreach (var sub in new[]
                         {
                             @"\SteamLibrary\steamapps\common\" + GameFolder,
                             @"\Steam\steamapps\common\" + GameFolder,
                             @"\Games\" + GameFolder,
                             @"\" + GameFolder,
                         })
                {
                    var candidate = drive + sub;
                    if (File.Exists(Path.Combine(candidate, GameExe)))
                        return candidate;
                }
            }

            foreach (var programFiles in new[]
                     {
                         Environment.GetEnvironmentVariable("ProgramFiles(x86)"),
                         Environment.GetEnvironmentVariable("ProgramFiles"),
                     })
            {
                if (string.IsNullOrEmpty(programFiles))
                    continue;

                var candidate = Path.Combine(programFiles, "Steam", "steamapps", "common", GameFolder);
                if (File.Exists(Path.Combine(candidate, GameExe)))
                    return candidate;
            }

            return null;
        }

        private static List<string> SteamLibraryRoots()
        {
            var roots = new List<string>();
            string steam = null;

            try
            {
                steam = Microsoft.Win32.Registry.GetValue(@"HKEY_CURRENT_USER\Software\Valve\Steam", "SteamPath", null) as string;
                if (string.IsNullOrEmpty(steam))
                    steam = Microsoft.Win32.Registry.GetValue(
                        @"HKEY_LOCAL_MACHINE\SOFTWARE\WOW6432Node\Valve\Steam", "InstallPath", null) as string;
            }
            catch
            {
                // 注册表不可读时走默认路径探测
            }

            if (!string.IsNullOrEmpty(steam))
            {
                steam = steam.Replace('/', '\\');
                if (Directory.Exists(steam))
                    roots.Add(steam);
            }

            var libraries = new List<string>();
            foreach (var root in roots.ToArray())
            {
                var vdf = Path.Combine(root, "steamapps", "libraryfolders.vdf");
                if (!File.Exists(vdf))
                    continue;

                try
                {
                    var text = File.ReadAllText(vdf);
                    foreach (Match m in Regex.Matches(text, "\"path\"\\s+\"([^\"]+)\""))
                    {
                        var p = m.Groups[1].Value.Replace(@"\\", @"\");
                        if (Directory.Exists(p))
                            libraries.Add(p);
                    }
                }
                catch
                {
                    // 单个库文件读取失败不影响其他路径
                }
            }

            roots.AddRange(libraries);
            if (roots.Count == 0)
                roots.Add(@"C:\Program Files (x86)\Steam");

            return roots;
        }
    }
}
