﻿# -*- coding: utf-8 -*-
"""逐行审计：找出菜单里仍是英文、且没进词表的可见文案。"""
import os, re, sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import dict_labels, dict_descs, dict_ui, dict_names

SRC = r"E:\DeepSeek\work\rdr2-zunzhe\src\src"
T = {}
for d in (dict_labels.D, dict_descs.D, dict_ui.D, dict_names.D):
    T.update(d)

CJK = re.compile(r"[\u4e00-\u9fff]")
WORD = re.compile(r"[A-Za-z]{3,}")
# 单行内的普通字符串字面量
LIT = re.compile(r'(?<![A-Za-z_])"((?:[^"\\]|\\.)*)"')
CALL = re.compile(r"ImGui::(Text|TextWrapped|TextDisabled|TextColored|BulletText|LabelText|"
                  r"Selectable|Button|MenuItem|Checkbox|Combo|Begin|BeginChild|BeginPopupModal|"
                  r"CollapsingHeader|TreeNode|SetTooltip|InputText|RadioButton|BeginCombo)\s*\(")

# 明显是内部 ID / 格式串 / 路径的，跳过
SKIP = re.compile(r"^(##|#|%|\s$)|\.(png|jpg|json|ini|log|dll)$|^[a-z0-9_]+$|^[A-Z][A-Z0-9_]{2,}$|^ImGui|imgui")


def main():
    hits = {}
    for root, _, files in os.walk(SRC):
        for f in sorted(files):
            if not f.endswith((".cpp", ".hpp")):
                continue
            p = os.path.join(root, f)
            for ln, line in enumerate(open(p, encoding="utf-8-sig", errors="ignore"), 1):
                if "LH(" in line or CJK.search(line):
                    continue
                if not CALL.search(line):
                    continue
                for m in LIT.finditer(line):
                    s = m.group(1).strip()
                    if not s or not WORD.search(s) or SKIP.search(s):
                        continue
                    if s in T:
                        continue
                    key = s
                    hits.setdefault(key, []).append(f"{os.path.relpath(p, SRC)}:{ln}")

    out = r"E:\DeepSeek\work\rdr2-zunzhe\analysis\untranslated.txt"
    with open(out, "w", encoding="utf-8") as fh:
        for s in sorted(hits):
            fh.write(f"{s}\t{len(hits[s])}\t{hits[s][0]}\n")
    print("untranslated unique:", len(hits))
    for s in sorted(hits)[:50]:
        print("  ", s, "|", hits[s][0])


if __name__ == "__main__":
    main()
