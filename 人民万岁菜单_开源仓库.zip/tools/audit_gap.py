# -*- coding: utf-8 -*-
"""统计：源码里通过 LH(...) 显示的英文，有多少在词表里没有中文对应。"""
import io, os, re, json

ROOT = r"E:\DeepSeek\work\rdr2-zunzhe\src\src"
LOC = os.path.join(ROOT, r"core\frontend\Localization.cpp")

pairs = {}
for m in re.finditer(r'\{"((?:[^"\\]|\\.)*)", "((?:[^"\\]|\\.)*)"\}', io.open(LOC, encoding="utf-8-sig").read()):
    pairs[m.group(1)] = m.group(2)

used = {}
pat = re.compile(r'LH\(\s*"((?:[^"\\]|\\.)*)"\s*\)')
for root, dirs, files in os.walk(ROOT):
    for fn in files:
        if not fn.endswith(".cpp") or fn == "Localization.cpp":
            continue
        p = os.path.join(root, fn)
        txt = io.open(p, encoding="utf-8-sig", errors="ignore").read()
        for m in pat.finditer(txt):
            s = m.group(1)
            used.setdefault(s, set()).add(fn)

missing = sorted([s for s in used if s not in pairs])
same = sorted([s for s in used if s in pairs and pairs[s] == s])

print("table entries:", len(pairs))
print("LH literals:", len(used))
print("missing (no zh):", len(missing))
print("same-as-en:", len(same))

out = []
out.append("=== MISSING ({} ) ===".format(len(missing)))
for s in missing:
    out.append("{}\t{}".format(s, ",".join(sorted(used[s]))))
out.append("")
out.append("=== SAME-AS-EN ({}) ===".format(len(same)))
for s in same:
    out.append("\t".join([s, pairs[s]]))

io.open(r"E:\DeepSeek\work\rdr2-zunzhe\analysis\loc_gap.txt", "w", encoding="utf-8").write("\n".join(out))
print("written analysis/loc_gap.txt")
for s in missing[:120]:
    print("  MISS:", s, "|", ",".join(sorted(used[s])))
