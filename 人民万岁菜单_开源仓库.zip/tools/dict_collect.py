# -*- coding: utf-8 -*-
"""收藏品名字中文（玩家 → 宝箱 里的下拉要能看懂每件叫什么）。"""

D = {
    # —— 传家宝 ——
    "Boar Bristle Brush": "野猪鬃毛刷",
    "Ebony Hairbrush": "乌木发刷",
    "Goat Hair Brush": "山羊毛刷",
    "Horse Hair Brush": "马鬃发刷",
    "New Guinea Rosewood Brush": "新几内亚红木发刷",
    "Rosewood Brush": "红木发刷",
    "Boxwood Comb": "黄杨木梳",
    "Cherrywood Comb": "樱桃木梳",
    "Ivory Comb": "象牙梳",
    "Tortoiseshell Comb": "玳瑁梳",
    "Carved Wood Hairpin": "雕木发簪",
    "Ebony Hairpin": "乌木发簪",
    "Ivory Hairpin": "象牙发簪",
    "Jade Hairpin": "玉发簪",
    "Metal Hairpin": "金属发簪",

    # —— 硬币 ——
    "1700 New Yorke Token": "1700 年纽约代币",
    "1787 One Cent Token": "1787 年一分代币",
    "1789 Penny": "1789 年便士",
    "1792 Nickel": "1792 年五分镍币",
    "1792 Quarter": "1792 年两角五分",
    "1792 Liberty Quarter": "1792 年自由女神两角五分",
    "1794 Silver Dollar": "1794 年银元",
    "1795 Half Eagle": "1795 年半鹰金币",
    "1796 Halfpenny": "1796 年半便士",
    "1797 Gold Eagle": "1797 年鹰金币",
    "1798 Draped Bust Silver Dollar": "1798 年披肩银元",
    "1800 Half Dime": "1800 年半角银币",
    "1800 Five Dollar Bechtler": "1800 年贝希特勒五元金币",
    "1800 Gold Quarter": "1800 年四分之一金币",
    "1800 Gold Dollar": "1800 年一美元金币",

    # —— 酒瓶 ——
    "Cognac": "干邑白兰地",
    "Absinthe": "苦艾酒",
    "Carribean Rum": "加勒比朗姆酒",
    "Irish Whisky": "爱尔兰威士忌",
    "London Dry Gin": "伦敦干金酒",
    "Old Tom Gin": "老汤姆金酒",
    "Gran Corazon Madeira": "马德拉葡萄酒",
    "Scotch Whisky": "苏格兰威士忌",
    "Tennessee Whiskey": "田纳西威士忌",

    # —— 箭头 ——
    "Agate Arrowhead": "玛瑙箭头",
    "Bone Arrowhead": "骨制箭头",
    "Chipped Arrowhead": "打制箭头",
    "Crude Arrowhead": "粗制箭头",
    "Feldspar Arrowhead": "长石箭头",
    "Granite Arrowhead": "燧石箭头",
    "Obsidian Arrowhead": "黑曜石箭头",
    "Quartz Arrowhead": "石英箭头",
    "Raw Arrowhead": "原石箭头",
    "Rough Arrowhead": "粗磨箭头",
    "Slate Arrowhead": "板岩箭头",
    "Splinter Arrowhead": "碎裂箭头",

    # —— 手镯 ——
    "Abello Ruby Bangle Bracelet": "阿贝罗红宝石手镯",
    "Durant Pearl Bracelet": "杜兰特珍珠手镯",
    "Elliston Carved Bracelet": "埃利斯顿雕纹手镯",
    "Ojeda Rose Gold Bracelet": "奥赫达玫瑰金手镯",
    "Greco Sapphire Bracelet": "格雷科蓝宝石手镯",
    "Helena Sapphire Bracelet": "海伦娜蓝宝石手镯",
    "Infanta Turquoise Bracelet": "因凡塔绿松石手镯",
    "Hajnal Garnet Bangle Bracelet": "哈伊纳尔石榴石手镯",

    # —— 耳环 ——
    "Ursula Citrine Earrings": "乌苏拉黄水晶耳环",
    "Emmeline Coral Earrings": "埃米琳珊瑚耳环",
    "Sterling Tooth Earrings": "斯特林牙饰耳环",
    "Dutchess Emerald Earrings": "公爵夫人祖母绿耳环",
    "Orchidee Diamond Earrings": "兰花钻石耳环",
    "Josephine Pearl Earrings": "约瑟芬珍珠耳环",
    "Beauchene Ruby Earrings": "博谢纳红宝石耳环",
    "Harford Garnet Earrings": "哈福德石榴石耳环",
    "Endicott Diamond Earrings": "恩迪科特钻饰耳环",
    "Royal Victoria Diamond Earrings": "维多利亚女王钻饰耳环",
    "Calumet Turquoise Earrings": "卡柳梅特绿松石耳环",

    # —— 项链 ——
    "Tuamotu Pearl Necklace": "土阿莫土黑珍珠项链",
    "Braxton Amethyst Necklace": "布拉克斯顿紫水晶项链",
    "Ainsworth Cross Necklace": "安斯沃思十字架项链",
    "Gosselin White Gold Necklace": "戈瑟兰白金项链",
    "Pelle Pearl Necklace": "佩尔珍珠项链",
    "Rou Pearl Necklace": "鲁氏珍珠项链",
    "Dane Topaz Necklace": "戴恩黄玉项链",
    "Blakely Miniature Necklace": "布莱克利微缩画像项链",
    "Richelieu Amethyst Necklace": "黎塞留紫水晶项链",

    # —— 戒指 ——
    "Harland Coral Ring": "哈兰珊瑚戒指",
    "Aubrey Onyx Ring": "奥布里缟玛瑙戒指",
    "Bosque Emerald Ring": "博斯克祖母绿戒指",
    "Beaulieux Diamond Ring": "博勒厄钻石戒指",
    "Yates Diamond Ring": "耶茨钻石戒指",
    "Bonnard Pearl Ring": "博纳尔珍珠戒指",
    "Pilgrim Moonstone Ring": "朝圣者月光石戒指",
    "Sackville Diamond Ring": "萨克维尔钻石戒指",
    "Banais Topaz Ring": "巴奈黄玉戒指",
    "Magnate Turquoise Ring": "巨头绿松石戒指",
    "Thorburn Turquoise Ring": "索伯恩绿松石戒指",
}

# —— 塔罗牌（4 套 × 14 张，规则生成）——
_SUIT = {"Cups": "圣杯", "Pentacles": "星币", "Swords": "宝剑", "Wands": "权杖"}
_RANK = {
    "2": "2", "3": "3", "4": "4", "5": "5", "6": "6", "7": "7",
    "8": "8", "9": "9", "10": "10", "Ace": "王牌", "King": "国王",
    "Knight": "骑士", "Page": "侍从", "Queen": "王后",
}
for _suit_en, _suit_cn in _SUIT.items():
    for _rank_en, _rank_cn in _RANK.items():
        D[f"{_rank_en} of {_suit_en}"] = f"塔罗 · {_suit_cn} {_rank_cn}"
