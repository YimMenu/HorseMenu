# -*- coding: utf-8 -*-
import re
src = r"E:\DeepSeek\work\rdr2-zunzhe\src\src\game\pointers\Pointers.cpp"
exe = r"E:\SteamLibrary\steamapps\common\Red Dead Redemption 2\RDR2.exe"
text = open(src, encoding="utf-8", errors="ignore").read()
pats = re.findall(r'Pattern<\s*"([0-9A-Fa-f? ]+)"\s*>\s*\(\s*"([^"]+)"', text)
data = open(exe, "rb").read()
print("patterns", len(pats), "exe", len(data))
missing = []
for sig, name in pats:
    parts = []
    for t in sig.split():
        if t in ("?", "??"):
            parts.append(b"\x00")
        else:
            parts.append(re.escape(bytes([int(t, 16)])))
    rx = b"".join(parts).replace(b"\x00", b".")
    if not re.search(rx, data):
        missing.append(name)
print("MISSING", len(missing))
for m in missing[:40]:
    print("  -", m)
