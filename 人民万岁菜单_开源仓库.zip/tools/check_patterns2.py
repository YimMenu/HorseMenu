import re
src = r"E:\DeepSeek\work\rdr2-zunzhe\src\src\game\pointers\Pointers.cpp"
exe = r"E:\SteamLibrary\steamapps\common\Red Dead Redemption 2\RDR2.exe"
text = open(src, encoding="utf-8", errors="ignore").read()
pats = re.findall(r'Pattern<\s*"([0-9A-Fa-f? ]+)"\s*>\s*\(\s*"([^"]+)"', text)
data = open(exe, "rb").read()
print("patterns", len(pats))
miss = []
for sig, name in pats:
    rx = b"".join(b"." if t in ("?", "??") else ("\\x%02x" % int(t, 16)).encode() for t in sig.split())
    if not re.search(rx, data):
        miss.append(name)
print("MISS", len(miss))
print("first 10 miss:", miss[:10])
print("first 10 ok:", [n for s,n in pats if n not in miss][:10])
