# -*- coding: utf-8 -*-
"""尊者RDR2 集合包 结构分析：PE 段/熵、可读字符串、pack.db 类型"""
import re, sys, math, os, json, collections

SRC = r"E:\555\尊者RDR2(2)\1Ardr2\1ArdrPack\3集合包"
OUT = r"E:\DeepSeek\work\rdr2-zunzhe\analysis"
os.makedirs(OUT, exist_ok=True)


def entropy(b):
    if not b:
        return 0.0
    c = collections.Counter(b)
    n = len(b)
    return -sum((v / n) * math.log2(v / n) for v in c.values())


def pe_sections(data):
    try:
        e_lfanew = int.from_bytes(data[0x3c:0x40], "little")
        assert data[e_lfanew:e_lfanew + 4] == b"PE\0\0"
        num_sec = int.from_bytes(data[e_lfanew + 6:e_lfanew + 8], "little")
        opt_size = int.from_bytes(data[e_lfanew + 20:e_lfanew + 22], "little")
        sec_off = e_lfanew + 24 + opt_size
        out = []
        for i in range(num_sec):
            h = data[sec_off + i * 40: sec_off + (i + 1) * 40]
            name = h[:8].rstrip(b"\0").decode("latin1")
            vsize = int.from_bytes(h[8:12], "little")
            vaddr = int.from_bytes(h[12:16], "little")
            rawsize = int.from_bytes(h[16:20], "little")
            rawptr = int.from_bytes(h[20:24], "little")
            body = data[rawptr:rawptr + rawsize]
            out.append(dict(name=name, vsize=vsize, vaddr=vaddr, rawsize=rawsize,
                            rawptr=rawptr, entropy=round(entropy(body), 3)))
        return out
    except Exception as e:
        return [{"error": str(e)}]


ASCII_RE = re.compile(rb"[\x20-\x7e]{5,}")
U16_RE = re.compile(rb"(?:[\x20-\x7e]\x00){4,}")


def strings_report(path):
    data = open(path, "rb").read()
    a = [m.group().decode("latin1") for m in ASCII_RE.finditer(data)]
    u = [m.group().decode("utf-16-le", "ignore") for m in U16_RE.finditer(data)]
    return data, a, u


def main():
    report = {}
    for fn in ["HorseMenu.dll", "pack.db", "1初始化_packed.exe", "2激活器_packed.exe", "3注入器.exe"]:
        p = os.path.join(SRC, fn)
        if not os.path.exists(p):
            continue
        data, a, u = strings_report(p)
        info = dict(size=len(data), entropy=round(entropy(data), 3), ascii_count=len(a), utf16_count=len(u))
        if fn.lower().endswith((".dll", ".exe")):
            info["sections"] = pe_sections(data)
        info["head_hex"] = data[:16].hex()
        report[fn] = info
        base = os.path.join(OUT, re.sub(r"[^\w.-]", "_", fn))
        with open(base + ".ascii.txt", "w", encoding="utf-8") as f:
            f.write("\n".join(a))
        with open(base + ".utf16.txt", "w", encoding="utf-8") as f:
            f.write("\n".join(u))
        print(f"--- {fn} size={len(data)} ent={info['entropy']} ascii={len(a)} u16={len(u)} head={info['head_hex']}")
        if "sections" in info:
            for s in info["sections"]:
                print("   ", s)
    with open(os.path.join(OUT, "report.json"), "w", encoding="utf-8") as f:
        json.dump(report, f, ensure_ascii=False, indent=2)


if __name__ == "__main__":
    main()
